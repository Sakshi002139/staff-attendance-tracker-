package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;

import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditStaffActivity extends AppCompatActivity {

    private static final String TAG = "EditStaffActivity";

    // Toolbar
    private MaterialToolbar toolbar;

    // TextInputLayouts
    private TextInputLayout layoutStaffId, layoutName, layoutEmail, layoutPhone,
            layoutRole, layoutDepartment, layoutJoiningDate,
            layoutAddress, layoutStatus;

    // TextInputEditTexts
    private TextInputEditText etStaffId, etName, etEmail, etPhone, etRole,
            etJoiningDate, etAddress;
    private AppCompatAutoCompleteTextView etDepartment, etStatus;

    // Buttons
    private MaterialButton btnUpdateStaff, btnDeleteStaff, btnCancel;

    // Firebase
    private DatabaseReference databaseReference;
    private SessionManager sessionManager;

    // Data
    private String companyKey;
    private String empId;
    private String employeeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_staff);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference();
        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();

        Log.d(TAG, "Company Key: " + companyKey);

        // Initialize views
        initViews();

        // Setup toolbar
        setupToolbar();

        // Get intent data
        getIntentData();

        // Setup dropdowns
        setupDepartmentDropdown();
        setupStatusDropdown();

        // Setup date picker
        setupDatePicker();

        // If we have empId, load full staff data from Firebase
        if (empId != null && !empId.isEmpty()) {
            loadStaffDataFromFirebase();
        } else {
            Toast.makeText(this, "Error: Staff ID not found", Toast.LENGTH_LONG).show();
            finish();
        }

        // Setup click listeners
        setupClickListeners();
    }

    private void initViews() {
        // Toolbar
        toolbar = findViewById(R.id.toolbar);

        // TextInputLayouts
        layoutStaffId = findViewById(R.id.layoutStaffId);
        layoutName = findViewById(R.id.layoutName);
        layoutEmail = findViewById(R.id.layoutEmail);
        layoutPhone = findViewById(R.id.layoutPhone);
        layoutRole = findViewById(R.id.layoutRole);
        layoutDepartment = findViewById(R.id.layoutDepartment);
        layoutJoiningDate = findViewById(R.id.layoutJoiningDate);
        layoutAddress = findViewById(R.id.layoutAddress);
        layoutStatus = findViewById(R.id.layoutStatus);

        // TextInputEditTexts
        etStaffId = findViewById(R.id.etStaffId);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etRole = findViewById(R.id.etRole);
        etDepartment = findViewById(R.id.etDepartment);
        etJoiningDate = findViewById(R.id.etJoiningDate);
        etAddress = findViewById(R.id.etAddress);
        etStatus = findViewById(R.id.etStatus);

        // Buttons
        btnUpdateStaff = findViewById(R.id.btnUpdateStaff);
        btnDeleteStaff = findViewById(R.id.btnDeleteStaff);
        btnCancel = findViewById(R.id.btnCancel);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Edit Staff Details");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void getIntentData() {
        Intent intent = getIntent();
        if (intent != null) {
            // Get data from intent using the keys from your log
            empId = intent.getStringExtra("employeeId");
            employeeName = intent.getStringExtra("employeeName");
            // companyKey is already from session, but we can also get from intent
            if (intent.hasExtra("companyKey")) {
                companyKey = intent.getStringExtra("companyKey");
            }

            Log.d(TAG, "Received from intent - empId: " + empId + ", name: " + employeeName);
        }
    }

    private void loadStaffDataFromFirebase() {
        if (companyKey == null || empId == null) {
            Toast.makeText(this, "Error: Company or Staff ID missing", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading
        btnUpdateStaff.setEnabled(false);
        btnUpdateStaff.setText("Loading...");

        DatabaseReference staffRef = databaseReference
                .child("Companies")
                .child(companyKey)
                .child("Employees")
                .child(empId);

        staffRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                btnUpdateStaff.setEnabled(true);
                btnUpdateStaff.setText("Update Staff");

                if (snapshot.exists()) {
                    // Get all data from Firebase
                    String name = snapshot.child("name").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class);
                    String role = snapshot.child("role").getValue(String.class);
                    String department = snapshot.child("department").getValue(String.class);
                    String joiningDate = snapshot.child("joiningDate").getValue(String.class);
                    String address = snapshot.child("address").getValue(String.class);
                    String accountStatus = snapshot.child("accountStatus").getValue(String.class);
                    String attendanceStatus = snapshot.child("attendanceStatus").getValue(String.class);
                    String companyName = snapshot.child("companyName").getValue(String.class);

                    // Log the data
                    Log.d(TAG, "========== FIREBASE DATA ==========");
                    Log.d(TAG, "empId: " + empId);
                    Log.d(TAG, "name: " + name);
                    Log.d(TAG, "email: " + email);
                    Log.d(TAG, "phone: " + phone);
                    Log.d(TAG, "role: " + role);
                    Log.d(TAG, "department: " + department);
                    Log.d(TAG, "joiningDate: " + joiningDate);
                    Log.d(TAG, "address: " + address);
                    Log.d(TAG, "accountStatus: " + accountStatus);
                    Log.d(TAG, "attendanceStatus: " + attendanceStatus);
                    Log.d(TAG, "companyName: " + companyName);
                    Log.d(TAG, "===================================");

                    // Set data to views
                    etStaffId.setText(empId);
                    if (name != null) etName.setText(name);
                    if (email != null) etEmail.setText(email);
                    if (phone != null) etPhone.setText(phone);
                    if (role != null) etRole.setText(role);
                    if (department != null) etDepartment.setText(department);
                    if (joiningDate != null) etJoiningDate.setText(joiningDate);
                    if (address != null) etAddress.setText(address);
                    if (accountStatus != null) etStatus.setText(accountStatus);

                    // Show success toast
                    Toast.makeText(EditStaffActivity.this,
                            "Loaded data for: " + (name != null ? name : employeeName),
                            Toast.LENGTH_SHORT).show();
                } else {
                    Log.e(TAG, "No data found for employee ID: " + empId);
                    Toast.makeText(EditStaffActivity.this,
                            "No staff data found in database", Toast.LENGTH_LONG).show();

                    // Still set the ID so user can see which employee
                    etStaffId.setText(empId);
                    if (employeeName != null) {
                        etName.setText(employeeName);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                btnUpdateStaff.setEnabled(true);
                btnUpdateStaff.setText("Update Staff");
                Log.e(TAG, "Failed to load data: " + error.getMessage());
                Toast.makeText(EditStaffActivity.this,
                        "Error loading data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupDepartmentDropdown() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                new String[]{
                        "Human Resources",
                        "Information Technology",
                        "Accounts & Finance",
                        "Sales & Marketing",
                        "Operations",
                        "Customer Support",
                        "Administration",
                        "Software Development",
                        "Android Development",
                        "Web Development",
                        "mobile application developer"
                }
        );
        etDepartment.setAdapter(adapter);
    }

    private void setupStatusDropdown() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                new String[]{"active", "inactive"}
        );
        etStatus.setAdapter(adapter);
    }

    private void setupDatePicker() {
        etJoiningDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();

            // Try to parse existing date if available
            if (!TextUtils.isEmpty(etJoiningDate.getText())) {
                try {
                    String[] dateParts = etJoiningDate.getText().toString().split("/");
                    if (dateParts.length == 3) {
                        int day = Integer.parseInt(dateParts[0]);
                        int month = Integer.parseInt(dateParts[1]) - 1;
                        int year = Integer.parseInt(dateParts[2]);
                        calendar.set(year, month, day);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        etJoiningDate.setText(date);
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });
    }

    private void setupClickListeners() {
        btnUpdateStaff.setOnClickListener(v -> validateAndUpdateStaff());
        btnDeleteStaff.setOnClickListener(v -> showDeleteConfirmationDialog());
        btnCancel.setOnClickListener(v -> onBackPressed());
    }

    private void validateAndUpdateStaff() {
        // Get values from input fields
        String updatedName = etName.getText().toString().trim();
        String updatedEmail = etEmail.getText().toString().trim();
        String updatedPhone = etPhone.getText().toString().trim();
        String updatedRole = etRole.getText().toString().trim();
        String updatedDepartment = etDepartment.getText().toString().trim();
        String updatedJoiningDate = etJoiningDate.getText().toString().trim();
        String updatedAddress = etAddress.getText().toString().trim();
        String updatedStatus = etStatus.getText().toString().trim();

        // Validate
        if (TextUtils.isEmpty(updatedName)) {
            layoutName.setError("Name is required");
            etName.requestFocus();
            return;
        } else {
            layoutName.setError(null);
        }

        if (TextUtils.isEmpty(updatedEmail)) {
            layoutEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(updatedEmail).matches()) {
            layoutEmail.setError("Enter valid email");
            etEmail.requestFocus();
            return;
        } else {
            layoutEmail.setError(null);
        }

        if (TextUtils.isEmpty(updatedPhone)) {
            layoutPhone.setError("Phone is required");
            etPhone.requestFocus();
            return;
        } else if (updatedPhone.length() != 10) {
            layoutPhone.setError("Enter valid 10-digit phone number");
            etPhone.requestFocus();
            return;
        } else {
            layoutPhone.setError(null);
        }

        if (TextUtils.isEmpty(updatedRole)) {
            layoutRole.setError("Role is required");
            etRole.requestFocus();
            return;
        } else {
            layoutRole.setError(null);
        }

        if (TextUtils.isEmpty(updatedDepartment)) {
            layoutDepartment.setError("Department is required");
            etDepartment.requestFocus();
            return;
        } else {
            layoutDepartment.setError(null);
        }

        if (TextUtils.isEmpty(updatedJoiningDate)) {
            layoutJoiningDate.setError("Joining date is required");
            etJoiningDate.requestFocus();
            return;
        } else {
            layoutJoiningDate.setError(null);
        }

        if (TextUtils.isEmpty(updatedStatus)) {
            layoutStatus.setError("Status is required");
            etStatus.requestFocus();
            return;
        } else {
            layoutStatus.setError(null);
        }

        // Update staff in database
        updateStaffInDatabase(updatedName, updatedEmail, updatedPhone, updatedRole,
                updatedDepartment, updatedJoiningDate, updatedAddress, updatedStatus);
    }

    private void updateStaffInDatabase(String name, String email, String phone,
                                       String role, String department,
                                       String joiningDate, String address,
                                       String status) {
        if (companyKey == null || empId == null) {
            Toast.makeText(this, "Error: Company or Staff ID missing", Toast.LENGTH_SHORT).show();
            return;
        }

        btnUpdateStaff.setEnabled(false);
        btnUpdateStaff.setText("Updating...");

        DatabaseReference staffRef = databaseReference
                .child("Companies")
                .child(companyKey)
                .child("Employees")
                .child(empId);

        Map<String, Object> updates = new HashMap<>();
        updates.put("name", name);
        updates.put("email", email);
        updates.put("phone", phone);
        updates.put("role", role);
        updates.put("department", department);
        updates.put("joiningDate", joiningDate);
        updates.put("address", address);
        updates.put("accountStatus", status.toLowerCase());

        Log.d(TAG, "Updating staff with ID: " + empId);
        Log.d(TAG, "Update data: " + updates.toString());

        staffRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Staff updated successfully", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnUpdateStaff.setEnabled(true);
                    btnUpdateStaff.setText("Update Staff");
                    Log.e(TAG, "Failed to update: " + e.getMessage());
                    Toast.makeText(this, "Failed to update: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void showDeleteConfirmationDialog() {
        String displayName = etName.getText().toString().trim();
        if (TextUtils.isEmpty(displayName)) {
            displayName = "this staff member";
        }

        new MaterialAlertDialogBuilder(this)
                .setTitle("Delete Staff")
                .setMessage("Are you sure you want to delete " + displayName + "? This action cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> deleteStaff())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteStaff() {
        if (companyKey == null || empId == null) {
            Toast.makeText(this, "Error: Company or Staff ID missing", Toast.LENGTH_SHORT).show();
            return;
        }

        btnDeleteStaff.setEnabled(false);
        btnDeleteStaff.setText("Deleting...");

        DatabaseReference staffRef = databaseReference
                .child("Companies")
                .child(companyKey)
                .child("Employees")
                .child(empId);

        staffRef.removeValue()
                .addOnSuccessListener(aVoid -> {
                    String displayName = etName.getText().toString().trim();
                    if (TextUtils.isEmpty(displayName)) {
                        displayName = "Staff";
                    }
                    Toast.makeText(this, displayName + " deleted successfully", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnDeleteStaff.setEnabled(true);
                    btnDeleteStaff.setText("Delete Staff");
                    Toast.makeText(this, "Failed to delete: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}