package com.example.staffattendance.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.HistoryModel;
import com.example.staffattendance.R;
import com.example.staffattendance.utils.SessionManager;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<HistoryModel> historyList;
    private Context context;
    private SessionManager sessionManager;
    private DatabaseReference attendanceRef;

    public interface OnMenuClickListener {
        void onEditClick(HistoryModel model);
        void onDeleteClick(HistoryModel model);
    }

    private OnMenuClickListener menuClickListener;

    public HistoryAdapter(List<HistoryModel> historyList) {
        this.historyList = historyList;
    }

    public void setOnMenuClickListener(OnMenuClickListener listener) {
        this.menuClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        sessionManager = new SessionManager(context);

        // Initialize Firebase reference
        String companyKey = sessionManager.getCompanyKey();
        if (companyKey != null && !companyKey.isEmpty()) {
            attendanceRef = FirebaseDatabase.getInstance()
                    .getReference("Companies")
                    .child(companyKey)
                    .child("Attendance");
        }

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HistoryModel model = historyList.get(position);

        // Set employee name
        if (model.getEmployeeName() != null && !model.getEmployeeName().isEmpty()) {
            holder.tvEmployeeName.setText(model.getEmployeeName());
            // Set profile letter (first character of name)
            String firstLetter = model.getEmployeeName().substring(0, 1).toUpperCase();
            holder.tvProfileLetter.setText(firstLetter);
        } else {
            holder.tvEmployeeName.setText("Unknown");
            holder.tvProfileLetter.setText("?");
        }

        // Set department/domain
        if (model.getDepartment() != null && !model.getDepartment().isEmpty()) {
            holder.tvDomain.setText(model.getDepartment());
        } else {
            holder.tvDomain.setText("--");
        }

        // Set date
        if (model.getDate() != null && !model.getDate().isEmpty()) {
            holder.tvDate.setText(formatDateDisplay(model.getDate()));
        } else {
            holder.tvDate.setText("--");
        }

        // Set check-in time
        if (model.getCheckIn() != null && !model.getCheckIn().isEmpty() &&
                !model.getCheckIn().equals("--:--")) {
            holder.tvCheckIn.setText(formatTimeDisplay(model.getCheckIn()));
        } else {
            holder.tvCheckIn.setText("--:--");
        }

        // Set check-out time
        if (model.getCheckOut() != null && !model.getCheckOut().isEmpty() &&
                !model.getCheckOut().equals("--:--")) {
            holder.tvCheckOut.setText(formatTimeDisplay(model.getCheckOut()));
        } else {
            holder.tvCheckOut.setText("--:--");
        }

        // Determine status - UPDATED FOR LEAVE SUPPORT
        String status = determineStatusFromModel(model);
        holder.tvStatus.setText(status);

        // Update status badge color and status chip
        updateStatusUI(holder, status, model);

        // Calculate and set duration
        String duration = calculateDuration(model.getCheckIn(), model.getCheckOut(), model);
        holder.tvDuration.setText(duration);

        // Set up menu button click listener
        holder.btnMenu.setOnClickListener(v -> showPopupMenu(v, model, position));
    }

    private String determineStatusFromModel(HistoryModel model) {
        // First check if it's a leave
        if (model.isOnLeave()) {
            String leaveStatus = model.getLeaveStatus().toUpperCase();
            if (leaveStatus.equals("PENDING")) {
                return "LEAVE (Pending)";
            } else if (leaveStatus.equals("APPROVED")) {
                return "LEAVE (Approved)";
            } else if (leaveStatus.equals("REJECTED")) {
                return "LEAVE (Rejected)";
            }
            return "LEAVE";
        }

        // Existing logic for attendance status
        if (model.getStatus() != null && !model.getStatus().isEmpty()) {
            String status = model.getStatus().toUpperCase();
            if (status.equals("PRESENT") && model.isLate()) {
                return "LATE";
            }
            return status;
        }

        // Determine from check-in/check-out
        if (model.getCheckIn() != null && !model.getCheckIn().isEmpty() &&
                !model.getCheckIn().equals("--:--")) {
            if (isLateCheckIn(model.getCheckIn())) {
                return "LATE";
            }
            return "PRESENT";
        }

        return "ABSENT";
    }

    private boolean isLateCheckIn(String checkInTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date checkIn = sdf.parse(checkInTime);
            Date lateThreshold = sdf.parse("09:30");

            if (checkIn != null && lateThreshold != null) {
                return checkIn.after(lateThreshold);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void updateStatusUI(ViewHolder holder, String status, HistoryModel model) {
        int badgeColor;
        int chipBgColor;
        int chipTextColor;

        // Check if it's leave status
        if (status.toUpperCase().contains("LEAVE")) {
            if (status.contains("Pending")) {
                badgeColor = android.graphics.Color.parseColor("#D69E2E"); // Yellow/Orange
                chipBgColor = android.graphics.Color.parseColor("#FEFCBF");
                chipTextColor = android.graphics.Color.parseColor("#744210");
            } else if (status.contains("Approved")) {
                badgeColor = android.graphics.Color.parseColor("#38A169"); // Green
                chipBgColor = android.graphics.Color.parseColor("#F0FFF4");
                chipTextColor = android.graphics.Color.parseColor("#276749");
            } else if (status.contains("Rejected")) {
                badgeColor = android.graphics.Color.parseColor("#E53E3E"); // Red
                chipBgColor = android.graphics.Color.parseColor("#FED7D7");
                chipTextColor = android.graphics.Color.parseColor("#9B2C2C");
            } else {
                badgeColor = android.graphics.Color.parseColor("#4299E1"); // Blue for leave
                chipBgColor = android.graphics.Color.parseColor("#EBF8FF");
                chipTextColor = android.graphics.Color.parseColor("#2C5282");
            }
        } else {
            // Regular attendance status
            switch (status) {
                case "PRESENT":
                    badgeColor = android.graphics.Color.parseColor("#38A169"); // Green
                    chipBgColor = android.graphics.Color.parseColor("#F0FFF4");
                    chipTextColor = android.graphics.Color.parseColor("#276749");
                    break;

                case "LATE":
                    badgeColor = android.graphics.Color.parseColor("#D69E2E"); // Yellow/Orange
                    chipBgColor = android.graphics.Color.parseColor("#FEFCBF");
                    chipTextColor = android.graphics.Color.parseColor("#744210");
                    break;

                case "ABSENT":
                    badgeColor = android.graphics.Color.parseColor("#E53E3E"); // Red
                    chipBgColor = android.graphics.Color.parseColor("#FED7D7");
                    chipTextColor = android.graphics.Color.parseColor("#9B2C2C");
                    break;

                default:
                    badgeColor = android.graphics.Color.parseColor("#A0AEC0"); // Gray
                    chipBgColor = android.graphics.Color.parseColor("#F7FAFC");
                    chipTextColor = android.graphics.Color.parseColor("#4A5568");
                    break;
            }
        }

        // Update status badge
        holder.tvStatusBadge.setTextColor(badgeColor);

        // Update status chip
        holder.cardStatus.setCardBackgroundColor(chipBgColor);
        holder.tvStatus.setTextColor(chipTextColor);
    }

    private String calculateDuration(String checkIn, String checkOut, HistoryModel model) {
        // If it's a leave, show leave type
        if (model.isOnLeave()) {
            String leaveType = model.getLeaveType();
            if (leaveType != null && !leaveType.isEmpty()) {
                return "Leave • " + leaveType;
            }
            return "Leave";
        }

        if (checkIn == null || checkOut == null ||
                checkIn.isEmpty() || checkOut.isEmpty() ||
                checkIn.equals("--:--") || checkOut.equals("--:--")) {
            return "-- • --";
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date inTime = sdf.parse(checkIn);
            Date outTime = sdf.parse(checkOut);

            if (inTime != null && outTime != null) {
                long diff = outTime.getTime() - inTime.getTime();
                if (diff < 0) {
                    return "-- • --"; // Invalid time range
                }

                long hours = diff / (60 * 60 * 1000);
                long minutes = (diff % (60 * 60 * 1000)) / (60 * 1000);

                // Determine if regular (8+ hours) or short
                String type = (hours >= 8) ? "Regular" : "Short";
                return String.format(Locale.getDefault(), "%dh %02dm • %s", hours, minutes, type);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "-- • --";
    }

    private String formatDateDisplay(String dateStr) {
        try {
            // Try to parse date from your model format (assuming yyyy-MM-dd)
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault());

            Date date = inputFormat.parse(dateStr);
            return outputFormat.format(date);
        } catch (ParseException e) {
            // If parsing fails, return original string
            return dateStr;
        }
    }

    private String formatTimeDisplay(String timeStr) {
        try {
            // Parse 24-hour format
            SimpleDateFormat inputFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());

            Date time = inputFormat.parse(timeStr);
            return outputFormat.format(time);
        } catch (ParseException e) {
            // Return as-is if already in AM/PM format
            return timeStr;
        }
    }

    private void showPopupMenu(View view, HistoryModel model, int position) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        popupMenu.getMenuInflater().inflate(R.menu.employee_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.action_edit) {
                if (menuClickListener != null) {
                    menuClickListener.onEditClick(model);
                }
                return true;
            } else if (itemId == R.id.action_delete) {
                showDeleteConfirmation(model, position);
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    private void showDeleteConfirmation(HistoryModel model, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Record")
                .setMessage("Are you sure you want to delete this attendance record?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteFromDatabase(model, position);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteFromDatabase(HistoryModel model, int position) {
        String companyKey = sessionManager.getCompanyKey();
        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(context, "Company information not found", Toast.LENGTH_SHORT).show();
            return;
        }

        String date = model.getDate();
        String employeeId = model.getEmployeeId();

        if (date == null || date.isEmpty() || employeeId == null || employeeId.isEmpty()) {
            Toast.makeText(context, "Cannot delete: Missing data", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference deleteRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Attendance")
                .child(date)
                .child(employeeId);

        deleteRef.removeValue()
                .addOnSuccessListener(aVoid -> {
                    // Remove from local list
                    if (position < historyList.size()) {
                        historyList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, historyList.size() - position);
                        Toast.makeText(context, "Record deleted successfully", Toast.LENGTH_SHORT).show();
                    }

                    // Also delete from leaves if it's a leave record
                    if (model.isOnLeave()) {
                        deleteLeaveFromDatabase(model);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(context, "Failed to delete: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void deleteLeaveFromDatabase(HistoryModel model) {
        String companyKey = sessionManager.getCompanyKey();
        String employeeId = model.getEmployeeId();
        String date = model.getDate();

        if (companyKey == null || employeeId == null || date == null) {
            return;
        }

        // Find the leave that covers this date
        DatabaseReference leavesRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Leaves")
                .child(employeeId);

        leavesRef.addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                for (com.google.firebase.database.DataSnapshot leaveSnapshot : snapshot.getChildren()) {
                    String startDate = leaveSnapshot.child("startDate").getValue(String.class);
                    String endDate = leaveSnapshot.child("endDate").getValue(String.class);
                    String leaveType = leaveSnapshot.child("leaveType").getValue(String.class);

                    // Check if this date falls within the leave range
                    if (startDate != null && endDate != null) {
                        try {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                            Date start = sdf.parse(startDate);
                            Date end = sdf.parse(endDate);
                            Date current = sdf.parse(date);

                            if (current != null && start != null && end != null &&
                                    !current.before(start) && !current.after(end)) {

                                // Also remove leave status from Attendance for this date
                                DatabaseReference attendanceDateRef = FirebaseDatabase.getInstance()
                                        .getReference("Companies")
                                        .child(companyKey)
                                        .child("Attendance")
                                        .child(date)
                                        .child(employeeId);

                                // Remove leave fields
                                attendanceDateRef.child("leaveStatus").removeValue();
                                attendanceDateRef.child("leaveType").removeValue();
                                attendanceDateRef.child("leaveReason").removeValue();

                                Toast.makeText(context, "Leave status removed for " + date, Toast.LENGTH_SHORT).show();
                                break;
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                // Handle error
            }
        });
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    public void updateList(List<HistoryModel> newList) {
        this.historyList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvProfileLetter, tvEmployeeName, tvDomain, tvDate,
                tvCheckIn, tvCheckOut, tvStatus, tvDuration, tvStatusBadge;
        CardView cardStatus;
        ImageButton btnMenu;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize all views from XML
            tvProfileLetter = itemView.findViewById(R.id.tvProfileLetter);
            tvEmployeeName = itemView.findViewById(R.id.tvEmployeeName);
            tvDomain = itemView.findViewById(R.id.tvDomain);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvCheckIn = itemView.findViewById(R.id.tvCheckIn);
            tvCheckOut = itemView.findViewById(R.id.tvCheckOut);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvDuration = itemView.findViewById(R.id.tvDuration);
            tvStatusBadge = itemView.findViewById(R.id.tvStatusBadge);
            cardStatus = itemView.findViewById(R.id.cardStatus);
            btnMenu = itemView.findViewById(R.id.btnMenu);
        }
    }
}