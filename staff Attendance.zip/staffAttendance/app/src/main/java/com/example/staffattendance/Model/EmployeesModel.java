package com.example.staffattendance.Model;

public class EmployeesModel {

    // Firebase key (PHONE)
    private String key;

    // Company
    private String companyKey;

    // Employee
    private String empId;
    private String name;
    private String email;
    private String phone;
    private String role;
    private String joiningDate;
    private String address;
    private String profileImageBase64;
    private String status;
    private String department; // ADDED THIS FIELD

    // Login
    private String password;
    private boolean firstLogin;

    public EmployeesModel() { }

    /* ========= GETTERS & SETTERS ========= */

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
        this.phone = key;
    }

    public String getCompanyKey() {
        return companyKey;
    }

    public void setCompanyKey(String companyKey) {
        this.companyKey = companyKey;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
        this.key = phone;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProfileImageBase64() {
        return profileImageBase64;
    }

    public void setProfileImageBase64(String profileImageBase64) {
        this.profileImageBase64 = profileImageBase64;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDepartment() { // ADDED THIS METHOD
        return department;
    }

    public void setDepartment(String department) { // ADDED THIS METHOD
        this.department = department;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(boolean firstLogin) {
        this.firstLogin = firstLogin;
    }
}