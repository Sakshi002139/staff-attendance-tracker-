package com.example.staffattendance.Model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HistoryModel {
    private String id;
    private String employeeId;
    private String employeeName;
    private String department;
    private String checkIn;
    private String checkOut;
    private String status;
    private String date;
    private String finalStatus;
    private long punchInTimestamp;
    private long punchOutTimestamp;

    // Employee details fields
    private String email;
    private String phone;
    private String photoUrl;

    // Additional info fields
    private String shiftType;
    private String notes;
    private boolean isLate;
    private boolean isEarlyOut;

    // Leave-related fields - ADDED
    private String leaveStatus;
    private String leaveType;
    private String leaveReason;

    // Empty constructor for Firebase
    public HistoryModel() {
        this.id = "";
        this.employeeId = "";
        this.employeeName = "";
        this.department = "";
        this.checkIn = "";
        this.checkOut = "";
        this.status = "PENDING"; // Default status
        this.date = "";
        this.finalStatus = "";
        this.punchInTimestamp = 0;
        this.punchOutTimestamp = 0;

        this.email = "";
        this.phone = "";
        this.photoUrl = "";

        this.shiftType = "Regular";
        this.notes = "";
        this.isLate = false;
        this.isEarlyOut = false;

        // Leave fields initialization - ADDED
        this.leaveStatus = "";
        this.leaveType = "";
        this.leaveReason = "";
    }

    // Constructor with parameters
    public HistoryModel(String id, String employeeId, String employeeName, String department,
                        String checkIn, String checkOut, String status, String date,
                        String finalStatus, long punchInTimestamp, long punchOutTimestamp,
                        String email, String phone, String photoUrl,
                        String shiftType, String notes, boolean isLate,
                        boolean isEarlyOut) {
        this.id = id;
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.department = department;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.status = status != null ? status : "PENDING";
        this.date = date;
        this.finalStatus = finalStatus;
        this.punchInTimestamp = punchInTimestamp;
        this.punchOutTimestamp = punchOutTimestamp;

        this.email = email;
        this.phone = phone;
        this.photoUrl = photoUrl;

        this.shiftType = shiftType;
        this.notes = notes;
        this.isLate = isLate;
        this.isEarlyOut = isEarlyOut;

        // Leave fields initialization - ADDED
        this.leaveStatus = "";
        this.leaveType = "";
        this.leaveReason = "";
    }

    // ==================== Getters and Setters ====================

    public String getId() {
        return id != null ? id : "";
    }

    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    public String getEmployeeId() {
        return employeeId != null ? employeeId : "";
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId != null ? employeeId : "";
    }

    public String getEmployeeName() {
        return employeeName != null ? employeeName : "Unknown";
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName != null ? employeeName : "";
    }

    public String getDepartment() {
        return department != null ? department : "N/A";
    }

    public void setDepartment(String department) {
        this.department = department != null ? department : "";
    }

    public String getCheckIn() {
        return checkIn != null ? checkIn : "--:--";
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = checkIn != null ? checkIn : "";
    }

    public String getCheckOut() {
        return checkOut != null ? checkOut : "--:--";
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = checkOut != null ? checkOut : "";
    }

    public String getStatus() {
        return status != null ? status : "PENDING";
    }

    public void setStatus(String status) {
        this.status = status != null ? status : "PENDING";
    }

    public String getDate() {
        return date != null ? date : "";
    }

    public void setDate(String date) {
        this.date = date != null ? date : "";
    }

    public String getFinalStatus() {
        return finalStatus != null ? finalStatus : "";
    }

    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus != null ? finalStatus : "";
    }

    public long getPunchInTimestamp() {
        return punchInTimestamp;
    }

    public void setPunchInTimestamp(long punchInTimestamp) {
        this.punchInTimestamp = punchInTimestamp;
    }

    public long getPunchOutTimestamp() {
        return punchOutTimestamp;
    }

    public void setPunchOutTimestamp(long punchOutTimestamp) {
        this.punchOutTimestamp = punchOutTimestamp;
    }

    // ==================== Employee Details ====================

    public String getEmail() {
        return email != null ? email : "";
    }

    public void setEmail(String email) {
        this.email = email != null ? email : "";
    }

    public String getPhone() {
        return phone != null ? phone : "";
    }

    public void setPhone(String phone) {
        this.phone = phone != null ? phone : "";
    }

    public String getPhotoUrl() {
        return photoUrl != null ? photoUrl : "";
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl != null ? photoUrl : "";
    }

    // ==================== Additional Info ====================

    public String getShiftType() {
        return shiftType != null ? shiftType : "Regular";
    }

    public void setShiftType(String shiftType) {
        this.shiftType = shiftType != null ? shiftType : "";
    }

    public String getNotes() {
        return notes != null ? notes : "";
    }

    public void setNotes(String notes) {
        this.notes = notes != null ? notes : "";
    }

    public boolean isLate() {
        return isLate;
    }

    public void setLate(boolean isLate) {
        this.isLate = isLate;
    }

    public boolean isEarlyOut() {
        return isEarlyOut;
    }

    public void setEarlyOut(boolean isEarlyOut) {
        this.isEarlyOut = isEarlyOut;
    }

    // ==================== Leave-related Getters and Setters - ADDED ====================

    public String getLeaveStatus() {
        return leaveStatus != null ? leaveStatus : "";
    }

    public void setLeaveStatus(String leaveStatus) {
        this.leaveStatus = leaveStatus != null ? leaveStatus : "";
    }

    public String getLeaveType() {
        return leaveType != null ? leaveType : "";
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType != null ? leaveType : "";
    }

    public String getLeaveReason() {
        return leaveReason != null ? leaveReason : "";
    }

    public void setLeaveReason(String leaveReason) {
        this.leaveReason = leaveReason != null ? leaveReason : "";
    }

    // ==================== HELPER METHODS ====================

    public boolean hasCompleteAttendance() {
        return !getCheckIn().isEmpty() && !getCheckIn().equals("--:--") &&
                !getCheckOut().isEmpty() && !getCheckOut().equals("--:--");
    }

    public boolean hasCheckedIn() {
        return !getCheckIn().isEmpty() && !getCheckIn().equals("--:--");
    }

    public boolean hasCheckedOut() {
        return !getCheckOut().isEmpty() && !getCheckOut().equals("--:--");
    }

    // FIXED: Better isPresent() method
    public boolean isPresent() {
        String currentStatus = getStatus().toUpperCase();
        return "PRESENT".equals(currentStatus) ||
                "LATE".equals(currentStatus) ||
                "PRESENT".equals(getFinalStatus().toUpperCase()) ||
                hasCheckedIn(); // If they checked in, they're present
    }

    // FIXED: isLate() already exists as boolean, so rename this
    public boolean isLateStatus() {
        return "LATE".equals(getStatus().toUpperCase()) || isLate();
    }

    // FIXED: Better isAbsent() method
    public boolean isAbsent() {
        String currentStatus = getStatus().toUpperCase();
        String finalStat = getFinalStatus().toUpperCase();

        return "ABSENT".equals(currentStatus) ||
                "ABSENT".equals(finalStat) ||
                (!hasCheckedIn() && !"PENDING".equals(currentStatus));
    }

    // ADDED: Helper method to check if on leave
    public boolean isOnLeave() {
        String currentStatus = getStatus().toUpperCase();
        return currentStatus.contains("LEAVE") ||
                (leaveStatus != null && !leaveStatus.isEmpty());
    }

    public String getDisplayStatus() {
        // First check if it's leave
        if (isOnLeave()) {
            if (leaveStatus != null && !leaveStatus.isEmpty()) {
                if (leaveStatus.equalsIgnoreCase("PENDING")) {
                    return "LEAVE (Pending)";
                } else if (leaveStatus.equalsIgnoreCase("APPROVED")) {
                    return "LEAVE (Approved)";
                } else if (leaveStatus.equalsIgnoreCase("REJECTED")) {
                    return "LEAVE (Rejected)";
                }
            }
            return "LEAVE";
        }

        if (isLate()) {
            return "LATE";
        }
        if (isEarlyOut) {
            return "EARLY OUT";
        }

        String currentStatus = getStatus().toUpperCase();
        if ("PENDING".equals(currentStatus)) {
            // Determine based on check-in time
            if (hasCheckedIn()) {
                return "PRESENT";
            } else {
                return "ABSENT";
            }
        }
        return getStatus();
    }

    @Override
    public String toString() {
        return "HistoryModel{" +
                "id='" + id + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", employeeName='" + employeeName + '\'' +
                ", department='" + department + '\'' +
                ", checkIn='" + checkIn + '\'' +
                ", checkOut='" + checkOut + '\'' +
                ", status='" + status + '\'' +
                ", date='" + date + '\'' +
                ", finalStatus='" + finalStatus + '\'' +
                ", punchInTimestamp=" + punchInTimestamp +
                ", punchOutTimestamp=" + punchOutTimestamp +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", photoUrl='" + photoUrl + '\'' +
                ", shiftType='" + shiftType + '\'' +
                ", notes='" + notes + '\'' +
                ", isLate=" + isLate +
                ", isEarlyOut=" + isEarlyOut +
                ", leaveStatus='" + leaveStatus + '\'' + // ADDED
                ", leaveType='" + leaveType + '\'' + // ADDED
                ", leaveReason='" + leaveReason + '\'' + // ADDED
                '}';
    }
}