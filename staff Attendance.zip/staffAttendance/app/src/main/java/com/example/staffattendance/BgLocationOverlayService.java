package com.example.staffattendance;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class BgLocationOverlayService extends Service {
    public BgLocationOverlayService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}