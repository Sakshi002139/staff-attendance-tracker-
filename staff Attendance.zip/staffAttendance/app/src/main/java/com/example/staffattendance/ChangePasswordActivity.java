package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.staffattendance.databinding.ActivityChangePasswordBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

public class ChangePasswordActivity extends AppCompatActivity {

    // UI Components
    private Toolbar toolbar;
    private TextView tvStepIndicator, tvStepTitle, tvStepSubtitle;
    private View step1Indicator, step2Indicator, step3Indicator;
    private View layoutPhoneNumber, layoutOtp, layoutNewPassword;
    private TextInputLayout tilPhoneNumber, tilOtp, tilNewPassword, tilConfirmPassword;
    private TextInputEditText etPhoneNumber, etOtp, etNewPassword, etConfirmPassword;
    private MaterialButton btnBack, btnNext, btnResendOtp;

    // Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    // OTP Verification
    private String mVerificationId;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private CountDownTimer countDownTimer;

    // User data
    private String companyKey, empId, userName, phoneNumber;

    // Steps: 1-EnterPhone, 2-OTP, 3-NewPassword
    private int currentStep = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        // Initialize all views
        initializeViews();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Get user data from Intent
        getIntentData();

        // Setup toolbar
        setupToolbar();

        // Setup click listeners
        setupClickListeners();

        // Setup text watchers
        setupTextWatchers();

        // Initialize UI for step 1
        showStep(1);
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);

        // Progress indicators
        tvStepIndicator = findViewById(R.id.tvStepIndicator);
        tvStepTitle = findViewById(R.id.tvStepTitle);
        tvStepSubtitle = findViewById(R.id.tvStepSubtitle);

        // Step indicators (if you have them in XML, otherwise remove)
        // step1Indicator = findViewById(R.id.step1Indicator);
        // step2Indicator = findViewById(R.id.step2Indicator);
        // step3Indicator = findViewById(R.id.step3Indicator);

        // Step layouts
        layoutPhoneNumber = findViewById(R.id.layoutPhoneNumber);
        layoutOtp = findViewById(R.id.layoutOtp);
        layoutNewPassword = findViewById(R.id.layoutNewPassword);

        // Input fields
        tilPhoneNumber = findViewById(R.id.tilPhoneNumber);
        tilOtp = findViewById(R.id.tilOtp);
        tilNewPassword = findViewById(R.id.tilNewPassword);
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword);

        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etOtp = findViewById(R.id.etOtp);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);

        // Buttons
        btnBack = findViewById(R.id.btnBack);
        btnNext = findViewById(R.id.btnNext);
        btnResendOtp = findViewById(R.id.btnResendOtp);
    }

    private void getIntentData() {
        Intent intent = getIntent();
        companyKey = intent.getStringExtra("companyKey");
        empId = intent.getStringExtra("empId");
        userName = intent.getStringExtra("userName");

        if (companyKey == null || empId == null) {
            Toast.makeText(this, "User information missing", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Fetch user's phone number from database
        fetchUserPhoneNumber();
    }

    private void fetchUserPhoneNumber() {
        mDatabase.child("Companies").child(companyKey)
                .child("Employees").child(empId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            phoneNumber = snapshot.child("phone").getValue(String.class);
                            if (phoneNumber != null && !phoneNumber.isEmpty()) {
                                // Pre-fill phone number if available
                                etPhoneNumber.setText(formatPhoneNumber(phoneNumber));
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Continue with empty phone
                    }
                });
    }

    private String formatPhoneNumber(String phone) {
        if (phone == null || phone.isEmpty()) return "";

        if (phone.startsWith("+")) {
            return phone;
        }
        // Assuming Indian numbers - adjust for your country
        if (phone.length() == 10) {
            return "+91" + phone;
        }
        return phone;
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Change Password");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupClickListeners() {
        // Next button (for all steps)
        btnNext.setOnClickListener(v -> {
            if (currentStep == 1) {
                verifyPhoneNumber();
            } else if (currentStep == 2) {
                verifyOTP();
            } else if (currentStep == 3) {
                changePassword();
            }
        });

        // Resend OTP
        btnResendOtp.setOnClickListener(v -> resendOTP());

        // Back button handling
        btnBack.setOnClickListener(v -> handleBackPress());
    }

    private void setupTextWatchers() {
        // Phone number text watcher
        etPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tilPhoneNumber.setError(null);
                btnNext.setEnabled(s.length() >= 10);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // OTP input text watcher
        etOtp.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tilOtp.setError(null);
                if (s.length() == 6) {
                    verifyOTP();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Password text watchers
        etNewPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tilNewPassword.setError(null);
                validatePasswords();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        etConfirmPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tilConfirmPassword.setError(null);
                validatePasswords();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void validatePasswords() {
        String newPass = etNewPassword.getText().toString().trim();
        String confirmPass = etConfirmPassword.getText().toString().trim();

        if (newPass.length() >= 6 && confirmPass.length() >= 6) {
            if (!newPass.equals(confirmPass)) {
                tilConfirmPassword.setError("Passwords do not match");
                btnNext.setEnabled(false);
            } else {
                tilConfirmPassword.setError(null);
                btnNext.setEnabled(true);
            }
        } else {
            btnNext.setEnabled(false);
        }
    }

    // ============ STEP HANDLING ============
    private void showStep(int step) {
        currentStep = step;

        // Hide all layouts first
        layoutPhoneNumber.setVisibility(View.GONE);
        layoutOtp.setVisibility(View.GONE);
        layoutNewPassword.setVisibility(View.GONE);

        // Show the current step layout
        switch (step) {
            case 1:
                showStep1();
                break;
            case 2:
                showStep2();
                break;
            case 3:
                showStep3();
                break;
        }

        // Update button visibility
        btnBack.setVisibility(step > 1 ? View.VISIBLE : View.GONE);
    }

    private void showStep1() {
        tvStepIndicator.setText("Step 1 of 3");
        tvStepTitle.setText("Verify Phone Number");
        tvStepSubtitle.setText("Enter your registered phone number to receive OTP");

        layoutPhoneNumber.setVisibility(View.VISIBLE);

        btnNext.setText("Send OTP");
        btnNext.setEnabled(false);

        // Focus on phone number field
        etPhoneNumber.requestFocus();
    }

    private void showStep2() {
        tvStepIndicator.setText("Step 2 of 3");
        tvStepTitle.setText("Enter OTP");
        tvStepSubtitle.setText("Enter the 6-digit code sent to your phone");

        layoutOtp.setVisibility(View.VISIBLE);

        btnNext.setText("Verify OTP");
        btnNext.setEnabled(false);
        btnResendOtp.setEnabled(false);

        // Focus on OTP field
        etOtp.requestFocus();

        // Start countdown for resend OTP
        startResendTimer();
    }

    private void showStep3() {
        tvStepIndicator.setText("Step 3 of 3");
        tvStepTitle.setText("Set New Password");
        tvStepSubtitle.setText("Create a strong password for your account");

        layoutNewPassword.setVisibility(View.VISIBLE);

        btnNext.setText("Change Password");
        btnNext.setEnabled(false);

        // Focus on new password field
        etNewPassword.requestFocus();
    }

    // ============ PHONE VERIFICATION ============
    private void verifyPhoneNumber() {
        String phone = etPhoneNumber.getText().toString().trim();

        if (phone.length() < 10) {
            tilPhoneNumber.setError("Enter valid phone number");
            return;
        }

        // Format phone number with country code
        String formattedPhone = formatPhoneNumber(phone);

        btnNext.setEnabled(false);
        btnNext.setText("Sending OTP...");

        // Start phone verification
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(formattedPhone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
                                // Auto-verification (e.g., device is in same SIM)
                                signInWithPhoneAuthCredential(credential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                btnNext.setEnabled(true);
                                btnNext.setText("Send OTP");

                                String errorMessage = "Verification failed: ";
                                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                                    errorMessage += "Invalid phone number";
                                } else {
                                    errorMessage += e.getMessage();
                                }

                                Toast.makeText(ChangePasswordActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String verificationId,
                                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                                mVerificationId = verificationId;
                                mResendToken = token;

                                // Move to OTP step
                                showStep(2);
                            }
                        })
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void verifyOTP() {
        String otp = etOtp.getText().toString().trim();

        if (otp.length() != 6) {
            tilOtp.setError("Enter 6-digit OTP");
            return;
        }

        if (mVerificationId == null) {
            Toast.makeText(this, "Verification ID not found", Toast.LENGTH_SHORT).show();
            return;
        }

        btnNext.setEnabled(false);
        btnNext.setText("Verifying...");

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, otp);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // OTP verified successfully
                            showStep(3);
                        } else {
                            // Verification failed
                            btnNext.setEnabled(true);
                            btnNext.setText("Verify OTP");

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                tilOtp.setError("Invalid OTP code");
                            } else {
                                Toast.makeText(ChangePasswordActivity.this,
                                        "OTP verification failed: " + task.getException().getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }

    private void resendOTP() {
        String phone = etPhoneNumber.getText().toString().trim();
        String formattedPhone = formatPhoneNumber(phone);

        if (formattedPhone.isEmpty()) {
            return;
        }

        btnResendOtp.setEnabled(false);
        btnResendOtp.setText("Resending...");

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(formattedPhone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
                                signInWithPhoneAuthCredential(credential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                btnResendOtp.setEnabled(true);
                                btnResendOtp.setText("Resend OTP");
                                Toast.makeText(ChangePasswordActivity.this,
                                        "Failed to resend OTP: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String verificationId,
                                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                                mVerificationId = verificationId;
                                mResendToken = token;

                                btnResendOtp.setEnabled(false);
                                Toast.makeText(ChangePasswordActivity.this,
                                        "OTP resent successfully",
                                        Toast.LENGTH_SHORT).show();

                                // Restart timer
                                if (countDownTimer != null) {
                                    countDownTimer.cancel();
                                }
                                startResendTimer();
                            }
                        })
                        .setForceResendingToken(mResendToken)
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void startResendTimer() {
        countDownTimer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                btnResendOtp.setText("Resend OTP (" + millisUntilFinished / 1000 + "s)");
            }

            @Override
            public void onFinish() {
                btnResendOtp.setText("Resend OTP");
                btnResendOtp.setEnabled(true);
            }
        }.start();
    }

    // ============ CHANGE PASSWORD ============
    private void changePassword() {
        String newPassword = etNewPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // Validate passwords
        if (newPassword.length() < 6) {
            tilNewPassword.setError("Password must be at least 6 characters");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            tilConfirmPassword.setError("Passwords do not match");
            return;
        }

        btnNext.setEnabled(false);
        btnNext.setText("Changing Password...");

        // Update password in Firebase Realtime Database
        updatePasswordInDatabase(newPassword);
    }

    private void updatePasswordInDatabase(String newPassword) {
        mDatabase.child("Companies").child(companyKey)
                .child("Employees").child(empId)
                .child("password")
                .setValue(newPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Password updated successfully
                        showSuccessDialog();
                    } else {
                        btnNext.setEnabled(true);
                        btnNext.setText("Change Password");
                        Toast.makeText(this,
                                "Failed to update password: " + task.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showSuccessDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Password Changed")
                .setMessage("Your password has been changed successfully!")
                .setPositiveButton("OK", (dialog, which) -> {
                    // Navigate back to profile
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    // ============ NAVIGATION HANDLING ============
    private void handleBackPress() {
        if (currentStep > 1) {
            showStep(currentStep - 1);
        } else {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (currentStep > 1) {
            handleBackPress();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }
}