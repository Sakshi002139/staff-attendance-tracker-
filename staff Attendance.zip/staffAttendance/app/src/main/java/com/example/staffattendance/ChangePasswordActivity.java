package com.example.staffattendance;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

public class ChangePasswordActivity extends AppCompatActivity {

    private TextInputEditText etNewPassword, etConfirmPassword;
    private MaterialButton btnChangePassword;

    private String companyKey;
    private String empId;

    private DatabaseReference empRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        companyKey = getIntent().getStringExtra("companyKey");
        empId = getIntent().getStringExtra("empId");

        if (TextUtils.isEmpty(companyKey) || TextUtils.isEmpty(empId)) {
            Toast.makeText(this, "Invalid request", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        empRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Employees")
                .child(empId);

        initViews();
        setListeners();
    }

    private void initViews() {
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnChangePassword = findViewById(R.id.btnChangePassword);
    }

    private void setListeners() {
        btnChangePassword.setOnClickListener(v -> validateAndChangePassword());
    }

    private void validateAndChangePassword() {

        String newPassword =
                etNewPassword.getText() != null
                        ? etNewPassword.getText().toString().trim()
                        : "";

        String confirmPassword =
                etConfirmPassword.getText() != null
                        ? etConfirmPassword.getText().toString().trim()
                        : "";

        if (TextUtils.isEmpty(newPassword)) {
            etNewPassword.setError("Enter new password");
            etNewPassword.requestFocus();
            return;
        }

        if (newPassword.length() < 6) {
            etNewPassword.setError("Minimum 6 characters");
            etNewPassword.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(confirmPassword)) {
            etConfirmPassword.setError("Confirm password");
            etConfirmPassword.requestFocus();
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            etConfirmPassword.requestFocus();
            return;
        }

        btnChangePassword.setEnabled(false);
        btnChangePassword.setText("Updating...");

        updatePasswordInDatabase(newPassword);
    }

    private void updatePasswordInDatabase(String newPassword) {

        // FIXED: Hash the password before storing
        String hashedPassword = hashPassword(newPassword);

        Map<String, Object> updates = new HashMap<>();
        updates.put("password", hashedPassword);
        updates.put("firstLogin", false);

        empRef.updateChildren(updates)
                .addOnSuccessListener(v -> {

                    Toast.makeText(this,
                            "Password updated successfully",
                            Toast.LENGTH_SHORT).show();

                    goToDashboard();
                })
                .addOnFailureListener(e -> {
                    btnChangePassword.setEnabled(true);
                    btnChangePassword.setText("Change Password");

                    Toast.makeText(this,
                            "Failed to update password",
                            Toast.LENGTH_SHORT).show();
                });
    }

    // FIXED: Add hashPassword method
    private String hashPassword(String password) {

        try {

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes());

            StringBuilder sb = new StringBuilder();

            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();

        } catch (Exception e) {
            return password;
        }
    }

    private void goToDashboard() {
        startActivity(
                new android.content.Intent(
                        this,
                        EmployeeDashboardActivity.class
                )
        );
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this,
                "Please change password to continue",
                Toast.LENGTH_SHORT).show();
    }
}