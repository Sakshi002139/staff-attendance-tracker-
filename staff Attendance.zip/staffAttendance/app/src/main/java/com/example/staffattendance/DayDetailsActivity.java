package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.staffattendance.utils.FirebaseManager;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DayDetailsActivity extends AppCompatActivity {

    private static final String TAG = "DayDetailsActivity";

    // UI Components
    private TextView txtDate;
    private ImageView btnRefresh, btnBack;
    private Button btnAbsent, btnHalfDay, btnPresent, btnWeekOff, btnHoliday;
    private Button btnPaidLeave, btnHalfLeave, btnUnpaidLeave;
    private TextView btnAddPunch;
    private EditText etNote;
    private Button btnSave;

    // Data
    private String selectedDate, employeeId, companyKey, employeeName;
    private String currentStatus = "PENDING";
    private String punchInTime = null;
    private String punchOutTime = null;
    private String leaveReason = null;
    private String leaveStatus = null;
    private String leaveType = null;

    // Firebase
    private DatabaseReference attendanceRef;
    private DatabaseReference employeeRef;
    private FirebaseManager firebaseManager;

    // Date Format
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private final SimpleDateFormat displayDateFormat = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_details);

        Log.d(TAG, "=== DAY DETAILS ACTIVITY STARTED ===");

        initializeViews();
        getIntentData();
        setupFirebase();
        setupClickListeners();
        loadExistingData();
    }

    private void initializeViews() {
        txtDate = findViewById(R.id.txtDate);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnBack = findViewById(R.id.btnBack); // Added back button

        // Attendance buttons
        btnAbsent = findViewById(R.id.btnAbsent);
        btnHalfDay = findViewById(R.id.btnHalfDay);
        btnPresent = findViewById(R.id.btnPresent);
        btnWeekOff = findViewById(R.id.btnWeekOff);
        btnHoliday = findViewById(R.id.btnHoliday);

        // Leave buttons
        btnPaidLeave = findViewById(R.id.btnPaidLeave);
        btnHalfLeave = findViewById(R.id.btnHalfLeave);
        btnUnpaidLeave = findViewById(R.id.btnUnpaidLeave);

        // Other views
        btnAddPunch = findViewById(R.id.btnAddPunch);
        etNote = findViewById(R.id.etNote);
        btnSave = findViewById(R.id.btnSave);
    }

    private void getIntentData() {
        selectedDate = getIntent().getStringExtra("date");
        currentStatus = getIntent().getStringExtra("status");
        employeeId = getIntent().getStringExtra("employeeId");
        companyKey = getIntent().getStringExtra("companyKey");
        employeeName = getIntent().getStringExtra("employeeName");

        // Also get additional data if available
        if (getIntent().hasExtra("punchIn")) {
            punchInTime = getIntent().getStringExtra("punchIn");
        }
        if (getIntent().hasExtra("punchOut")) {
            punchOutTime = getIntent().getStringExtra("punchOut");
        }
        if (getIntent().hasExtra("leaveReason")) {
            leaveReason = getIntent().getStringExtra("leaveReason");
        }
        if (getIntent().hasExtra("leaveStatus")) {
            leaveStatus = getIntent().getStringExtra("leaveStatus");
        }
        if (getIntent().hasExtra("leaveType")) {
            leaveType = getIntent().getStringExtra("leaveType");
        }

        Log.d(TAG, "Intent Data:");
        Log.d(TAG, "  selectedDate: " + selectedDate);
        Log.d(TAG, "  currentStatus: " + currentStatus);
        Log.d(TAG, "  employeeId: " + employeeId);
        Log.d(TAG, "  companyKey: " + companyKey);

        // Set date display
        try {
            Date date = dateFormat.parse(selectedDate);
            if (date != null) {
                txtDate.setText(displayDateFormat.format(date));
            } else {
                txtDate.setText(selectedDate);
            }
        } catch (ParseException e) {
            txtDate.setText(selectedDate);
        }
    }

    private void setupFirebase() {
        firebaseManager = FirebaseManager.getInstance();

        if (companyKey != null && employeeId != null) {
            attendanceRef = firebaseManager.getCompanyAttendanceRef(companyKey).child(employeeId).child(selectedDate);
            employeeRef = firebaseManager.getCompanyEmployeesRef(companyKey).child(employeeId);
        } else {
            Log.e(TAG, "Missing companyKey or employeeId");
            Toast.makeText(this, "Error: Missing data", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setupClickListeners() {
        // Back button - Added
        btnBack.setOnClickListener(v -> onBackPressed());

        // Refresh button
        btnRefresh.setOnClickListener(v -> loadExistingData());

        // Attendance status buttons
        btnAbsent.setOnClickListener(v -> setStatus("ABSENT"));
        btnHalfDay.setOnClickListener(v -> setStatus("HALF_DAY"));
        btnPresent.setOnClickListener(v -> setStatus("PRESENT"));
        btnWeekOff.setOnClickListener(v -> setStatus("WEEK_OFF"));
        btnHoliday.setOnClickListener(v -> setStatus("HOLIDAY"));

        // Leave buttons
        btnPaidLeave.setOnClickListener(v -> showLeaveDialog("PAID", "Paid Leave"));
        btnHalfLeave.setOnClickListener(v -> showLeaveDialog("HALF_DAY", "Half Day Leave"));
        btnUnpaidLeave.setOnClickListener(v -> showLeaveDialog("UNPAID", "Unpaid Leave"));

        // Add punch button
        btnAddPunch.setOnClickListener(v -> showPunchDialog());

        // Save button
        btnSave.setOnClickListener(v -> saveData());

        // Date picker (optional - if you want to change date)
        txtDate.setOnClickListener(v -> showDatePickerDialog());
    }

    private void setStatus(String status) {
        currentStatus = status;

        // Clear leave data when setting attendance status
        leaveReason = null;
        leaveStatus = null;
        leaveType = null;
        etNote.setText("");

        // Reset button backgrounds to outline style
        resetButtonStyles();

        // Highlight selected button with light colors
        highlightSelectedButton(status);

        Toast.makeText(this, "Status set to: " + status, Toast.LENGTH_SHORT).show();
    }

    private void resetButtonStyles() {
        // Reset all buttons to default outline style (no color fill)
        btnAbsent.setBackgroundResource(R.drawable.bg_outline_red);
        btnHalfDay.setBackgroundResource(R.drawable.bg_outline_orange);
        btnPresent.setBackgroundResource(R.drawable.bg_outline_green);
        btnWeekOff.setBackgroundResource(R.drawable.bg_outline_gray);
        btnHoliday.setBackgroundResource(R.drawable.bg_outline_gray);
        btnPaidLeave.setBackgroundResource(R.drawable.bg_outline_purple);
        btnHalfLeave.setBackgroundResource(R.drawable.bg_outline_purple);
        btnUnpaidLeave.setBackgroundResource(R.drawable.bg_outline_blue);

        // Reset text colors to default
        btnAbsent.setTextColor(ContextCompat.getColor(this, R.color.red_error));
        btnHalfDay.setTextColor(ContextCompat.getColor(this, R.color.orange_warning));
        btnPresent.setTextColor(ContextCompat.getColor(this, R.color.green_success));
        btnWeekOff.setTextColor(ContextCompat.getColor(this, R.color.gray_default));
        btnHoliday.setTextColor(ContextCompat.getColor(this, R.color.gray_default));
        btnPaidLeave.setTextColor(ContextCompat.getColor(this, R.color.purple_primary));
        btnHalfLeave.setTextColor(ContextCompat.getColor(this, R.color.purple_primary));
        btnUnpaidLeave.setTextColor(ContextCompat.getColor(this, R.color.blue_info));
    }

    private void highlightSelectedButton(String status) {
        // Use light background colors with black text for better visibility
        switch (status) {
            case "ABSENT":
                btnAbsent.setBackgroundResource(R.drawable.bg_light_red);
                btnAbsent.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "HALF_DAY":
                btnHalfDay.setBackgroundResource(R.drawable.bg_light_orange);
                btnHalfDay.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "PRESENT":
                btnPresent.setBackgroundResource(R.drawable.bg_light_green);
                btnPresent.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "WEEK_OFF":
                btnWeekOff.setBackgroundResource(R.drawable.bg_light_gray);
                btnWeekOff.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "HOLIDAY":
                btnHoliday.setBackgroundResource(R.drawable.bg_light_gray);
                btnHoliday.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "LEAVE_PAID":
                btnPaidLeave.setBackgroundResource(R.drawable.bg_light_purple);
                btnPaidLeave.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "LEAVE_HALF":
                btnHalfLeave.setBackgroundResource(R.drawable.bg_light_purple);
                btnHalfLeave.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "LEAVE_UNPAID":
                btnUnpaidLeave.setBackgroundResource(R.drawable.bg_light_blue);
                btnUnpaidLeave.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            case "LEAVE_PENDING":
                // For pending leave, use a light yellow/orange with black text
                if ("PAID".equals(leaveType)) {
                    btnPaidLeave.setBackgroundResource(R.drawable.bg_light_orange);
                    btnPaidLeave.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                } else if ("HALF_DAY".equals(leaveType)) {
                    btnHalfLeave.setBackgroundResource(R.drawable.bg_light_orange);
                    btnHalfLeave.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                } else {
                    btnUnpaidLeave.setBackgroundResource(R.drawable.bg_light_orange);
                    btnUnpaidLeave.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                }
                break;
            case "WORKING":
                // Working status - light blue with black text
                btnPresent.setBackgroundResource(R.drawable.bg_light_blue);
                btnPresent.setTextColor(ContextCompat.getColor(this, android.R.color.black));
                break;
            default:
                // If status not recognized, do nothing
                break;
        }
    }

    private void showLeaveDialog(String leaveTypeStr, String title) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setTitle(title);

        // Set up the input
        final EditText input = new EditText(this);
        input.setHint("Enter reason for leave");
        input.setPadding(40, 20, 40, 20);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", (dialog, which) -> {
            String reason = input.getText().toString().trim();
            if (!TextUtils.isEmpty(reason)) {
                setLeaveStatus(leaveTypeStr, reason);
            } else {
                Toast.makeText(this, "Please enter a reason", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void setLeaveStatus(String leaveTypeStr, String reason) {
        // Reset attendance button styles
        resetButtonStyles();

        // Set leave data
        switch (leaveTypeStr) {
            case "PAID":
                currentStatus = "LEAVE_PAID";
                leaveType = "PAID";
                highlightSelectedButton("LEAVE_PAID");
                break;
            case "HALF_DAY":
                currentStatus = "LEAVE_HALF";
                leaveType = "HALF_DAY";
                highlightSelectedButton("LEAVE_HALF");
                break;
            case "UNPAID":
                currentStatus = "LEAVE_UNPAID";
                leaveType = "UNPAID";
                highlightSelectedButton("LEAVE_UNPAID");
                break;
        }

        leaveReason = reason;
        leaveStatus = "PENDING"; // Leave is pending approval
        etNote.setText(reason);

        Toast.makeText(this, "Leave request submitted", Toast.LENGTH_SHORT).show();
    }

    private void showPunchDialog() {
        String[] options = {"Punch In", "Punch Out", "Cancel"};

        new MaterialAlertDialogBuilder(this)
                .setTitle("Add Punch")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            addPunchIn();
                            break;
                        case 1:
                            addPunchOut();
                            break;
                        case 2:
                            dialog.dismiss();
                            break;
                    }
                })
                .show();
    }

    private void addPunchIn() {
        Calendar now = Calendar.getInstance();
        String currentTime = timeFormat.format(now.getTime());

        punchInTime = currentTime;

        // If this is a new punch in, set status to WORKING
        if (currentStatus.equals("PENDING") || currentStatus.equals("ABSENT")) {
            currentStatus = "WORKING";
            resetButtonStyles();
            highlightSelectedButton("WORKING");
        }

        updatePunchButtonText();
        Toast.makeText(this, "Punch In: " + currentTime, Toast.LENGTH_SHORT).show();
    }

    private void addPunchOut() {
        if (punchInTime == null) {
            Toast.makeText(this, "Please add Punch In first", Toast.LENGTH_SHORT).show();
            return;
        }

        Calendar now = Calendar.getInstance();
        String currentTime = timeFormat.format(now.getTime());

        punchOutTime = currentTime;

        // Calculate if it's full day, half day, etc.
        calculateStatusFromPunches();
        updatePunchButtonText();

        Toast.makeText(this, "Punch Out: " + currentTime, Toast.LENGTH_SHORT).show();
    }

    private void updatePunchButtonText() {
        if (punchInTime != null || punchOutTime != null) {
            String punchText = "";
            if (punchInTime != null) {
                punchText += "In: " + punchInTime;
            }
            if (punchOutTime != null) {
                if (!punchText.isEmpty()) punchText += " | ";
                punchText += "Out: " + punchOutTime;
            }
            btnAddPunch.setText(punchText);
        } else {
            btnAddPunch.setText("+ ADD PUNCH IN");
        }
    }

    private void calculateStatusFromPunches() {
        // This would need office timing rules from company settings
        // For now, set a simple status
        if (punchInTime != null && punchOutTime != null) {
            currentStatus = "PRESENT";
            resetButtonStyles();
            highlightSelectedButton("PRESENT");
        }
    }

    private void loadExistingData() {
        if (attendanceRef == null) return;

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading data...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        attendanceRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss();

                if (snapshot.exists()) {
                    Log.d(TAG, "Loading existing data for: " + selectedDate);

                    // Load punch data
                    String punchIn = snapshot.child("punchInTime").getValue(String.class);
                    String punchOut = snapshot.child("punchOutTime").getValue(String.class);

                    if (punchIn != null && !punchIn.equals("null")) {
                        punchInTime = punchIn;
                    }
                    if (punchOut != null && !punchOut.equals("null")) {
                        punchOutTime = punchOut;
                    }

                    // Load leave data
                    String lvStatus = snapshot.child("leaveStatus").getValue(String.class);
                    String lvReason = snapshot.child("leaveReason").getValue(String.class);
                    String lvType = snapshot.child("leaveType").getValue(String.class);

                    if (lvStatus != null && !lvStatus.isEmpty() && !lvStatus.equals("null")) {
                        leaveStatus = lvStatus;
                        leaveReason = lvReason;
                        leaveType = lvType;

                        if ("APPROVED".equals(lvStatus)) {
                            if ("PAID".equals(lvType)) {
                                currentStatus = "LEAVE_PAID";
                            } else if ("HALF_DAY".equals(lvType)) {
                                currentStatus = "LEAVE_HALF";
                            } else {
                                currentStatus = "LEAVE_UNPAID";
                            }
                        } else if ("PENDING".equals(lvStatus)) {
                            currentStatus = "LEAVE_PENDING";
                        }

                        if (lvReason != null && !lvReason.equals("null")) {
                            etNote.setText(lvReason);
                        }
                    }

                    // Load regular status
                    String status = snapshot.child("status").getValue(String.class);
                    if (status != null && !status.equals("null") &&
                            !status.equals("LEAVE_PENDING") && !status.startsWith("LEAVE_")) {
                        currentStatus = status;
                    }

                    // Update UI
                    updateUIFromLoadedData();

                    Toast.makeText(DayDetailsActivity.this, "Data loaded", Toast.LENGTH_SHORT).show();
                } else {
                    Log.d(TAG, "No existing data for this date");
                    // If no data, still update UI with any intent data
                    updateUIFromLoadedData();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Log.e(TAG, "Error loading data: " + error.getMessage());
                Toast.makeText(DayDetailsActivity.this,
                        "Error loading data: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateUIFromLoadedData() {
        // Highlight the appropriate button based on current status
        resetButtonStyles();

        if (currentStatus != null && !currentStatus.equals("null") && !currentStatus.isEmpty()) {
            highlightSelectedButton(currentStatus);
        }

        // Show punch times if available
        updatePunchButtonText();
    }

    private void saveData() {
        if (attendanceRef == null) {
            Toast.makeText(this, "Error: No database reference", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Saving...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        Map<String, Object> data = new HashMap<>();

        // Save note if entered
        String note = etNote.getText().toString().trim();
        if (!TextUtils.isEmpty(note)) {
            data.put("note", note);
        }

        // Save status
        if (currentStatus != null && !currentStatus.equals("null")) {
            data.put("status", currentStatus);
        }

        // Save punch data
        if (punchInTime != null && !punchInTime.equals("null")) {
            data.put("punchInTime", punchInTime);
            data.put("punchInTimestamp", System.currentTimeMillis());
        }

        if (punchOutTime != null && !punchOutTime.equals("null")) {
            data.put("punchOutTime", punchOutTime);
            data.put("punchOutTimestamp", System.currentTimeMillis());
        }

        // Save leave data
        if (leaveReason != null && !leaveReason.equals("null")) {
            data.put("leaveReason", leaveReason);
        }
        if (leaveStatus != null && !leaveStatus.equals("null")) {
            data.put("leaveStatus", leaveStatus);
        }
        if (leaveType != null && !leaveType.equals("null")) {
            data.put("leaveType", leaveType);
        }

        // Add timestamp
        data.put("lastUpdated", System.currentTimeMillis());
        data.put("updatedBy", "admin");

        attendanceRef.setValue(data)
                .addOnCompleteListener(task -> {
                    progressDialog.dismiss();
                    if (task.isSuccessful()) {
                        Toast.makeText(DayDetailsActivity.this,
                                "Data saved successfully", Toast.LENGTH_SHORT).show();

                        // Return to previous activity with result
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("date", selectedDate);
                        resultIntent.putExtra("status", currentStatus);
                        setResult(RESULT_OK, resultIntent);

                        finish();
                    } else {
                        String error = task.getException() != null ?
                                task.getException().getMessage() : "Unknown error";
                        Toast.makeText(DayDetailsActivity.this,
                                "Save failed: " + error, Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Save error: " + error);
                    }
                });
    }

    private void showDatePickerDialog() {
        try {
            Date currentDate = dateFormat.parse(selectedDate);
            Calendar calendar = Calendar.getInstance();
            if (currentDate != null) {
                calendar.setTime(currentDate);
            }

            DatePickerDialog dialog = new DatePickerDialog(
                    this,
                    (view, year, month, dayOfMonth) -> {
                        String newDate = String.format(Locale.US, "%04d-%02d-%02d",
                                year, month + 1, dayOfMonth);
                        selectedDate = newDate;

                        try {
                            Date date = dateFormat.parse(newDate);
                            txtDate.setText(displayDateFormat.format(date));
                        } catch (ParseException e) {
                            txtDate.setText(newDate);
                        }

                        // Reset data for new date
                        resetAllData();

                        // Reload data for new date
                        attendanceRef = firebaseManager.getCompanyAttendanceRef(companyKey)
                                .child(employeeId).child(selectedDate);
                        loadExistingData();
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            dialog.show();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void resetAllData() {
        currentStatus = "PENDING";
        punchInTime = null;
        punchOutTime = null;
        leaveReason = null;
        leaveStatus = null;
        leaveType = null;
        etNote.setText("");
        resetButtonStyles();
        btnAddPunch.setText("+ ADD PUNCH IN");
    }
}