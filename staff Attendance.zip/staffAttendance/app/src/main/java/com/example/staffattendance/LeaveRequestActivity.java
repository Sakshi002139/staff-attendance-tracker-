package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.staffattendance.Model.LeaveItem;
import com.example.staffattendance.utils.SessionManager;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LeaveRequestActivity extends AppCompatActivity {

    private EditText edtStartDate, edtEndDate, edtReason;
    private Spinner spinnerLeaveType;
    private Button btnSubmit;

    private SessionManager sessionManager;
    private String companyKey, empId;

    private Calendar startCalendar = Calendar.getInstance();
    private Calendar endCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_request);

        // Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Apply Leave");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        initViews();
        setupLeaveTypeSpinner();
        setupDatePickers();
        setupSession();
        setupSubmitButton();
    }

    private void initViews() {
        edtStartDate = findViewById(R.id.edtStartDate);
        edtEndDate = findViewById(R.id.edtEndDate);
        edtReason = findViewById(R.id.edtReason);
        spinnerLeaveType = findViewById(R.id.spinnerLeaveType);
        btnSubmit = findViewById(R.id.btnSubmit);
    }

    private void setupLeaveTypeSpinner() {
        String[] leaveTypes = {"Sick Leave", "Casual Leave", "Earned Leave",
                "Maternity Leave", "Paternity Leave", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, leaveTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerLeaveType.setAdapter(adapter);
    }

    private void setupDatePickers() {
        edtStartDate.setOnClickListener(v -> showDatePicker(startCalendar, edtStartDate, true));
        edtEndDate.setOnClickListener(v -> showDatePicker(endCalendar, edtEndDate, false));
    }

    private void showDatePicker(Calendar calendar, EditText editText, boolean isStartDate) {
        DatePickerDialog picker = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    editText.setText(sdf.format(calendar.getTime()));

                    if (isStartDate && !TextUtils.isEmpty(edtEndDate.getText())) validateDates();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        picker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

        if (!isStartDate && !TextUtils.isEmpty(edtStartDate.getText())) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date startDate = sdf.parse(edtStartDate.getText().toString());
                if (startDate != null) picker.getDatePicker().setMinDate(startDate.getTime());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        picker.show();
    }

    private void validateDates() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date startDate = sdf.parse(edtStartDate.getText().toString());
            Date endDate = TextUtils.isEmpty(edtEndDate.getText()) ? null :
                    sdf.parse(edtEndDate.getText().toString());

            if (endDate != null && endDate.before(startDate)) {
                Toast.makeText(this, "End date cannot be before start date", Toast.LENGTH_SHORT).show();
                edtEndDate.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupSession() {
        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();
        empId = sessionManager.getEmpId();

        if (TextUtils.isEmpty(companyKey) || TextUtils.isEmpty(empId)) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setupSubmitButton() {
        btnSubmit.setOnClickListener(v -> submitLeaveRequest());
    }

    private void submitLeaveRequest() {
        String startDate = edtStartDate.getText().toString().trim();
        String endDate = edtEndDate.getText().toString().trim();
        String reason = edtReason.getText().toString().trim();
        String leaveType = spinnerLeaveType.getSelectedItem().toString().trim();

        if (TextUtils.isEmpty(startDate)) {
            Toast.makeText(this, "Please select start date", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(leaveType)) {
            Toast.makeText(this, "Please select leave type", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(reason)) {
            Toast.makeText(this, "Please enter reason for leave", Toast.LENGTH_SHORT).show();
            return;
        }

        String finalEndDate = TextUtils.isEmpty(endDate) ? startDate : endDate;
        int days = calculateDays(startDate, finalEndDate);
        if (days <= 0) {
            Toast.makeText(this, "Invalid date range", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Use startDate as leaveId instead of push()
        String leaveId = startDate;

        LeaveItem leaveItem = new LeaveItem(
                leaveId,
                companyKey,
                empId,
                leaveType,
                startDate,
                finalEndDate,
                reason,
                String.valueOf(days),
                "PENDING",
                System.currentTimeMillis()
        );

        DatabaseReference leaveRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Leaves")
                .child(empId)
                .child(leaveId); // ✅ key = startDate

        leaveRef.setValue(leaveItem)
                .addOnSuccessListener(unused -> {
                    saveLeaveToAttendanceDates(startDate, finalEndDate, leaveItem);
                    Toast.makeText(this, "Leave request submitted successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private int calculateDays(String startDateStr, String endDateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);
            long diff = endDate.getTime() - startDate.getTime();
            return (int) (diff / (1000 * 60 * 60 * 24)) + 1;
        } catch (Exception e) {
            return 1;
        }
    }

    private void saveLeaveToAttendanceDates(String startDateStr, String endDateStr, LeaveItem leaveItem) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);

            while (!calendar.getTime().after(endDate)) {
                String currentDate = sdf.format(calendar.getTime());

                DatabaseReference dateRef = FirebaseDatabase.getInstance()
                        .getReference("Companies")
                        .child(companyKey)
                        .child("Attendance")
                        .child(empId)
                        .child(currentDate);

                dateRef.child("leaveReason").setValue(leaveItem.getReason());
                dateRef.child("leaveStatus").setValue(leaveItem.getStatus());
                dateRef.child("leaveType").setValue(leaveItem.getLeaveType());

                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
