package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditEmployeeActivity extends AppCompatActivity {

    private ShapeableImageView imgProfile;
    private TextInputEditText etName, etEmail, etPhone,
            etRole, etDepartment, etJoiningDate, etAddress;
    private MaterialButton btnUpdate;

    private DatabaseReference rootRef;
    private String companyKey, employeeKey;
    private String profileBase64 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_employee);

        companyKey = getIntent().getStringExtra("companyKey");
        employeeKey = getIntent().getStringExtra("employeeKey");

        if (companyKey == null || employeeKey == null) {
            Toast.makeText(this, "Invalid employee", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        rootRef = FirebaseDatabase.getInstance().getReference();

        initViews();
        loadEmployeeData();

        etJoiningDate.setOnClickListener(v -> showDatePicker());
        btnUpdate.setOnClickListener(v -> updateEmployee());
    }

    /* ================= INIT ================= */

    private void initViews() {
        imgProfile = findViewById(R.id.imgProfile);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etRole = findViewById(R.id.etRole);
        etDepartment = findViewById(R.id.edtDepartment);
        etJoiningDate = findViewById(R.id.etJoiningDate);
        etAddress = findViewById(R.id.etAddress);
        btnUpdate = findViewById(R.id.btnUpdate);
    }

    /* ================= LOAD EMPLOYEE ================= */

    private void loadEmployeeData() {

        rootRef.child("Companies")
                .child(companyKey)
                .child("employees") // ✅ FIXED (lowercase)
                .child(employeeKey)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (!snapshot.exists()) {
                            Toast.makeText(
                                    EditEmployeeActivity.this,
                                    "Employee not found",
                                    Toast.LENGTH_SHORT
                            ).show();
                            finish();
                            return;
                        }

                        etName.setText(snapshot.child("name").getValue(String.class));
                        etEmail.setText(snapshot.child("email").getValue(String.class));
                        etPhone.setText(snapshot.child("phone").getValue (String.class));
                        etRole.setText(snapshot.child("role").getValue(String.class));
                        etDepartment.setText(snapshot.child("department").getValue(String.class));
                        etJoiningDate.setText(snapshot.child("joiningDate").getValue(String.class));
                        etAddress.setText(snapshot.child("address").getValue(String.class));

                        profileBase64 = snapshot.child("profileImageBase64")
                                .getValue(String.class);

                        // ✅ SHOW PROFILE IMAGE
                        if (profileBase64 != null && !profileBase64.isEmpty()) {
                            byte[] decoded = Base64.decode(profileBase64, Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(
                                    decoded, 0, decoded.length
                            );
                            imgProfile.setImageBitmap(bitmap);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(
                                EditEmployeeActivity.this,
                                error.getMessage(),
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });
    }

    /* ================= UPDATE EMPLOYEE ================= */

    private void updateEmployee() {

        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        if (name.isEmpty() || phone.length() != 10) {
            Toast.makeText(
                    this,
                    "Enter valid name & phone",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("name", name);
        updateMap.put("email", etEmail.getText().toString().trim());
        updateMap.put("phone", phone);
        updateMap.put("role", etRole.getText().toString().trim());
        updateMap.put("department", etDepartment.getText().toString().trim());
        updateMap.put("joiningDate", etJoiningDate.getText().toString().trim());
        updateMap.put("address", etAddress.getText().toString().trim());
        updateMap.put("profileImageBase64", profileBase64);

        rootRef.child("Companies")
                .child(companyKey)
                .child("employees") // ✅ FIXED
                .child(employeeKey)
                .updateChildren(updateMap)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(
                            EditEmployeeActivity.this,
                            "Employee Updated Successfully",
                            Toast.LENGTH_SHORT
                    ).show();
                    finish();
                });
    }

    /* ================= DATE PICKER ================= */

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(
                this,
                (view, y, m, d) ->
                        etJoiningDate.setText(d + "/" + (m + 1) + "/" + y),
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        ).show();
    }
}
