package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class EmployeeDashboardActivity extends AppCompatActivity {

    private SessionManager sessionManager;

    private String companyKey;
    private String companyName;
    private String empId;
    private String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_dashboard);

        sessionManager = new SessionManager(this);

        getData();

        if (companyKey == null || empId == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_LONG).show();
            goToLogin();
            return;
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        if (findViewById(R.id.fragment_container) == null) {
            Toast.makeText(this, "Layout error: fragment container missing", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (savedInstanceState == null) {
            loadFragment(new EmployeeHomeFragment());
        }

        bottomNavigationView.setOnItemSelectedListener(item -> {

            Fragment fragment;

            int id = item.getItemId();

            if (id == R.id.nav_home) {
                fragment = new EmployeeHomeFragment();
            }
            else if (id == R.id.nav_attendance) {
                fragment = new AttendanceFragment();
            }
            else if (id == R.id.nav_profile) {
                fragment = new EmployeeProfileFragment();
            }
            else {
                return false;
            }

            loadFragment(fragment);
            return true;
        });
    }

    private void getData() {

        companyKey = getIntent().getStringExtra("companyKey");
        companyName = getIntent().getStringExtra("companyName");
        empId = getIntent().getStringExtra("empId");
        userName = getIntent().getStringExtra("userName");

        if (companyKey == null) companyKey = sessionManager.getCompanyKey();
        if (companyName == null) companyName = sessionManager.getCompanyName();
        if (empId == null) empId = sessionManager.getEmpId();
        if (userName == null) userName = sessionManager.getUserName();

        if (!TextUtils.isEmpty(companyName)) {
            sessionManager.setCompanyName(companyName);
        }

        if (!TextUtils.isEmpty(userName)) {
            sessionManager.saveUserData(userName, sessionManager.getUserEmail());
        }
    }

    private void loadFragment(@NonNull Fragment fragment) {

        Bundle bundle = new Bundle();
        bundle.putString("companyKey", companyKey);
        bundle.putString("companyName", companyName);
        bundle.putString("empId", empId);
        bundle.putString("userName", userName);

        fragment.setArguments(bundle);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    // Getter methods for fragments

    public String getCompanyKey() {
        return companyKey;
    }

    public String getCompanyName() {
        return companyName != null ? companyName : "";
    }

    public String getEmpId() {
        return empId;
    }

    public String getUserName() {
        return userName != null ? userName : "";
    }

    // =========================
    // LOGOUT FUNCTION
    // =========================

    public void logoutEmployee() {

        if (!TextUtils.isEmpty(companyKey) && !TextUtils.isEmpty(empId)) {

            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("Companies")
                    .child(companyKey)
                    .child("Employees")
                    .child(empId);

            Map<String, Object> updates = new HashMap<>();
            updates.put("accountStatus", "inactive");
            updates.put("status", "INACTIVE");

            ref.updateChildren(updates);
        }

        sessionManager.logoutUser();

        goToLogin();
    }

    private void goToLogin() {

        Intent intent = new Intent(EmployeeDashboardActivity.this, EmployeeLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    // Confirm exit

    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {

        super.onBackPressed();
        new AlertDialog.Builder(this)
                .setTitle("Exit App")
                .setMessage("Do you want to logout?")
                .setPositiveButton("Logout", (dialog, which) -> logoutEmployee())
                .setNegativeButton("Cancel", null)
                .show();
    }
}