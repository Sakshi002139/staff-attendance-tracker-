package com.example.staffattendance;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class EmployeeDashboardActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private String companyKey, companyName, empId, userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_dashboard);

        sessionManager = new SessionManager(this);

        getData();

        if (companyKey == null || empId == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        // ✅ ADD: Check if fragment container exists
        if (findViewById(R.id.fragment_container) == null) {
            Toast.makeText(this, "Layout error: fragment container not found", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (savedInstanceState == null) {
            loadFragment(new EmployeeHomeFragment());
        }

        bottomNavigationView.setOnItemSelectedListener(item -> {

            Fragment fragment;

            int id = item.getItemId();
            if (id == R.id.nav_home) {
                fragment = new EmployeeHomeFragment();
            } else if (id == R.id.nav_attendance) {
                fragment = new AttendanceFragment();
            } else if (id == R.id.nav_profile) {
                fragment = new EmployeeProfileFragment();
            } else {
                return false;
            }

            loadFragment(fragment);
            return true;
        });
    }

    private void getData() {
        companyKey = getIntent().getStringExtra("companyKey");
        companyName = getIntent().getStringExtra("companyName");
        empId = getIntent().getStringExtra("empId");
        userName = getIntent().getStringExtra("userName");

        if (companyKey == null) companyKey = sessionManager.getCompanyKey();
        if (companyName == null) companyName = sessionManager.getCompanyName();
        if (empId == null) empId = sessionManager.getEmpId();
        if (userName == null) userName = sessionManager.getUserName();

        // Save to session manager for future use
        if (companyName != null && !companyName.isEmpty()) {
            sessionManager.setCompanyName(companyName);
        }
        if (userName != null && !userName.isEmpty()) {
            sessionManager.saveUserData(userName, sessionManager.getUserEmail());
        }
    }

    private void loadFragment(@NonNull Fragment fragment) {
        // ✅ FIXED: Change from fragment_container to fragmentContainer
        // Also pass data to fragment via Bundle
        Bundle bundle = new Bundle();
        bundle.putString("companyKey", companyKey);
        bundle.putString("companyName", companyName);
        bundle.putString("empId", empId);
        bundle.putString("userName", userName);
        fragment.setArguments(bundle);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment) // ✅ CHANGED HERE
                .commit();
    }

    // ✅ ADDED: Getter methods for fragments to access data
    public String getCompanyKey() {
        return companyKey;
    }

    public String getCompanyName() {
        return companyName != null ? companyName : "";
    }

    public String getEmpId() {
        return empId;
    }

    public String getUserName() {
        return userName != null ? userName : "";
    }
}