package com.example.staffattendance.Model;

public class AttendanceReportItem {
    private String date;
    private String day;
    private String status;
    private String punchIn;
    private String punchOut;
    private String totalHours;
    private String overtime;
    private String leaveReason;
    private String leaveType;      // New field for leave type
    private String leaveStatus;    // New field for leave status
    private String employeeName;   // New field for employee name (for all employees report)
    private String employeeId;      // New field for employee ID

    // Constructors
    public AttendanceReportItem() {
    }

    public AttendanceReportItem(String date, String day, String status) {
        this.date = date;
        this.day = day;
        this.status = status;
    }

    // Getters and Setters
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPunchIn() {
        return punchIn;
    }

    public void setPunchIn(String punchIn) {
        this.punchIn = punchIn;
    }

    public String getPunchOut() {
        return punchOut;
    }

    public void setPunchOut(String punchOut) {
        this.punchOut = punchOut;
    }

    public String getTotalHours() {
        return totalHours;
    }

    public void setTotalHours(String totalHours) {
        this.totalHours = totalHours;
    }

    public String getOvertime() {
        return overtime;
    }

    public void setOvertime(String overtime) {
        this.overtime = overtime;
    }

    public String getLeaveReason() {
        return leaveReason;
    }

    public void setLeaveReason(String leaveReason) {
        this.leaveReason = leaveReason;
    }

    // New getters and setters for leaveType
    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    // New getters and setters for leaveStatus
    public String getLeaveStatus() {
        return leaveStatus;
    }

    public void setLeaveStatus(String leaveStatus) {
        this.leaveStatus = leaveStatus;
    }

    // New getters and setters for employeeName
    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    // New getters and setters for employeeId
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    // Helper method to check if this is a leave record
    public boolean isLeave() {
        return leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null") && !leaveStatus.equals("NONE");
    }

    // Helper method to check if leave is approved
    public boolean isLeaveApproved() {
        return "APPROVED".equalsIgnoreCase(leaveStatus);
    }

    // Helper method to check if leave is pending
    public boolean isLeavePending() {
        return "PENDING".equalsIgnoreCase(leaveStatus);
    }

    // Helper method to get display status with employee context
    public String getDisplayStatus() {
        if (isLeave()) {
            if (isLeaveApproved()) {
                return "LEAVE (Approved)";
            } else if (isLeavePending()) {
                return "LEAVE (Pending)";
            } else {
                return "LEAVE";
            }
        }
        return status != null ? status : "UNKNOWN";
    }

    @Override
    public String toString() {
        return "AttendanceReportItem{" +
                "date='" + date + '\'' +
                ", day='" + day + '\'' +
                ", status='" + status + '\'' +
                ", punchIn='" + punchIn + '\'' +
                ", punchOut='" + punchOut + '\'' +
                ", totalHours='" + totalHours + '\'' +
                ", overtime='" + overtime + '\'' +
                ", leaveReason='" + leaveReason + '\'' +
                ", leaveType='" + leaveType + '\'' +
                ", leaveStatus='" + leaveStatus + '\'' +
                ", employeeName='" + employeeName + '\'' +
                ", employeeId='" + employeeId + '\'' +
                '}';
    }
}