package com.example.staffattendance;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.staffattendance.utils.SessionManager;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.*;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.database.*;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EmployeeHomeFragment extends Fragment {

    private static final int CAMERA_PERMISSION = 101;
    private static final int LOCATION_PERMISSION = 102;
    private static final int REQUEST_CHECK_SETTINGS = 200;

    private PreviewView previewView;
    private ImageButton btnSwitchCamera;
    private MaterialButton btnPunch;
    private Toolbar toolbar;
    private TextView tvTime, tvDate;

    private ImageCapture imageCapture;
    private ExecutorService cameraExecutor;
    private int lensFacing = CameraSelector.LENS_FACING_FRONT;

    private String companyKey, companyName, empId;

    private DatabaseReference attendanceRef;
    private ValueEventListener punchListener;
    private Handler timeHandler;

    private FusedLocationProviderClient fusedLocationClient;
    private Location currentLocation;
    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {

        View view = inflater.inflate(R.layout.fragment_employee_home, container, false);

        // Views
        previewView = view.findViewById(R.id.previewView);
        btnSwitchCamera = view.findViewById(R.id.btnSwitchCamera);
        btnPunch = view.findViewById(R.id.btnPunch);
        toolbar = view.findViewById(R.id.toolbar);
        tvTime = view.findViewById(R.id.tvTime);
        tvDate = view.findViewById(R.id.tvDate);

        // Initialize SessionManager
        sessionManager = new SessionManager(requireActivity());

        // FIXED: Get data from Activity instead of Intent
        if (getActivity() != null && getActivity() instanceof EmployeeDashboardActivity) {
            EmployeeDashboardActivity activity = (EmployeeDashboardActivity) getActivity();
            companyKey = activity.getCompanyKey();
            companyName = activity.getCompanyName();
            empId = activity.getEmpId();
        }

        // If still null, try to get from SessionManager
        if (companyKey == null || empId == null) {
            companyKey = sessionManager.getCompanyKey();
            empId = sessionManager.getEmpId();
            companyName = sessionManager.getCompanyName();
        }

        if (companyKey == null || empId == null) {
            Toast.makeText(getContext(), "Error: Missing employee information", Toast.LENGTH_SHORT).show();
            return view;
        }

        // Toolbar setup
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity != null) {
            activity.setSupportActionBar(toolbar);
            if (activity.getSupportActionBar() != null) {
                activity.getSupportActionBar().setTitle(companyName != null ? companyName : "Attendance");
            }
        }
        toolbar.setTitleTextColor(ContextCompat.getColor(requireContext(), android.R.color.white));

        cameraExecutor = Executors.newSingleThreadExecutor();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        startLiveClock();
        observePunchStatus();
        checkCameraPermission();
        checkLocationPermission();

        btnSwitchCamera.setOnClickListener(v -> {
            lensFacing = (lensFacing == CameraSelector.LENS_FACING_FRONT)
                    ? CameraSelector.LENS_FACING_BACK
                    : CameraSelector.LENS_FACING_FRONT;
            startCamera();
        });

        btnPunch.setOnClickListener(v -> checkLocationBeforePunch());

        return view;
    }

    /* ---------------- CLOCK ---------------- */
    private void startLiveClock() {
        timeHandler = new Handler(Looper.getMainLooper());
        timeHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!isAdded()) return;
                tvTime.setText(new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()));
                tvDate.setText(new SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault()).format(new Date()));
                timeHandler.postDelayed(this, 1000);
            }
        });
    }

    /* ---------------- PERMISSIONS ---------------- */
    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
        }
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                Toast.makeText(getContext(), "Camera permission required", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, we can proceed
                Toast.makeText(getContext(), "Location permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Location permission required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /* ---------------- LOCATION WITH SYSTEM DIALOG ---------------- */
    private void checkLocationBeforePunch() {
        // Check if location permission is granted
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getContext(), "Location permission required", Toast.LENGTH_SHORT).show();
            return;
        }

        LocationRequest locationRequest = LocationRequest.create()
                .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                .setInterval(10000)
                .setFastestInterval(5000);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest)
                .setAlwaysShow(true); // Show dialog even if location is already on

        SettingsClient client = LocationServices.getSettingsClient(requireActivity());
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());

        task.addOnSuccessListener(locationSettingsResponse -> {
            // Location is ON, get location and punch
            getCurrentLocationAndPunch();
        });

        task.addOnFailureListener(e -> {
            if (e instanceof ResolvableApiException) {
                try {
                    // Show the dialog by calling startResolutionForResult()
                    ResolvableApiException resolvable = (ResolvableApiException) e;
                    resolvable.startResolutionForResult(
                            requireActivity(),
                            REQUEST_CHECK_SETTINGS
                    );
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(getContext(), "Error opening location settings", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Location must be ON to punch", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            if (resultCode == AppCompatActivity.RESULT_OK) {
                // User turned on location, proceed with punch
                getCurrentLocationAndPunch();
            } else {
                Toast.makeText(getContext(), "Location must be ON to punch", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getCurrentLocationAndPunch() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        currentLocation = location;
                        // Get city/address from location
                        getCityFromLocation(location);
                    } else {
                        // If getCurrentLocation returns null, try getLastLocation
                        fusedLocationClient.getLastLocation()
                                .addOnSuccessListener(lastLocation -> {
                                    if (lastLocation != null) {
                                        currentLocation = lastLocation;
                                        getCityFromLocation(lastLocation);
                                    } else {
                                        Toast.makeText(getContext(), "Unable to get location. Try again.", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Failed to get location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void getCityFromLocation(Location location) {
        new Thread(() -> {
            try {
                Geocoder geocoder = new Geocoder(requireContext(), Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(
                        location.getLatitude(),
                        location.getLongitude(),
                        1
                );

                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    String city = address.getLocality();
                    String fullAddress = address.getAddressLine(0);

                    // Save location info
                    saveLocationInfo(city, fullAddress, location.getLatitude(), location.getLongitude());

                    // Now capture photo
                    requireActivity().runOnUiThread(() -> {
                        capturePhoto();
                    });
                } else {
                    requireActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Unable to get address from location", Toast.LENGTH_SHORT).show();
                    });
                }

            } catch (IOException e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "Error getting address", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void saveLocationInfo(String city, String address, double lat, double lng) {
        if (companyKey == null || empId == null) {
            Toast.makeText(getContext(), "Cannot save location: Missing information", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save to SharedPreferences
        requireActivity().getSharedPreferences("OfficeLocationPrefs", 0)
                .edit()
                .putString("city", city)
                .putString("address", address)
                .putString("lat", String.valueOf(lat))
                .putString("lng", String.valueOf(lng))
                .putString("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()))
                .apply();

        // Save to Firebase
        DatabaseReference locationRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("EmployeeLocations")
                .child(empId);

        String timestampKey = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault()).format(new Date());

        Map<String, Object> locationData = new HashMap<>();
        locationData.put("city", city);
        locationData.put("address", address);
        locationData.put("latitude", lat);
        locationData.put("longitude", lng);
        locationData.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
        locationData.put("date", new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));

        locationRef.child(timestampKey).setValue(locationData)
                .addOnSuccessListener(aVoid -> {
                    // Successfully saved to Firebase
                })
                .addOnFailureListener(e -> {
                    // Failed to save to Firebase
                });
    }

    /* ---------------- CAMERA ---------------- */
    private void startCamera() {
        if (!isAdded()) return;

        ListenableFuture<ProcessCameraProvider> future =
                ProcessCameraProvider.getInstance(requireContext());

        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                provider.unbindAll();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build();

                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(lensFacing)
                        .build();

                provider.bindToLifecycle(
                        getViewLifecycleOwner(),
                        cameraSelector,
                        preview,
                        imageCapture
                );

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Error starting camera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(requireContext()));
    }

    private void capturePhoto() {
        if (imageCapture == null) {
            Toast.makeText(getContext(), "Camera not ready", Toast.LENGTH_SHORT).show();
            return;
        }

        File file = new File(
                requireContext().getExternalFilesDir(null),
                "ATT_" + System.currentTimeMillis() + ".jpg"
        );

        ImageCapture.OutputFileOptions outputFileOptions =
                new ImageCapture.OutputFileOptions.Builder(file).build();

        imageCapture.takePicture(
                outputFileOptions,
                ContextCompat.getMainExecutor(requireContext()),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults output) {
                        if (isAdded()) {
                            saveAttendance(Uri.fromFile(file));
                        }
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException e) {
                        e.printStackTrace();
                        if (isAdded()) {
                            Toast.makeText(getContext(), "Error capturing photo: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    /* ---------------- ATTENDANCE ---------------- */
    private void saveAttendance(Uri uri) {
        if (!isAdded()) return;

        if (companyKey == null || empId == null) {
            Toast.makeText(getContext(), "Cannot save attendance: Missing information", Toast.LENGTH_SHORT).show();
            return;
        }

        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Attendance")
                .child(empId)
                .child(date);

        double lat = currentLocation != null ? currentLocation.getLatitude() : 0.0;
        double lng = currentLocation != null ? currentLocation.getLongitude() : 0.0;

        ref.get().addOnSuccessListener(snapshot -> {
            Map<String, Object> map = new HashMap<>();

            if (!snapshot.exists() || !snapshot.hasChild("punchInTime")) {
                // Punch In
                map.put("punchInTime", time);
                map.put("photoIn", uri.toString());
                map.put("latIn", lat);
                map.put("lngIn", lng);
                map.put("status", "PUNCHED IN");
                map.put("punchInTimestamp", System.currentTimeMillis());
                ref.updateChildren(map);
                Toast.makeText(getContext(), "Punch In successful!", Toast.LENGTH_SHORT).show();
            } else if (!snapshot.hasChild("punchOutTime")) {
                // Punch Out
                map.put("punchOutTime", time);
                map.put("photoOut", uri.toString());
                map.put("latOut", lat);
                map.put("lngOut", lng);
                map.put("finalStatus", "PRESENT");
                map.put("punchOutTimestamp", System.currentTimeMillis());
                ref.updateChildren(map);
                Toast.makeText(getContext(), "Punch Out successful!", Toast.LENGTH_SHORT).show();
            } else {
                // Already completed
                Toast.makeText(getContext(), "Today's attendance already completed", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    /* ---------------- UI STATUS ---------------- */
    private void observePunchStatus() {
        if (companyKey == null || empId == null) {
            Toast.makeText(getContext(), "Cannot observe punch status: Missing information", Toast.LENGTH_SHORT).show();
            return;
        }

        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        attendanceRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Attendance")
                .child(empId)
                .child(date);

        punchListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;

                if (!snapshot.exists()) {
                    btnPunch.setText("PUNCH IN");
                    btnPunch.setBackgroundTintList(
                            ContextCompat.getColorStateList(requireContext(), R.color.green)
                    );
                    btnPunch.setEnabled(true);
                } else {
                    if (snapshot.hasChild("punchOutTime")) {
                        btnPunch.setText("COMPLETED");
                        btnPunch.setBackgroundTintList(
                                ContextCompat.getColorStateList(requireContext(), R.color.gray_xdark)
                        );
                        btnPunch.setEnabled(false);
                    } else {
                        btnPunch.setText("PUNCH OUT");
                        btnPunch.setBackgroundTintList(
                                ContextCompat.getColorStateList(requireContext(), R.color.red)
                        );
                        btnPunch.setEnabled(true);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        attendanceRef.addValueEventListener(punchListener);
    }

    /* ---------------- CLEANUP ---------------- */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (timeHandler != null) {
            timeHandler.removeCallbacksAndMessages(null);
        }
        if (attendanceRef != null && punchListener != null) {
            attendanceRef.removeEventListener(punchListener);
        }
        if (cameraExecutor != null) {
            cameraExecutor.shutdown();
        }
    }
}