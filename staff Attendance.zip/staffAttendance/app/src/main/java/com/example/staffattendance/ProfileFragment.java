package com.example.staffattendance;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {

    private static final String TAG = "ProfileFragment";

    // UI Components
    private CircleImageView imgProfile;
    private TextView txtAdminName, txtRole, txtLastLogin;
    private TextView txtEmail, txtPhone;
    private TextView txtCompanyName, txtCompanyId, txtEmployeeCount;
    private MaterialCardView btnSetTime, btnReports;
    private MaterialButton btnLogout;
    private com.google.android.material.floatingactionbutton.FloatingActionButton btnChangePhoto;

    // Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;
    private SessionManager sessionManager;

    // Permissions
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int CAMERA_REQUEST = 2;
    private static final int CAMERA_PERMISSION_REQUEST = 101;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        storageReference = FirebaseStorage.getInstance().getReference();
        sessionManager = new SessionManager(requireContext());

        // Initialize UI components
        initializeViews(view);

        // Setup click listeners
        setupClickListeners();

        // Load profile data
        loadProfileData();

        return view;
    }

    private void initializeViews(View view) {
        imgProfile = view.findViewById(R.id.imgProfile);
        txtAdminName = view.findViewById(R.id.txtAdminName);
        txtRole = view.findViewById(R.id.txtRole);
        txtLastLogin = view.findViewById(R.id.txtLastLogin);
        txtEmail = view.findViewById(R.id.txtEmail);
        txtCompanyName = view.findViewById(R.id.txtCompanyName);
        txtEmployeeCount = view.findViewById(R.id.txtEmployeeCount);
        btnSetTime = view.findViewById(R.id.btnSetTime);
        btnReports = view.findViewById(R.id.btnReports);
        btnLogout = view.findViewById(R.id.btnLogout);
        btnChangePhoto = view.findViewById(R.id.btnChangePhoto);
    }

    private void setupClickListeners() {
        // Change profile photo
        btnChangePhoto.setOnClickListener(v -> showImageSourceDialog());

        // Set Office Time
        btnSetTime.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), SetOfficeTimeActivity.class));
        });

        // View Reports
        btnReports.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), ReportsActivity.class));
        });

        // Logout
        btnLogout.setOnClickListener(v -> logoutAdmin());
    }

    private void showImageSourceDialog() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Change Profile Photo")
                .setItems(new String[]{"Take Photo", "Choose from Gallery"}, (dialog, which) -> {
                    if (which == 0) {
                        checkCameraPermission();
                    } else {
                        openGallery();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(requireActivity().getPackageManager()) != null) {
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(requireContext(), "Camera permission required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == PICK_IMAGE_REQUEST && data != null) {
                Uri imageUri = data.getData();
                uploadProfileImage(imageUri);
            } else if (requestCode == CAMERA_REQUEST && data != null) {
                Uri imageUri = data.getData();
                if (imageUri == null && data.getExtras() != null) {
                    // For camera, you need to save the image first
                    Toast.makeText(requireContext(), "Camera photo captured", Toast.LENGTH_SHORT).show();
                    // Implement camera image saving
                } else {
                    uploadProfileImage(imageUri);
                }
            }
        }
    }

    private void uploadProfileImage(Uri imageUri) {
        if (imageUri == null) return;

        String userId = mAuth.getCurrentUser().getUid();
        String companyKey = sessionManager.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(requireContext(), "Company not found", Toast.LENGTH_SHORT).show();
            return;
        }

        String filename = "profile_" + UUID.randomUUID().toString() + ".jpg";
        StorageReference fileRef = storageReference.child("profile_images/" + filename);

        Toast.makeText(requireContext(), "Uploading profile image...", Toast.LENGTH_SHORT).show();

        fileRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    fileRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        saveProfileImageUrl(uri.toString(), userId, companyKey);
                    });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(requireContext(), "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Upload error", e);
                });
    }

    private void saveProfileImageUrl(String imageUrl, String userId, String companyKey) {
        DatabaseReference adminRef = databaseReference.child("Companies")
                .child(companyKey)
                .child("Admins")
                .child(userId);

        adminRef.child("profileImage").setValue(imageUrl)
                .addOnSuccessListener(aVoid -> {
                    // Update UI with new image
                    Glide.with(this)
                            .load(imageUrl)
                            .placeholder(R.drawable.ic_profile_placeholder)
                            .into(imgProfile);

                    Toast.makeText(requireContext(), "Profile image updated", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(requireContext(), "Failed to save image URL", Toast.LENGTH_SHORT).show();
                });
    }

    private void loadProfileData() {
        FirebaseUser user = mAuth.getCurrentUser();
        String companyKey = sessionManager.getCompanyKey();

        if (user == null) {
            redirectToLogin();
            return;
        }

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(requireContext(), "Company information not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Set basic info from session
        txtAdminName.setText(sessionManager.getUserName());
        txtEmail.setText(sessionManager.getUserEmail());
        txtRole.setText("Administrator");

        // Set last login
        if (user.getMetadata() != null) {
            long lastLogin = user.getMetadata().getLastSignInTimestamp();
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
            txtLastLogin.setText("Last login: " + sdf.format(new Date(lastLogin)));
        }

        // Load admin details from Firebase
        loadAdminDetails(user.getUid(), companyKey);

        // Load company details
        loadCompanyDetails(companyKey);
    }

    private void loadAdminDetails(String userId, String companyKey) {
        DatabaseReference adminRef = databaseReference.child("Companies")
                .child(companyKey)
                .child("Admins")
                .child(userId);

        adminRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Load name
                    String name = snapshot.child("name").getValue(String.class);
                    if (name != null && !name.isEmpty()) {
                        txtAdminName.setText(name);
                        sessionManager.saveUserData(name, sessionManager.getUserEmail());
                    }

                    // Load phone
                    String phone = snapshot.child("phone").getValue(String.class);
                    if (phone != null && !phone.isEmpty()) {
                        txtPhone.setText(phone);
                        sessionManager.setUserPhone(phone);
                    }

                    // Load profile image
                    String profileImage = snapshot.child("profileImage").getValue(String.class);
                    if (profileImage != null && !profileImage.isEmpty()) {
                        Glide.with(requireContext())
                                .load(profileImage)
                                .placeholder(R.drawable.ic_profile_placeholder)
                                .into(imgProfile);
                    } else {
                        // Set default profile image
                        Glide.with(requireContext())
                                .load(R.drawable.ic_profile_placeholder)
                                .into(imgProfile);
                    }

                    // Load email if not in session
                    String email = snapshot.child("email").getValue(String.class);
                    if (email != null && !email.isEmpty()) {
                        txtEmail.setText(email);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading admin details: " + error.getMessage());
            }
        });
    }

    private void loadCompanyDetails(String companyKey) {
        DatabaseReference companyRef = databaseReference.child("Companies")
                .child(companyKey);

        companyRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Company name
                    String companyName = snapshot.child("companyName").getValue(String.class);
                    if (companyName != null && !companyName.isEmpty()) {
                        txtCompanyName.setText(companyName);
                        sessionManager.setCompanyName(companyName);
                    }

                    // Company ID
                    String companyId = snapshot.child("companyId").getValue(String.class);
                    if (companyId != null && !companyId.isEmpty()) {
                        txtCompanyId.setText(companyId);
                    }

                    // Employee count
                    DataSnapshot employeesSnapshot = snapshot.child("Employees");
                    if (employeesSnapshot.exists()) {
                        long employeeCount = employeesSnapshot.getChildrenCount();
                        txtEmployeeCount.setText(String.valueOf(employeeCount));
                    } else {
                        txtEmployeeCount.setText("0");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading company details: " + error.getMessage());
                Toast.makeText(requireContext(), "Error loading company data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void logoutAdmin() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    mAuth.signOut();
                    sessionManager.logout();
                    redirectToLogin();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void redirectToLogin() {
        Intent intent = new Intent(requireActivity(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        requireActivity().finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh data when fragment resumes
        if (mAuth.getCurrentUser() != null && sessionManager.getCompanyKey() != null) {
            loadProfileData();
        }
    }
}