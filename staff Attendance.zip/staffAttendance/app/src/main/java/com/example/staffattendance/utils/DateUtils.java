package com.example.staffattendance.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class DateUtils {

    // Date formats
    public static final String FORMAT_DATE_ONLY = "yyyy-MM-dd";
    public static final String FORMAT_DISPLAY_DATE = "dd MMM yyyy";
    public static final String FORMAT_DISPLAY_DATE_LONG = "dd MMMM yyyy";
    public static final String FORMAT_DISPLAY_MONTH_YEAR = "MMMM yyyy";
    public static final String FORMAT_DATETIME = "dd MMM, hh:mm a";
    public static final String FORMAT_TIME_12H = "hh:mm a";
    public static final String FORMAT_TIME_24H = "HH:mm";
    public static final String FORMAT_TIME_24H_WITH_SECONDS = "HH:mm:ss";
    public static final String FORMAT_DAY_NAME = "EEEE";
    public static final String FORMAT_FULL_DATETIME = "dd MMM yyyy, hh:mm a";

    // -------------------- FORMAT DATES --------------------
    public static String formatDate(long timestamp) {
        if (timestamp <= 0) return "Never";
        return formatDate(new Date(timestamp), FORMAT_DISPLAY_DATE);
    }

    public static String formatDateTime(long timestamp) {
        if (timestamp <= 0) return "Never";
        return formatDate(new Date(timestamp), FORMAT_DATETIME);
    }

    public static String formatTime(long timestamp) {
        if (timestamp <= 0) return "--:--";
        return formatDate(new Date(timestamp), FORMAT_TIME_12H);
    }

    public static String formatDate(Date date, String pattern) {
        if (date == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
        return sdf.format(date);
    }

    public static String formatDate(String dateString, String inputPattern, String outputPattern) {
        if (dateString == null || dateString.isEmpty()) return "";

        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern, Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern, Locale.getDefault());
            Date date = inputFormat.parse(dateString);
            return outputFormat.format(date);
        } catch (ParseException e) {
            return dateString;
        }
    }

    public static Date parseDate(String dateString, String pattern) {
        if (dateString == null || dateString.isEmpty()) return null;

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
            return sdf.parse(dateString);
        } catch (ParseException e) {
            return null;
        }
    }

    public static String getRelativeTime(long timestamp) {
        long diff = System.currentTimeMillis() - timestamp;

        if (diff < 0) return "In the future";

        long seconds = diff / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        long weeks = days / 7;
        long months = days / 30;
        long years = days / 365;

        if (years > 0) return years + " year" + (years > 1 ? "s" : "") + " ago";
        if (months > 0) return months + " month" + (months > 1 ? "s" : "") + " ago";
        if (weeks > 0) return weeks + " week" + (weeks > 1 ? "s" : "") + " ago";
        if (days > 0) return days + " day" + (days > 1 ? "s" : "") + " ago";
        if (hours > 0) return hours + " hour" + (hours > 1 ? "s" : "") + " ago";
        if (minutes > 0) return minutes + " minute" + (minutes > 1 ? "s" : "") + " ago";
        if (seconds > 10) return seconds + " second" + (seconds > 1 ? "s" : "") + " ago";
        return "Just now";
    }

    // -------------------- DURATION --------------------
    public static String formatDuration(long durationMillis) {
        if (durationMillis <= 0) return "0h 0m";

        long hours = TimeUnit.MILLISECONDS.toHours(durationMillis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(durationMillis) - TimeUnit.HOURS.toMinutes(hours);

        return hours + "h " + minutes + "m";
    }

    /**
     * Calculate total hours between two times (robust)
     * Handles both HH:mm and HH:mm:ss formats and overnight shifts
     */
    public static String calculateTotalHours(String startTime, String endTime, String timePattern) {
        if (startTime == null || endTime == null ||
                startTime.isEmpty() || endTime.isEmpty()) return "0h 0m";

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(timePattern, Locale.getDefault());

            // Support seconds if present
            if (startTime.length() > 5) sdf = new SimpleDateFormat(FORMAT_TIME_24H_WITH_SECONDS, Locale.getDefault());

            Date start = sdf.parse(startTime);
            Date end = sdf.parse(endTime);

            long diff = end.getTime() - start.getTime();

            // Overnight shift (end next day)
            if (diff < 0) diff += 24 * 60 * 60 * 1000;

            return formatDuration(diff);
        } catch (ParseException e) {
            return "0h 0m";
        }
    }

    // -------------------- DATE CHECKS --------------------
    public static boolean isSameDay(Date date1, Date date2) {
        if (date1 == null || date2 == null) return false;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date1);
        cal2.setTime(date2);
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH) &&
                cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH);
    }

    public static boolean isToday(Date date) {
        return isSameDay(date, new Date());
    }

    public static boolean isPastDate(Date date) {
        if (date == null) return false;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date);
        cal2.setTime(new Date());
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);
        cal2.set(Calendar.HOUR_OF_DAY, 0);
        cal2.set(Calendar.MINUTE, 0);
        cal2.set(Calendar.SECOND, 0);
        cal2.set(Calendar.MILLISECOND, 0);
        return cal1.before(cal2);
    }

    public static boolean isFutureDate(Date date) {
        if (date == null) return false;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date);
        cal2.setTime(new Date());
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);
        cal2.set(Calendar.HOUR_OF_DAY, 0);
        cal2.set(Calendar.MINUTE, 0);
        cal2.set(Calendar.SECOND, 0);
        cal2.set(Calendar.MILLISECOND, 0);
        return cal1.after(cal2);
    }

    // -------------------- OTHER UTILITIES --------------------
    public static String getDayName(String dateString, String datePattern) {
        if (dateString == null || dateString.isEmpty()) return "";
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat(datePattern, Locale.getDefault());
            SimpleDateFormat dayFormat = new SimpleDateFormat(FORMAT_DAY_NAME, Locale.getDefault());
            Date date = inputFormat.parse(dateString);
            return dayFormat.format(date);
        } catch (ParseException e) {
            return "";
        }
    }

    public static String getCurrentDate(String pattern) {
        return formatDate(new Date(), pattern);
    }

    public static Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, days);
        return cal.getTime();
    }

    public static long getDaysDifference(Date date1, Date date2) {
        long diff = Math.abs(date2.getTime() - date1.getTime());
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }

    public static String convert24HourTo12Hour(String time24) {
        if (time24 == null || time24.isEmpty()) return "--:--";

        try {
            SimpleDateFormat inputFormat = time24.length() > 5 ?
                    new SimpleDateFormat(FORMAT_TIME_24H_WITH_SECONDS, Locale.getDefault()) :
                    new SimpleDateFormat(FORMAT_TIME_24H, Locale.getDefault());

            SimpleDateFormat outputFormat = new SimpleDateFormat(FORMAT_TIME_12H, Locale.getDefault());
            Date date = inputFormat.parse(time24);
            return outputFormat.format(date);
        } catch (ParseException e) {
            return time24;
        }
    }

    public static String getMonthName(int month) {
        if (month < 1 || month > 12) return "";
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, month - 1);
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM", Locale.getDefault());
        return monthFormat.format(cal.getTime());
    }

    public static Date getStartOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    public static Date getEndOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime();
    }
}
