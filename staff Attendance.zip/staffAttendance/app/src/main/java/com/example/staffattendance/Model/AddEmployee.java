package com.example.staffattendance.Model;

public class AddEmployee {

    private String id;
    private String name;
    private String phone;
    private String email;
    private String role;
    private String joiningDate;
    private String address;
    private String imageUrl;

    // 🔹 REQUIRED empty constructor (Firebase needs this)
    public AddEmployee() {
    }

    // 🔹 Constructor
    public AddEmployee(String id, String name, String phone, String email,
                       String role, String joiningDate,
                       String address, String imageUrl) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.role = role;
        this.joiningDate = joiningDate;
        this.address = address;
        this.imageUrl = imageUrl;
    }

    // 🔹 Getters & Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
