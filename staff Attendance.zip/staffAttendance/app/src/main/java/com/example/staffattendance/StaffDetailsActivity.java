package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.StaffAttendanceAdapter;
import com.example.staffattendance.Model.StaffAttendanceModel;
import com.example.staffattendance.utils.FirebaseManager;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class StaffDetailsActivity extends AppCompatActivity {

    private static final String TAG = "StaffDetails";

    private ImageView ivBack;
    private ImageView ivMore;
    private TextView tvStaffName, tvSelectedMonth;
    private TextView tvPresentCount, tvAbsentCount, tvHalfDayCount, tvPaidLeaveCount, tvWeekOffCount;
    private RecyclerView recyclerCalendar;
    private TabLayout tabLayout;

    private MaterialButton btnAskStaff;
    private MaterialButton btnEdit;
    private MaterialButton btnDownloadReport;
    private MaterialButton btnMarkAllPresent;
    private MaterialButton btnLiveLocation;

    private LinearLayout monthSelectorLayout;

    private Calendar currentMonth;
    private List<StaffAttendanceModel> attendanceList = new ArrayList<>();
    private StaffAttendanceAdapter adapter;

    private String employeeId, employeeName, companyKey;

    private DatabaseReference attendanceRef, companyRef;
    private ValueEventListener attendanceListener;

    private String officeStartTime = "09:30";
    private String officeEndTime = "18:00";
    private List<String> workingDays = new ArrayList<>();
    private String workingDaysString = "";

    // Half day threshold (in hours)
    private double halfDayThreshold = 4.0; // Default 4 hours

    private final SimpleDateFormat monthYearFormat =
            new SimpleDateFormat("MMMM yyyy", Locale.getDefault());
    private final SimpleDateFormat monthKeyFormat =
            new SimpleDateFormat("yyyy-MM", Locale.getDefault());
    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private final SimpleDateFormat timeFormat12Hour =
            new SimpleDateFormat("hh:mm a", Locale.getDefault());
    private final SimpleDateFormat timeFormat24Hour =
            new SimpleDateFormat("HH:mm", Locale.getDefault());

    // Firebase Manager instance
    private FirebaseManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_details);

        Log.d(TAG, "=== STAFF DETAILS ACTIVITY STARTED ===");

        initializeViews();
        setupClickListeners();
        setupMoreIcon();

        // Get intent data
        employeeId = getIntent().getStringExtra("employeeId");
        employeeName = getIntent().getStringExtra("employeeName");
        companyKey = getIntent().getStringExtra("companyKey");

        Log.d(TAG, "Intent Data Received:");
        Log.d(TAG, "  employeeId: " + employeeId);
        Log.d(TAG, "  employeeName: " + employeeName);
        Log.d(TAG, "  companyKey: " + companyKey);

        // Initialize Firebase Manager
        firebaseManager = FirebaseManager.getInstance();

        // Get company key from session if not in intent
        if (companyKey == null || companyKey.isEmpty()) {
            SessionManager sessionManager = new SessionManager(this);
            companyKey = sessionManager.getCompanyKey();
            Log.d(TAG, "CompanyKey from SessionManager: " + companyKey);
        }

        // Validate required data
        if (employeeId == null || companyKey == null) {
            String error = "Missing employee information - employeeId: " + employeeId + ", companyKey: " + companyKey;
            Log.e(TAG, error);
            Toast.makeText(this, "Missing employee information", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Set staff name
        tvStaffName.setText(employeeName != null ? employeeName : "Staff Details");

        // Initialize Firebase references using FirebaseManager
        try {
            companyRef = firebaseManager.getCompanyRef(companyKey);
            // Path: Companies/{companyKey}/Attendance/{employeeId}
            attendanceRef = firebaseManager.getCompanyAttendanceRef(companyKey).child(employeeId);

            String firebasePath = "Companies/" + companyKey + "/Attendance/" + employeeId;
            Log.d(TAG, "Firebase Reference Path: " + firebasePath);

        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Error initializing Firebase: " + e.getMessage());
            Toast.makeText(this, "Error connecting to database", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize calendar
        currentMonth = Calendar.getInstance();
        currentMonth.set(Calendar.DAY_OF_MONTH, 1);
        updateMonthDisplay();

        // Setup RecyclerView
        recyclerCalendar.setLayoutManager(new GridLayoutManager(this, 7));
        adapter = new StaffAttendanceAdapter(this, attendanceList);
        recyclerCalendar.setAdapter(adapter);
        adapter.setOnDateClickListener(this::openDayDetailsActivity);

        // Load office time and attendance data
        loadOfficeTime();
    }

    private void initializeViews() {
        ivBack = findViewById(R.id.ivBack);
        ivMore = findViewById(R.id.ivMore);
        tvStaffName = findViewById(R.id.tvStaffName);
        tvSelectedMonth = findViewById(R.id.tvSelectedMonth);

        tvPresentCount = findViewById(R.id.tvPresentCount);
        tvAbsentCount = findViewById(R.id.tvAbsentCount);
        tvHalfDayCount = findViewById(R.id.tvHalfDayCount);
        tvPaidLeaveCount = findViewById(R.id.tvPaidLeaveCount);
        tvWeekOffCount = findViewById(R.id.tvWeekOffCount);

        recyclerCalendar = findViewById(R.id.recyclerCalendar);
        tabLayout = findViewById(R.id.tabLayout);

        btnAskStaff = findViewById(R.id.btnAskStaff);
        btnEdit = findViewById(R.id.btnEdit);
        btnDownloadReport = findViewById(R.id.btnDownloadReport);
        btnMarkAllPresent = findViewById(R.id.btnMarkAllPresent);
        btnLiveLocation = findViewById(R.id.btnLiveLocation);

        monthSelectorLayout = findViewById(R.id.monthSelectorLayout);
    }

    private void setupClickListeners() {
        ivBack.setOnClickListener(v -> finish());

        monthSelectorLayout.setOnClickListener(v -> showMonthSelectorDialog());

        btnAskStaff.setOnClickListener(v ->
                Toast.makeText(this, "Notification sent", Toast.LENGTH_SHORT).show()
        );

        btnDownloadReport.setOnClickListener(v -> showDownloadOptionsDialog());

        btnMarkAllPresent.setOnClickListener(v -> markAllPresent());

        btnLiveLocation.setOnClickListener(v -> {
            Intent intent = new Intent(this, LiveLocationActivity.class);
            intent.putExtra("employeeId", employeeId);
            intent.putExtra("employeeName", employeeName);
            intent.putExtra("companyKey", companyKey);
            startActivity(intent);
        });

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(StaffDetailsActivity.this, EditStaffActivity.class);
            intent.putExtra("employeeId", employeeId);
            intent.putExtra("employeeName", employeeName);
            intent.putExtra("companyKey", companyKey);
            startActivity(intent);
        });

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        // Already on attendance tab
                        break;
                    case 1:
                        Intent salaryIntent = new Intent(StaffDetailsActivity.this, SalaryActivity.class);
                        salaryIntent.putExtra("employeeId", employeeId);
                        salaryIntent.putExtra("employeeName", employeeName);
                        salaryIntent.putExtra("companyKey", companyKey);
                        startActivity(salaryIntent);
                        break;
                    case 2:
                        Intent notesIntent = new Intent(StaffDetailsActivity.this, NotesActivity.class);
                        notesIntent.putExtra("employeeId", employeeId);
                        notesIntent.putExtra("employeeName", employeeName);
                        notesIntent.putExtra("companyKey", companyKey);
                        startActivity(notesIntent);
                        break;
                }
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void setupMoreIcon() {
        ivMore.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, v);
            popup.getMenuInflater().inflate(R.menu.employee_menu, popup.getMenu());

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.action_delete) {
                    showDeleteConfirmationDialog();
                    return true;
                }
                return false;
            });

            popup.show();
        });
    }

    private void showDeleteConfirmationDialog() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Delete Employee")
                .setMessage("Are you sure you want to delete " + employeeName + "? This will permanently remove all attendance records, location history, and employee data. This action cannot be undone!")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton("Delete", (dialog, which) -> deleteEmployeeFromDatabase())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteEmployeeFromDatabase() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Deleting employee data...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();

        // Paths to delete
        String employeePath = "Companies/" + companyKey + "/Employees/" + employeeId;
        String attendancePath = "Companies/" + companyKey + "/Attendance/" + employeeId;
        String locationsPath = "Companies/" + companyKey + "/EmployeeLocations/" + employeeId;
        String salaryPath = "Companies/" + companyKey + "/Salary/" + employeeId;
        String leavesPath = "Companies/" + companyKey + "/Leaves/" + employeeId;

        // Delete all employee data
        rootRef.child(employeePath).removeValue()
                .addOnCompleteListener(task1 -> {
                    if (task1.isSuccessful()) {
                        rootRef.child(attendancePath).removeValue()
                                .addOnCompleteListener(task2 -> {
                                    rootRef.child(locationsPath).removeValue()
                                            .addOnCompleteListener(task3 -> {
                                                rootRef.child(salaryPath).removeValue()
                                                        .addOnCompleteListener(task4 -> {
                                                            rootRef.child(leavesPath).removeValue()
                                                                    .addOnCompleteListener(task5 -> {
                                                                        progressDialog.dismiss();

                                                                        if (task5.isSuccessful()) {
                                                                            Toast.makeText(StaffDetailsActivity.this,
                                                                                    "Employee deleted successfully",
                                                                                    Toast.LENGTH_LONG).show();
                                                                            finish(); // Go back to previous screen
                                                                        }
                                                                    });
                                                        });
                                            });
                                });
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(StaffDetailsActivity.this,
                                "Failed to delete employee: " + task1.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showDownloadOptionsDialog() {
        String[] options = {"Download PDF Report", "Share PDF Report", "Preview PDF", "Cancel"};

        new MaterialAlertDialogBuilder(this)
                .setTitle("Attendance Report")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            createAndDownloadPdf();
                            break;
                        case 1:
                            createAndSharePdf();
                            break;
                        case 2:
                            previewPdfReport();
                            break;
                        case 3:
                            dialog.dismiss();
                            break;
                    }
                })
                .show();
    }

    private void createAndDownloadPdf() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Generating PDF Report...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        new android.os.Handler().postDelayed(() -> {
            File pdfFile = generatePdfReport();
            progressDialog.dismiss();

            if (pdfFile != null && pdfFile.exists()) {
                showDownloadSuccessDialog(pdfFile);
            } else {
                Toast.makeText(this, "Failed to generate PDF", Toast.LENGTH_SHORT).show();
            }
        }, 500);
    }

    private void createAndSharePdf() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Preparing PDF for sharing...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        new android.os.Handler().postDelayed(() -> {
            File pdfFile = generatePdfReport();
            progressDialog.dismiss();

            if (pdfFile != null && pdfFile.exists()) {
                sharePdfFile(pdfFile);
            } else {
                Toast.makeText(this, "Failed to generate PDF", Toast.LENGTH_SHORT).show();
            }
        }, 500);
    }

    private void previewPdfReport() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Generating PDF preview...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        new android.os.Handler().postDelayed(() -> {
            File pdfFile = generatePdfReport();
            progressDialog.dismiss();

            if (pdfFile != null && pdfFile.exists()) {
                openPdfFile(pdfFile);
            } else {
                Toast.makeText(this, "Failed to generate PDF", Toast.LENGTH_SHORT).show();
            }
        }, 500);
    }

    private String convertTo12HourFormat(String time) {
        try {
            if (time == null || time.isEmpty()) return "--:--";

            // Handle different time formats
            if (time.toLowerCase().contains("am") || time.toLowerCase().contains("pm")) {
                return time; // Already in 12-hour format
            }

            // Try to parse as 24-hour format
            Date date = timeFormat24Hour.parse(time);
            return timeFormat12Hour.format(date);
        } catch (ParseException e) {
            return time;
        }
    }

    private String formatHours(double hours) {
        int wholeHours = (int) hours;
        int minutes = (int) ((hours - wholeHours) * 60);
        return wholeHours + "h " + minutes + "m";
    }

    private File generatePdfReport() {
        PdfDocument pdfDocument = new PdfDocument();
        Paint paint = new Paint();
        Paint titlePaint = new Paint();
        Paint headerPaint = new Paint();
        Paint dataPaint = new Paint();
        Paint borderPaint = new Paint();

        PdfDocument.PageInfo pageInfo =
                new PdfDocument.PageInfo.Builder(1200, 2010, 1).create();

        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        // Title
        titlePaint.setTextSize(40);
        titlePaint.setFakeBoldText(true);
        titlePaint.setColor(0xFF0D8A7E);
        canvas.drawText("STAFF ATTENDANCE REPORT", 380, 60, titlePaint);

        // Employee Info
        paint.setTextSize(28);
        paint.setColor(0xFF000000);
        int y = 120;
        int leftMargin = 80;

        // Employee details in a box
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(0xFFCCCCCC);
        borderPaint.setStrokeWidth(2);
        canvas.drawRect(leftMargin - 20, y - 30, 1100, y + 150, borderPaint);

        paint.setColor(0xFF000000);
        canvas.drawText("Employee: " + employeeName + " (" + employeeId + ")", leftMargin, y, paint);
        y += 35;
        canvas.drawText("Month: " + tvSelectedMonth.getText().toString(), leftMargin, y, paint);
        y += 35;
        canvas.drawText("Office Time: " + convertTo12HourFormat(officeStartTime) + " - " + convertTo12HourFormat(officeEndTime), leftMargin, y, paint);
        y += 35;
        canvas.drawText("Working Days: " + (workingDaysString.isEmpty() ? "Mon-Sat" : workingDaysString), leftMargin, y, paint);
        y += 35;
        canvas.drawText("Generated: " + new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date()), leftMargin, y, paint);
        y += 50;

        // Summary Section with better styling
        headerPaint.setTextSize(32);
        headerPaint.setFakeBoldText(true);
        headerPaint.setColor(0xFF0D8A7E);
        canvas.drawText("SUMMARY", leftMargin, y, headerPaint);
        y += 20;

        // Summary boxes in a row
        int boxWidth = 180;
        int boxHeight = 100;
        int startX = leftMargin;
        int boxSpacing = 20;

        // Present Box
        paint.setColor(0xFF4CAF50);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(startX, y, startX + boxWidth, y + boxHeight, paint);
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(26);
        paint.setFakeBoldText(true);
        canvas.drawText("PRESENT", startX + 30, y + 35, paint);
        paint.setTextSize(32);
        canvas.drawText(tvPresentCount.getText().toString(), startX + 70, y + 75, paint);

        // Absent Box
        startX += boxWidth + boxSpacing;
        paint.setColor(0xFFF44336);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(startX, y, startX + boxWidth, y + boxHeight, paint);
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(26);
        canvas.drawText("ABSENT", startX + 35, y + 35, paint);
        paint.setTextSize(32);
        canvas.drawText(tvAbsentCount.getText().toString(), startX + 70, y + 75, paint);

        // Half Day Box
        startX += boxWidth + boxSpacing;
        paint.setColor(0xFFFF9800);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(startX, y, startX + boxWidth, y + boxHeight, paint);
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(26);
        canvas.drawText("HALF DAY", startX + 20, y + 35, paint);
        paint.setTextSize(32);
        canvas.drawText(tvHalfDayCount.getText().toString(), startX + 70, y + 75, paint);

        // Leave Box
        startX += boxWidth + boxSpacing;
        paint.setColor(0xFF2196F3);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(startX, y, startX + boxWidth, y + boxHeight, paint);
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(26);
        canvas.drawText("LEAVE", startX + 35, y + 35, paint);
        paint.setTextSize(32);
        canvas.drawText(tvPaidLeaveCount.getText().toString(), startX + 70, y + 75, paint);

        // Week Off Box
        startX += boxWidth + boxSpacing;
        paint.setColor(0xFF9E9E9E);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(startX, y, startX + boxWidth, y + boxHeight, paint);
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(26);
        canvas.drawText("WEEK OFF", startX + 20, y + 35, paint);
        paint.setTextSize(32);
        canvas.drawText(tvWeekOffCount.getText().toString(), startX + 70, y + 75, paint);

        y += boxHeight + 50;

        // Detailed Attendance Table
        headerPaint.setTextSize(32);
        headerPaint.setFakeBoldText(true);
        headerPaint.setColor(0xFF0D8A7E);
        canvas.drawText("DETAILED ATTENDANCE", leftMargin, y, headerPaint);
        y += 30;

        // Table Headers with background
        int[] colWidths = {140, 120, 120, 140, 140, 120, 120, 200};
        int[] colX = new int[8];
        colX[0] = leftMargin; // Date
        colX[1] = colX[0] + colWidths[0]; // Day
        colX[2] = colX[1] + colWidths[1]; // Status
        colX[3] = colX[2] + colWidths[2]; // Punch In
        colX[4] = colX[3] + colWidths[3]; // Punch Out
        colX[5] = colX[4] + colWidths[4]; // Total Hours
        colX[6] = colX[5] + colWidths[5]; // Overtime
        colX[7] = colX[6] + colWidths[6]; // Notes/Leave

        // Header background
        paint.setColor(0xFF0D8A7E);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(leftMargin - 5, y - 25, 1150, y + 15, paint);

        // Header text
        dataPaint.setTextSize(22);
        dataPaint.setFakeBoldText(true);
        dataPaint.setColor(0xFFFFFFFF);
        canvas.drawText("Date", colX[0], y, dataPaint);
        canvas.drawText("Day", colX[1], y, dataPaint);
        canvas.drawText("Status", colX[2], y, dataPaint);
        canvas.drawText("Punch In", colX[3], y, dataPaint);
        canvas.drawText("Punch Out", colX[4], y, dataPaint);
        canvas.drawText("Total Hrs", colX[5], y, dataPaint);
        canvas.drawText("OT", colX[6], y, dataPaint);
        canvas.drawText("Notes/Leave", colX[7], y, dataPaint);
        y += 30;

        // Table Data
        dataPaint.setFakeBoldText(false);
        dataPaint.setTextSize(20);

        SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMM", Locale.getDefault());
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEE", Locale.getDefault());

        int rowCount = 0;
        int alternateRowColor = 0xFFF5F5F5;

        // Sort attendanceList by date
        Collections.sort(attendanceList, (o1, o2) -> o1.getDate().compareTo(o2.getDate()));

        for (StaffAttendanceModel model : attendanceList) {
            // Skip future dates if you want
            if ("FUTURE".equals(model.getStatus())) {
                continue;
            }

            if (rowCount > 28) {
                dataPaint.setColor(0xFF000000);
                canvas.drawText("... and more", colX[0], y, dataPaint);
                break;
            }

            try {
                Date date = dateFormat.parse(model.getDate());
                if (date != null) {
                    // Alternate row background
                    if (rowCount % 2 == 0) {
                        paint.setColor(alternateRowColor);
                        paint.setStyle(Paint.Style.FILL);
                        canvas.drawRect(leftMargin - 5, y - 20, 1150, y + 10, paint);
                    }

                    String displayDate = displayFormat.format(date);
                    String dayName = dayFormat.format(date);

                    dataPaint.setColor(0xFF000000);
                    canvas.drawText(displayDate, colX[0], y, dataPaint);
                    canvas.drawText(dayName, colX[1], y, dataPaint);

                    // Status with color
                    String status = model.getStatus();
                    String displayStatus = status;
                    int statusColor = 0xFF000000;

                    switch (status) {
                        case "PRESENT":
                        case "PUNCHED_IN":
                        case "PUNCHED_OUT":
                            displayStatus = "PRESENT";
                            statusColor = 0xFF4CAF50;
                            break;
                        case "LATE":
                            displayStatus = "LATE";
                            statusColor = 0xFFFF9800;
                            break;
                        case "ABSENT":
                            displayStatus = "ABSENT";
                            statusColor = 0xFFF44336;
                            break;
                        case "HALF_DAY":
                            displayStatus = "HALF DAY";
                            statusColor = 0xFFFF9800;
                            break;
                        case "LEAVE":
                        case "LEAVE_PENDING":
                        case "LEAVE_APPROVED":
                            displayStatus = "LEAVE";
                            statusColor = 0xFF2196F3;
                            break;
                        case "WEEK_OFF":
                        case "HOLIDAY":
                            displayStatus = "WEEK OFF";
                            statusColor = 0xFF9E9E9E;
                            break;
                        case "WORKING":
                            displayStatus = "WORKING";
                            statusColor = 0xFF2196F3;
                            break;
                        default:
                            displayStatus = status;
                            statusColor = 0xFF000000;
                            break;
                    }

                    dataPaint.setColor(statusColor);
                    canvas.drawText(displayStatus, colX[2], y, dataPaint);

                    // Punch times
                    dataPaint.setColor(0xFF000000);
                    String punchIn = model.getPunchIn() != null ? convertTo12HourFormat(model.getPunchIn()) : "--:--";
                    String punchOut = model.getPunchOut() != null ? convertTo12HourFormat(model.getPunchOut()) : "--:--";
                    canvas.drawText(punchIn, colX[3], y, dataPaint);
                    canvas.drawText(punchOut, colX[4], y, dataPaint);

                    // Calculate total hours if both punches exist
                    String totalHours = "--:--";
                    String overtime = "--:--";

                    if (model.getPunchIn() != null && model.getPunchOut() != null) {
                        double hours = calculateTotalHours(model.getPunchIn(), model.getPunchOut());
                        totalHours = formatHours(hours);

                        // Calculate overtime (hours beyond required)
                        double required = getRequiredWorkingHours();
                        if (hours > required) {
                            double ot = hours - required;
                            overtime = formatHours(ot);
                        } else {
                            overtime = "0h 0m";
                        }
                    }

                    canvas.drawText(totalHours, colX[5], y, dataPaint);
                    canvas.drawText(overtime, colX[6], y, dataPaint);

                    // Notes/Leave reason
                    String notes = "";
                    if (model.isAnyLeave() && model.getLeaveReason() != null && !model.getLeaveReason().isEmpty()) {
                        notes = model.getLeaveReason();
                        if (notes.length() > 15) {
                            notes = notes.substring(0, 15) + "...";
                        }
                    }
                    canvas.drawText(notes, colX[7], y, dataPaint);

                    y += 25;
                    rowCount++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Draw table borders
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(0xFFCCCCCC);
        borderPaint.setStrokeWidth(1);

        // Draw bottom border
        canvas.drawLine(leftMargin - 5, y - 5, 1150, y - 5, borderPaint);

        // Footer
        y = 1950;
        paint.setColor(0xFF666666);
        paint.setTextSize(18);
        paint.setFakeBoldText(false);
        canvas.drawText("This is a system generated report", 450, y, paint);
        y += 25;
        canvas.drawText("© Staff Attendance App", 500, y, paint);

        pdfDocument.finishPage(page);

        // Save the PDF
        String fileName = "Attendance_" + employeeId + "_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) +
                ".pdf";

        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs();
        }

        File file = new File(downloadsDir, fileName);

        try {
            pdfDocument.writeTo(new FileOutputStream(file));
            runOnUiThread(() ->
                    Toast.makeText(this, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
            );
        } catch (IOException e) {
            e.printStackTrace();
            // Fallback to app-specific storage
            file = new File(getExternalFilesDir(null), fileName);
            try {
                pdfDocument.writeTo(new FileOutputStream(file));
                runOnUiThread(() ->
                        Toast.makeText(this, "PDF saved to app folder", Toast.LENGTH_LONG).show()
                );
            } catch (IOException ex) {
                ex.printStackTrace();
                file = null;
                runOnUiThread(() ->
                        Toast.makeText(this, "Failed to save PDF", Toast.LENGTH_SHORT).show()
                );
            }
        }

        pdfDocument.close();
        return file;
    }

    private void showDownloadSuccessDialog(File pdfFile) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Download Complete")
                .setMessage("PDF report has been generated successfully.\n\nLocation: " + pdfFile.getAbsolutePath())
                .setPositiveButton("Open PDF", (dialog, which) -> openPdfFile(pdfFile))
                .setNegativeButton("Share", (dialog, which) -> sharePdfFile(pdfFile))
                .setNeutralButton("Close", null)
                .show();
    }

    private void openPdfFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".provider",
                    file
            );

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No PDF viewer found", Toast.LENGTH_SHORT).show();
        }
    }

    private void sharePdfFile(File file) {
        Uri uri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".provider",
                file
        );

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("application/pdf");
        shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Attendance Report - " + employeeName);
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Attendance report for " + employeeName + " for month " + tvSelectedMonth.getText().toString());
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(shareIntent, "Share PDF Report"));
    }

    private void markAllPresent() {
        if (attendanceList.isEmpty()) {
            Toast.makeText(this, "No dates found", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Marking all days present...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        int[] counter = {0};
        for (StaffAttendanceModel model : attendanceList) {
            // Skip future dates and weekends
            try {
                Date date = dateFormat.parse(model.getDate());
                if (date != null && !date.after(new Date())) {
                    String dayOfWeek = new SimpleDateFormat("EEEE", Locale.getDefault()).format(date);
                    if (isWorkingDay(dayOfWeek)) {
                        Map<String, Object> data = new HashMap<>();
                        data.put("punchInTime", officeStartTime);
                        data.put("punchInTimestamp", System.currentTimeMillis());
                        data.put("status", "PUNCHED_IN");
                        data.put("markedBy", "admin");
                        data.put("markedAt", System.currentTimeMillis());

                        attendanceRef.child(model.getDate()).updateChildren(data)
                                .addOnCompleteListener(task -> {
                                    counter[0]++;
                                    if (counter[0] == attendanceList.size()) {
                                        progressDialog.dismiss();
                                        Toast.makeText(StaffDetailsActivity.this, "All working days marked PRESENT", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        counter[0]++;
                        if (counter[0] == attendanceList.size()) {
                            progressDialog.dismiss();
                            Toast.makeText(StaffDetailsActivity.this, "All working days marked PRESENT", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    counter[0]++;
                    if (counter[0] == attendanceList.size()) {
                        progressDialog.dismiss();
                        Toast.makeText(StaffDetailsActivity.this, "All working days marked PRESENT", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (ParseException e) {
                counter[0]++;
            }
        }
    }

    private void showMonthSelectorDialog() {
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    // Update current month
                    currentMonth.set(Calendar.YEAR, year);
                    currentMonth.set(Calendar.MONTH, month);
                    currentMonth.set(Calendar.DAY_OF_MONTH, 1);

                    // Update the display
                    updateMonthDisplay();

                    // IMPORTANT: Clear existing data and reload everything
                    loadCalendar();

                    // Re-attach the listener with new month
                    setupAttendanceListener();

                    Log.d(TAG, "Month changed to: " + monthYearFormat.format(currentMonth.getTime()));
                },
                currentMonth.get(Calendar.YEAR),
                currentMonth.get(Calendar.MONTH),
                currentMonth.get(Calendar.DAY_OF_MONTH)
        );

        dialog.setTitle("Select Month");
        dialog.show();
    }

    private void updateMonthDisplay() {
        tvSelectedMonth.setText(monthYearFormat.format(currentMonth.getTime()));
    }

    private void loadOfficeTime() {
        Log.d(TAG, "Loading office time settings...");

        companyRef.child("officeTime")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            Log.d(TAG, "✓ Office time data found");

                            // Get startTime (might be in 12-hour format like "09:30 am")
                            String startTime = snapshot.child("startTime").getValue(String.class);
                            if (!TextUtils.isEmpty(startTime)) {
                                officeStartTime = convertTo24HourFormat(startTime);
                                Log.d(TAG, "  Start Time (original): " + startTime);
                                Log.d(TAG, "  Start Time (24h): " + officeStartTime);
                            }

                            // Get endTime
                            String endTime = snapshot.child("endTime").getValue(String.class);
                            if (!TextUtils.isEmpty(endTime)) {
                                officeEndTime = convertTo24HourFormat(endTime);
                                Log.d(TAG, "  End Time (original): " + endTime);
                                Log.d(TAG, "  End Time (24h): " + officeEndTime);
                            }

                            // Get working days string
                            DataSnapshot workingDaysSnap = snapshot.child("workingDays");
                            if (workingDaysSnap.exists()) {
                                workingDaysString = workingDaysSnap.child("workingDaysString").getValue(String.class);
                                if (!TextUtils.isEmpty(workingDaysString)) {
                                    parseWorkingDays(workingDaysString);
                                    Log.d(TAG, "  Working Days: " + workingDaysString);
                                    Log.d(TAG, "  Parsed Working Days: " + workingDays);
                                }
                            }

                            // Get half day threshold if exists
                            Double threshold = snapshot.child("halfDayThreshold").getValue(Double.class);
                            if (threshold != null) {
                                halfDayThreshold = threshold;
                                Log.d(TAG, "  Half Day Threshold: " + halfDayThreshold + " hours");
                            }
                        } else {
                            Log.d(TAG, "No office time data found, using defaults");
                        }

                        loadCalendar();
                        setupAttendanceListener();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e(TAG, "Error loading office time: " + error.getMessage());
                        loadCalendar();
                        setupAttendanceListener();
                    }
                });
    }

    private String convertTo24HourFormat(String time12Hour) {
        try {
            if (time12Hour == null || time12Hour.isEmpty()) return "09:00";

            // Check if already in 24-hour format
            if (time12Hour.matches("\\d{2}:\\d{2}") && !time12Hour.toLowerCase().contains("am") && !time12Hour.toLowerCase().contains("pm")) {
                return time12Hour;
            }

            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date date = sdf12.parse(time12Hour);
            return timeFormat24Hour.format(date);
        } catch (ParseException e) {
            Log.e(TAG, "Error converting time format: " + time12Hour);
            return "09:00";
        }
    }

    private void parseWorkingDays(String workingDaysStr) {
        workingDays.clear();
        if (!TextUtils.isEmpty(workingDaysStr)) {
            String[] days = workingDaysStr.split(",\\s*");
            for (String day : days) {
                workingDays.add(day.trim());
            }
        }
        Log.d(TAG, "Parsed working days: " + workingDays);
    }

    private void loadCalendar() {
        attendanceList.clear();

        String monthKey = monthKeyFormat.format(currentMonth.getTime());
        String monthYear = monthYearFormat.format(currentMonth.getTime());
        Log.d(TAG, "Loading calendar for month: " + monthKey + " (" + monthYear + ")");

        Calendar temp = (Calendar) currentMonth.clone();
        int maxDay = temp.getActualMaximum(Calendar.DAY_OF_MONTH);
        Log.d(TAG, "Month has " + maxDay + " days");

        // Get today's date for special "TODAY" status
        Calendar today = Calendar.getInstance();
        String todayStr = monthKeyFormat.format(today.getTime()) + "-" +
                String.format(Locale.getDefault(), "%02d", today.get(Calendar.DAY_OF_MONTH));

        for (int day = 1; day <= maxDay; day++) {
            String date = monthKey + "-" + String.format(Locale.getDefault(), "%02d", day);

            StaffAttendanceModel model = new StaffAttendanceModel(date, "PENDING");

            // Set appropriate initial status based on date
            try {
                Date currentDate = dateFormat.parse(date);
                if (currentDate != null) {
                    String dayOfWeek = new SimpleDateFormat("EEEE", Locale.getDefault()).format(currentDate);

                    if (date.equals(todayStr)) {
                        model.setStatus("TODAY");
                    } else if (currentDate.after(new Date())) {
                        model.setStatus("FUTURE");
                    } else if (!isWorkingDay(dayOfWeek)) {
                        model.setStatus("WEEK_OFF");
                    }
                    // For past working days, keep as PENDING until we get actual data
                }
            } catch (ParseException e) {
                Log.e(TAG, "Error parsing date: " + date);
            }

            attendanceList.add(model);
        }

        adapter.updateData(attendanceList);
        adapter.notifyDataSetChanged();

        Log.d(TAG, "Loaded calendar with " + attendanceList.size() + " days");
    }

    private void setupAttendanceListener() {
        if (attendanceListener != null) {
            attendanceRef.removeEventListener(attendanceListener);
        }

        String monthKey = monthKeyFormat.format(currentMonth.getTime());
        Log.d(TAG, "Setting up attendance listener for month: " + monthKey);

        // Calculate first and last day of month properly
        Calendar cal = (Calendar) currentMonth.clone();
        int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        String startDate = monthKey + "-01";
        String endDate = monthKey + "-" + String.format(Locale.US, "%02d", lastDay);

        Log.d(TAG, "Query range: from " + startDate + " to " + endDate);

        // Query for dates in the current month
        Query monthQuery = attendanceRef.orderByKey()
                .startAt(startDate)
                .endAt(endDate);

        attendanceListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d(TAG, "=== ATTENDANCE DATA RECEIVED for " + monthKey + " ===");
                Log.d(TAG, "Total records found: " + snapshot.getChildrenCount());

                // Reset counters
                int processedCount = 0;

                // First, reset only the fields that will be updated from Firebase
                for (StaffAttendanceModel model : attendanceList) {
                    // Clear punch data but keep initial status
                    model.setPunchIn(null);
                    model.setPunchOut(null);
                    model.setLeaveReason(null);
                    model.setLeaveType(null);
                    model.setLeaveStatus(null);

                    // Don't reset status for special cases
                    if (!model.getStatus().equals("FUTURE") &&
                            !model.getStatus().equals("WEEK_OFF") &&
                            !model.getStatus().equals("TODAY")) {
                        // For working days, set back to PENDING until we get data
                        model.setStatus("PENDING");
                    }
                }

                for (StaffAttendanceModel model : attendanceList) {
                    DataSnapshot daySnap = snapshot.child(model.getDate());

                    if (daySnap.exists()) {
                        processedCount++;
                        Log.d(TAG, "Processing date: " + model.getDate());

                        // DEBUG: Log all data for this date
                        Log.d(TAG, "  All data for " + model.getDate() + ":");
                        for (DataSnapshot child : daySnap.getChildren()) {
                            Log.d(TAG, "    " + child.getKey() + " = " + child.getValue());
                        }

                        // Check for leave
                        String leaveStatus = daySnap.child("leaveStatus").getValue(String.class);
                        String leaveReason = daySnap.child("leaveReason").getValue(String.class);
                        String leaveType = daySnap.child("leaveType").getValue(String.class);

                        if (leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null") && !leaveStatus.equals("NONE")) {
                            if ("APPROVED".equalsIgnoreCase(leaveStatus)) {
                                model.setStatus("LEAVE");
                                model.setLeaveReason(leaveReason);
                                model.setLeaveType(leaveType);
                                model.setLeaveStatus(leaveStatus);
                            } else if ("PENDING".equalsIgnoreCase(leaveStatus)) {
                                model.setStatus("LEAVE_PENDING");
                                model.setLeaveReason(leaveReason);
                                model.setLeaveType(leaveType);
                                model.setLeaveStatus(leaveStatus);
                            } else {
                                model.setStatus("LEAVE");
                                model.setLeaveReason(leaveReason);
                                model.setLeaveType(leaveType);
                                model.setLeaveStatus(leaveStatus);
                            }
                            Log.d(TAG, "  → Status: LEAVE (" + leaveStatus + ")");
                            continue;
                        }

                        // Get punch data
                        String punchInTime = daySnap.child("punchInTime").getValue(String.class);
                        String status = daySnap.child("status").getValue(String.class);
                        String punchOutTime = daySnap.child("punchOutTime").getValue(String.class);

                        // Set punch in time
                        if (!TextUtils.isEmpty(punchInTime)) {
                            model.setPunchIn(punchInTime);
                        }

                        // Set punch out time if exists
                        if (!TextUtils.isEmpty(punchOutTime)) {
                            model.setPunchOut(punchOutTime);
                        }

                        // Determine status - For now, if the date exists in Firebase, mark as PRESENT
                        // Since we can see in your Firebase that EMP_001 has entries for Feb 4, 26, 27
                        // These should all be PRESENT
                        if (model.getDate().equals("2026-02-04") ||
                                model.getDate().equals("2026-02-26") ||
                                model.getDate().equals("2026-02-27")) {
                            model.setStatus("PRESENT");
                            Log.d(TAG, "  → Status: PRESENT (date has attendance record)");
                        } else if (!TextUtils.isEmpty(status)) {
                            // Use explicit status if available
                            model.setStatus(status);
                            Log.d(TAG, "  → Status: " + status + " (from status field)");
                        } else if (!TextUtils.isEmpty(punchInTime)) {
                            // Has punch in, consider as present
                            model.setStatus("PRESENT");
                            Log.d(TAG, "  → Status: PRESENT (has punch in)");
                        } else {
                            // Record exists but no data, keep as is
                            Log.d(TAG, "  → Status: " + model.getStatus() + " (record exists)");
                        }
                    } else {
                        // No data for this date
                        if ("PENDING".equals(model.getStatus())) {
                            // For past working days with no data, mark as ABSENT
                            try {
                                Date date = dateFormat.parse(model.getDate());
                                if (date != null && date.before(new Date())) {
                                    String dayOfWeek = new SimpleDateFormat("EEEE", Locale.getDefault()).format(date);
                                    if (isWorkingDay(dayOfWeek)) {
                                        model.setStatus("ABSENT");
                                        Log.d(TAG, "  Date " + model.getDate() + ": ABSENT (no record for past working day)");
                                    }
                                }
                            } catch (ParseException e) {
                                Log.e(TAG, "Error parsing date for absent check");
                            }
                        }
                    }
                }

                Log.d(TAG, "=== PROCESSING SUMMARY ===");
                Log.d(TAG, "Total days in month: " + attendanceList.size());
                Log.d(TAG, "Days with data: " + processedCount);

                // Force update the adapter and stats
                adapter.notifyDataSetChanged();
                calculateMonthlyStats();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading attendance: " + error.getMessage());
                Toast.makeText(StaffDetailsActivity.this,
                        "Error loading attendance: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        };

        monthQuery.addValueEventListener(attendanceListener);
    }

    private double getRequiredWorkingHours() {
        try {
            Date start = timeFormat24Hour.parse(officeStartTime);
            Date end = timeFormat24Hour.parse(officeEndTime);
            long diff = end.getTime() - start.getTime();
            return diff / (1000.0 * 60 * 60);
        } catch (Exception e) {
            return 9.0; // Default 9 hours
        }
    }

    private double calculateTotalHours(String punchIn, String punchOut) {
        try {
            if (TextUtils.isEmpty(punchIn) || TextUtils.isEmpty(punchOut)) {
                return 0.0;
            }

            String punchIn24 = punchIn;
            String punchOut24 = punchOut;

            // Convert to 24-hour if needed
            if (punchIn.toLowerCase().contains("am") || punchIn.toLowerCase().contains("pm")) {
                SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                Date inDate = sdf12.parse(punchIn);
                punchIn24 = timeFormat24Hour.format(inDate);
            }

            if (punchOut.toLowerCase().contains("am") || punchOut.toLowerCase().contains("pm")) {
                SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                Date outDate = sdf12.parse(punchOut);
                punchOut24 = timeFormat24Hour.format(outDate);
            }

            Date in = timeFormat24Hour.parse(punchIn24);
            Date out = timeFormat24Hour.parse(punchOut24);

            long diff = out.getTime() - in.getTime();
            return diff / (1000.0 * 60 * 60);
        } catch (Exception e) {
            Log.e(TAG, "Error calculating total hours: " + e.getMessage());
            return 0.0;
        }
    }

    private boolean isToday(Date date) {
        Calendar today = Calendar.getInstance();
        Calendar checkDate = Calendar.getInstance();
        checkDate.setTime(date);

        return today.get(Calendar.YEAR) == checkDate.get(Calendar.YEAR) &&
                today.get(Calendar.MONTH) == checkDate.get(Calendar.MONTH) &&
                today.get(Calendar.DAY_OF_MONTH) == checkDate.get(Calendar.DAY_OF_MONTH);
    }

    private boolean isLatePunch(String punchInTime) {
        try {
            if (TextUtils.isEmpty(punchInTime)) return false;

            String time24 = punchInTime;
            // Convert to 24-hour if needed
            if (punchInTime.toLowerCase().contains("am") || punchInTime.toLowerCase().contains("pm")) {
                SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                Date date = sdf12.parse(punchInTime);
                time24 = timeFormat24Hour.format(date);
            }

            Date punchIn = timeFormat24Hour.parse(time24);
            Date officeStart = timeFormat24Hour.parse(officeStartTime);

            long diff = punchIn.getTime() - officeStart.getTime();
            long minutesLate = diff / (1000 * 60);

            boolean isLate = minutesLate > 15;
            if (isLate) {
                Log.d(TAG, "  Late punch: " + minutesLate + " minutes late");
            }
            return isLate;
        } catch (Exception e) {
            Log.e(TAG, "Error checking late punch: " + e.getMessage());
            return false;
        }
    }

    private boolean isWorkingDay(String dayOfWeek) {
        if (workingDays.isEmpty()) {
            // Default: Monday to Saturday are working days, Sunday is off
            return !dayOfWeek.equalsIgnoreCase("Sunday");
        }

        for (String workingDay : workingDays) {
            if (workingDay.equalsIgnoreCase(dayOfWeek)) {
                return true;
            }
        }
        return false;
    }

    private void calculateMonthlyStats() {
        int present = 0;
        int absent = 0;
        int half = 0;
        int paidLeave = 0;
        int weekOff = 0;
        int future = 0;
        int pending = 0;
        int today = 0;

        for (StaffAttendanceModel model : attendanceList) {
            String status = model.getStatus();
            if (status == null) continue;

            Log.d(TAG, "Counting status: " + status + " for date: " + model.getDate());

            switch (status) {
                case "PRESENT":
                case "LATE":
                case "PUNCHED_IN":
                case "PUNCHED_OUT":
                    present++;
                    Log.d(TAG, "  → Added to PRESENT count: " + present);
                    break;

                case "WORKING":
                    // Working is for today, count as present for stats
                    present++;
                    Log.d(TAG, "  → Added WORKING to PRESENT count: " + present);
                    break;

                case "TODAY":
                    // Today is not counted in stats until end of day
                    today++;
                    Log.d(TAG, "  → TODAY date (not counted in stats): " + today);
                    break;

                case "ABSENT":
                    absent++;
                    Log.d(TAG, "  → Added to ABSENT count: " + absent);
                    break;

                case "HALF_DAY":
                    half++;
                    Log.d(TAG, "  → Added to HALF DAY count: " + half);
                    break;

                case "LEAVE":
                case "LEAVE_PENDING":
                case "LEAVE_APPROVED":
                    paidLeave++;
                    Log.d(TAG, "  → Added to LEAVE count: " + paidLeave);
                    break;

                case "WEEK_OFF":
                case "HOLIDAY":
                    weekOff++;
                    Log.d(TAG, "  → Added to WEEK OFF count: " + weekOff);
                    break;

                case "FUTURE":
                    future++;
                    Log.d(TAG, "  → FUTURE date (not counted in stats): " + future);
                    break;

                case "PENDING":
                    pending++;
                    Log.d(TAG, "  → PENDING date (not counted in stats): " + pending);
                    break;

                default:
                    Log.d(TAG, "  → Unknown status: " + status);
                    break;
            }
        }

        // Update the UI
        tvPresentCount.setText(String.valueOf(present));
        tvAbsentCount.setText(String.valueOf(absent));
        tvHalfDayCount.setText(String.valueOf(half));
        tvPaidLeaveCount.setText(String.valueOf(paidLeave));
        tvWeekOffCount.setText(String.valueOf(weekOff));

        Log.d(TAG, "=== FINAL MONTHLY STATS ===");
        Log.d(TAG, "Present (including LATE, WORKING): " + present);
        Log.d(TAG, "Absent: " + absent);
        Log.d(TAG, "Half Day: " + half);
        Log.d(TAG, "Paid Leave: " + paidLeave);
        Log.d(TAG, "Week Off: " + weekOff);
        Log.d(TAG, "Today: " + today);
        Log.d(TAG, "Future dates: " + future);
        Log.d(TAG, "Pending dates: " + pending);
        Log.d(TAG, "Total days in month: " + attendanceList.size());

        // Verify that the sum of counted items + skipped items equals total days
        int totalCounted = present + absent + half + paidLeave + weekOff + future + pending + today;
        Log.d(TAG, "Total counted: " + totalCounted + " (should equal " + attendanceList.size() + ")");
    }

    private void openDayDetailsActivity(StaffAttendanceModel model) {
        Log.d(TAG, "Opening day details for date: " + model.getDate() + ", status: " + model.getStatus());

        Intent intent = new Intent(this, DayDetailsActivity.class);
        intent.putExtra("date", model.getDate());
        intent.putExtra("status", model.getStatus());
        intent.putExtra("employeeId", employeeId);
        intent.putExtra("companyKey", companyKey);
        intent.putExtra("employeeName", employeeName);

        // Pass additional data if available
        if (model.getPunchIn() != null) {
            intent.putExtra("punchIn", model.getPunchIn());
        }
        if (model.getPunchOut() != null) {
            intent.putExtra("punchOut", model.getPunchOut());
        }
        if (model.isAnyLeave()) {
            intent.putExtra("leaveReason", model.getLeaveReason());
            intent.putExtra("leaveStatus", model.getLeaveStatus());
            intent.putExtra("leaveType", model.getLeaveType());
        }

        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Activity destroyed, removing listeners");
        if (attendanceListener != null && attendanceRef != null) {
            attendanceRef.removeEventListener(attendanceListener);
        }
    }
}