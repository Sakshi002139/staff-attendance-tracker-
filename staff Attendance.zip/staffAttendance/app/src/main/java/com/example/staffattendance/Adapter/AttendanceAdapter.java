package com.example.staffattendance.Adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.AttendanceDayModel;
import com.example.staffattendance.R;

import java.io.File;
import java.util.List;

public class AttendanceAdapter
        extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {

    Context context;
    List<AttendanceDayModel> list;

    public AttendanceAdapter(Context context, List<AttendanceDayModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_calendar, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {

        AttendanceDayModel m = list.get(position);

        // ---------- PUNCH IN ----------
        h.tvPunchInTime.setText(m.punchInTime);
        h.tvPunchInAddress.setText(m.punchInAddress);

        loadImage(h.imgPunchIn, m.punchInImage);

        // ---------- PUNCH OUT ----------
        h.tvPunchOutTime.setText(m.punchOutTime);
        h.tvPunchOutAddress.setText(m.punchOutAddress);

        loadImage(h.imgPunchOut, m.punchOutImage);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    // ================= IMAGE LOADER =================
    private void loadImage(ImageView imageView, String imagePath) {

        if (imagePath == null || imagePath.isEmpty()) {
            imageView.setImageResource(R.drawable.ic_image_placeholder);
            return;
        }

        try {
            if (imagePath.startsWith("file://")) {
                imageView.setImageURI(Uri.parse(imagePath));
            } else {
                File file = new File(imagePath);
                imageView.setImageURI(Uri.fromFile(file));
            }
        } catch (Exception e) {
            imageView.setImageResource(R.drawable.ic_image_placeholder);
        }
    }

    // ================= VIEW HOLDER =================
    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvPunchInTime, tvPunchInAddress;
        TextView tvPunchOutTime, tvPunchOutAddress;
        ImageView imgPunchIn, imgPunchOut;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvPunchInTime = itemView.findViewById(R.id.tvPunchInTime);
            tvPunchInAddress = itemView.findViewById(R.id.tvPunchInAddress);
            imgPunchIn = itemView.findViewById(R.id.imgPunchIn);

            tvPunchOutTime = itemView.findViewById(R.id.tvPunchOutTime);
            tvPunchOutAddress = itemView.findViewById(R.id.tvPunchOutAddress);
            imgPunchOut = itemView.findViewById(R.id.imgPunchOut);
        }
    }
}
