package com.example.staffattendance.utils;

import android.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class AttendanceUtils {
    private static final String TAG = "AttendanceUtils";

    // Office timing constants
    private static final String OFFICE_START_TIME = "09:30";
    private static final String OFFICE_END_TIME = "18:00";
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private static final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

    // Thresholds
    public static final double REQUIRED_WORKING_HOURS = 8.5; // 8 hours 30 minutes
    public static final int HALF_DAY_THRESHOLD_HOURS = 4; // Minimum hours for half day
    public static final int LATE_GRACE_PERIOD_MINUTES = 0; // No grace period (9:30 sharp)

    /**
     * Check if check-in time is late (after 9:30 AM)
     */
    public static boolean isLate(String checkInTime) {
        try {
            if (checkInTime == null || checkInTime.isEmpty() ||
                    checkInTime.equals("--:--") || checkInTime.equals("N/A")) {
                return false;
            }

            Date punchIn = TIME_FORMAT.parse(checkInTime);
            Date officeStart = TIME_FORMAT.parse(OFFICE_START_TIME);

            // Late if after 9:30 AM
            return punchIn != null && officeStart != null && punchIn.after(officeStart);

        } catch (ParseException e) {
            Log.e(TAG, "Error parsing time in isLate(): " + checkInTime + " - " + e.getMessage());
        }
        return false;
    }

    /**
     * Calculate hours worked between check-in and check-out
     */
    public static double calculateHoursWorked(String checkIn, String checkOut) {
        try {
            if (checkIn == null || checkIn.isEmpty() || checkIn.equals("--:--") ||
                    checkOut == null || checkOut.isEmpty() || checkOut.equals("--:--")) {
                return 0.0;
            }

            Date inTime = TIME_FORMAT.parse(checkIn);
            Date outTime = TIME_FORMAT.parse(checkOut);

            if (inTime != null && outTime != null) {
                long diff = outTime.getTime() - inTime.getTime();
                long totalMinutes = diff / (1000 * 60);

                // Convert minutes to hours with 2 decimal places
                double hours = totalMinutes / 60.0;
                return Math.round(hours * 100.0) / 100.0;
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error calculating hours worked: " + e.getMessage());
        }
        return 0.0;
    }

    /**
     * Determine attendance status based on check-in/check-out times
     */
    public static String determineStatus(String checkIn, String checkOut, String leaveStatus) {
        // Check leave status first
        if (leaveStatus != null && !leaveStatus.isEmpty()) {
            if (leaveStatus.equalsIgnoreCase("APPROVED")) {
                return "LEAVE";
            } else if (leaveStatus.equalsIgnoreCase("PENDING")) {
                return "LEAVE_PENDING";
            }
        }

        // If no check-in at all
        if (checkIn == null || checkIn.isEmpty() || checkIn.equals("--:--")) {
            return "ABSENT";
        }

        // Check if late
        boolean late = isLate(checkIn);

        // If checked in but no check-out yet
        if (checkOut == null || checkOut.isEmpty() || checkOut.equals("--:--")) {
            return late ? "LATE" : "PRESENT";
        }

        // Both check-in and check-out exist
        double hours = calculateHoursWorked(checkIn, checkOut);

        if (hours >= REQUIRED_WORKING_HOURS) {
            return late ? "LATE" : "PRESENT";
        } else if (hours >= HALF_DAY_THRESHOLD_HOURS) {
            return late ? "LATE_HALF_DAY" : "HALF_DAY";
        } else {
            return "SHORT_HOURS";
        }
    }

    /**
     * Get current date in yyyy-MM-dd format
     */
    public static String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }

    /**
     * Get current time in HH:mm format
     */
    public static String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return sdf.format(new Date());
    }

    /**
     * Get formatted date (EEEE, dd MMM yyyy)
     */
    public static String getFormattedDate(String dateString) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault());

            Date date = inputFormat.parse(dateString);
            if (date != null) {
                return outputFormat.format(date);
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error formatting date: " + e.getMessage());
        }
        return dateString;
    }

    /**
     * Format time to 12-hour format with AM/PM
     */
    public static String formatTime12Hour(String time24Hour) {
        try {
            if (time24Hour == null || time24Hour.isEmpty() || time24Hour.equals("--:--")) {
                return "--:--";
            }

            SimpleDateFormat inputFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());

            Date time = inputFormat.parse(time24Hour);
            if (time != null) {
                return outputFormat.format(time);
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error formatting time: " + e.getMessage());
        }
        return time24Hour;
    }

    /**
     * Get days difference between two dates
     */
    public static int getDaysDifference(String startDate, String endDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date start = sdf.parse(startDate);
            Date end = sdf.parse(endDate);

            if (start != null && end != null) {
                long diff = end.getTime() - start.getTime();
                return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) + 1; // +1 to include both dates
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error calculating days difference: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Check if a date is today
     */
    public static boolean isToday(String dateString) {
        String today = getCurrentDate();
        return today.equals(dateString);
    }

    /**
     * Check if a date is a weekend (Saturday or Sunday)
     */
    public static boolean isWeekend(String dateString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date date = sdf.parse(dateString);

            if (date != null) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
                return dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY;
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error checking weekend: " + e.getMessage());
        }
        return false;
    }

    /**
     * Get the month name from date
     */
    public static String getMonthName(String dateString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date date = sdf.parse(dateString);

            if (date != null) {
                SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy", Locale.getDefault());
                return monthFormat.format(date);
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error getting month name: " + e.getMessage());
        }
        return dateString;
    }

    /**
     * Validate time format (HH:mm)
     */
    public static boolean isValidTimeFormat(String time) {
        if (time == null || time.isEmpty()) {
            return false;
        }

        try {
            TIME_FORMAT.parse(time);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * Get office start time
     */
    public static String getOfficeStartTime() {
        return OFFICE_START_TIME;
    }

    /**
     * Get office end time
     */
    public static String getOfficeEndTime() {
        return OFFICE_END_TIME;
    }

    /**
     * Get required working hours
     */
    public static double getRequiredWorkingHours() {
        return REQUIRED_WORKING_HOURS;
    }

    /**
     * Get half day threshold
     */
    public static int getHalfDayThreshold() {
        return HALF_DAY_THRESHOLD_HOURS;
    }
}