package com.example.staffattendance.Model;

public class LeaveItem {

    private String leaveId;       // Unique ID for leave (we will use startDate)
    private String companyKey;    // Company identifier
    private String empId;         // Employee ID
    private String leaveType;     // Sick, Casual, Earned etc.
    private String startDate;     // Start date of leave
    private String endDate;       // End date of leave
    private String reason;        // Reason for leave
    private String days;          // Number of days
    private String status;        // PENDING / APPROVED / REJECTED
    private long timestamp;       // System timestamp for sorting

    // Default constructor required by Firebase
    public LeaveItem() {
    }

    // Full constructor
    public LeaveItem(String leaveId, String companyKey, String empId, String leaveType,
                     String startDate, String endDate, String reason, String days,
                     String status, long timestamp) {
        this.leaveId = leaveId;
        this.companyKey = companyKey;
        this.empId = empId;
        this.leaveType = leaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.days = days;
        this.status = status;
        this.timestamp = timestamp;
    }

    // Getters and Setters
    public String getLeaveId() { return leaveId; }
    public void setLeaveId(String leaveId) { this.leaveId = leaveId; }

    public String getCompanyKey() { return companyKey; }
    public void setCompanyKey(String companyKey) { this.companyKey = companyKey; }

    public String getEmpId() { return empId; }
    public void setEmpId(String empId) { this.empId = empId; }

    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getDays() { return days; }
    public void setDays(String days) { this.days = days; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
