package com.example.staffattendance.Model;

public class LeaveItem {

    private String leaveId;
    private String companyKey;
    private String empId;
    private String leaveType;
    private String startDate;
    private String endDate;
    private String reason;
    private String days;
    private String status;
    private long timestamp;

    // Default constructor
    public LeaveItem() {
    }

    // Full constructor
    public LeaveItem(String leaveId, String companyKey, String empId, String leaveType,
                     String startDate, String endDate, String reason, String days,
                     String status, long timestamp) {
        this.leaveId = leaveId;
        this.companyKey = companyKey;
        this.empId = empId;
        this.leaveType = leaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.days = days;
        this.status = status;
        this.timestamp = timestamp;
    }

    // Getters and Setters (with null safety)
    public String getLeaveId() { return leaveId != null ? leaveId : ""; }
    public void setLeaveId(String leaveId) { this.leaveId = leaveId; }

    public String getCompanyKey() { return companyKey != null ? companyKey : ""; }
    public void setCompanyKey(String companyKey) { this.companyKey = companyKey; }

    public String getEmpId() { return empId != null ? empId : ""; }
    public void setEmpId(String empId) { this.empId = empId; }

    public String getLeaveType() { return leaveType != null ? leaveType : ""; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    public String getStartDate() { return startDate != null ? startDate : ""; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate != null ? endDate : ""; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getReason() { return reason != null ? reason : ""; }
    public void setReason(String reason) { this.reason = reason; }

    public String getDays() { return days != null ? days : "1"; }
    public void setDays(String days) { this.days = days; }

    public String getStatus() { return status != null ? status : "PENDING"; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    // Helper method
    public int getDaysAsInt() {
        try {
            return Integer.parseInt(getDays());
        } catch (NumberFormatException e) {
            return 1;
        }
    }
}