package com.example.staffattendance.utils;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class FirebaseManager {

    private static FirebaseManager instance;
    private final FirebaseAuth auth;
    private final FirebaseDatabase database;

    private static final String TAG = "FirebaseManager";

    private FirebaseManager() {
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
    }

    public static synchronized FirebaseManager getInstance() {
        if (instance == null) {
            instance = new FirebaseManager();
        }
        return instance;
    }

    // ================= ROOT =================

    public DatabaseReference getRootRef() {
        return database.getReference();
    }

    // ================= AUTH =================

    public FirebaseAuth getAuth() {
        return auth;
    }

    public boolean isLoggedIn() {
        return auth.getCurrentUser() != null;
    }

    public void logout() {
        auth.signOut();
        Log.d(TAG, "Firebase logout successful");
    }

    // ================= USERS (PHONE BASED) =================

    public DatabaseReference getUsersRef() {
        return getRootRef().child("Users");
    }

    public DatabaseReference getUserRef(String phone) {
        return getUsersRef().child(phone);
    }

    // ================= COMPANIES =================

    public DatabaseReference getCompaniesRef() {
        return getRootRef().child("Companies");
    }

    public DatabaseReference getCompanyRef(String companyKey) {
        return getCompaniesRef().child(companyKey);
    }

    public DatabaseReference getCompanyNameRef(String companyKey) {
        return getCompanyRef(companyKey).child("companyName");
    }

    public DatabaseReference getOwnerPhoneRef(String companyKey) {
        return getCompanyRef(companyKey).child("ownerPhone");
    }

    public DatabaseReference getLastEmployeeNoRef(String companyKey) {
        return getCompanyRef(companyKey).child("lastEmployeeNo");
    }

    // ================= ADMINS =================

    public DatabaseReference getCompanyAdminsRef(String companyKey) {
        return getCompanyRef(companyKey).child("Admins"); // Capital A
    }

    public DatabaseReference getCompanyAdminRef(String companyKey, String phone) {
        return getCompanyAdminsRef(companyKey).child(phone);
    }

    // ================= EMPLOYEES =================

    public DatabaseReference getCompanyEmployeesRef(String companyKey) {
        return getCompanyRef(companyKey).child("Employees");
    }

    public DatabaseReference getCompanyEmployeeRef(String companyKey, String employeePhone) {
        return getCompanyEmployeesRef(companyKey).child(employeePhone);
    }

    public Query getEmployeeByPhone(String companyKey, String phone) {
        return getCompanyEmployeesRef(companyKey)
                .orderByChild("phone")
                .equalTo(phone);
    }

    // ================= ATTENDANCE =================

    public DatabaseReference getCompanyAttendanceRef(String companyKey) {
        return getCompanyRef(companyKey).child("Attendance");
    }

    public DatabaseReference getDateAttendanceRef(String companyKey, String date) {
        return getCompanyAttendanceRef(companyKey).child(date);
    }

    public DatabaseReference getEmployeeAttendanceRef(
            String companyKey, String date, String phone) {
        return getDateAttendanceRef(companyKey, date).child(phone);
    }

    // ================= QUERIES =================

    public Query getCompanyByOwnerPhone(String ownerPhone) {
        return getCompaniesRef()
                .orderByChild("ownerPhone")
                .equalTo(ownerPhone);
    }

    // ================= UTIL =================

    public void checkCompanyExists(String companyKey, CompanyExistsListener listener) {
        getCompanyRef(companyKey)
                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                    @Override
                    public void onDataChange(com.google.firebase.database.DataSnapshot snapshot) {
                        listener.onExists(snapshot.exists());
                    }

                    @Override
                    public void onCancelled(com.google.firebase.database.DatabaseError error) {
                        listener.onError(error.getMessage());
                    }
                });
    }

    public interface CompanyExistsListener {
        void onExists(boolean exists);
        void onError(String error);
    }

    public void testConnection() {
        getRootRef()
                .child("connection_test")
                .setValue(System.currentTimeMillis())
                .addOnSuccessListener(unused ->
                        Log.d(TAG, "Firebase connected"))
                .addOnFailureListener(e ->
                        Log.e(TAG, "Firebase error: " + e.getMessage()));
    }

    // ================= LEAVE MANAGEMENT =================

    public DatabaseReference getCompanyLeavesRef(String companyKey) {
        return getCompanyRef(companyKey).child("Leaves");
    }

    public DatabaseReference getEmployeeLeavesRef(String companyKey, String employeePhone) {
        return getCompanyLeavesRef(companyKey).child(employeePhone);
    }

    public DatabaseReference getLeaveRequestRef(String companyKey, String employeePhone, String leaveId) {
        return getEmployeeLeavesRef(companyKey, employeePhone).child(leaveId);
    }

    public Query getAllLeaveRequests(String companyKey, String employeePhone) {
        return getEmployeeLeavesRef(companyKey, employeePhone).orderByChild("timestamp");
    }

    public Query getLeaveRequestsByStatus(String companyKey, String employeePhone, String status) {
        return getEmployeeLeavesRef(companyKey, employeePhone)
                .orderByChild("status")
                .equalTo(status);
    }

    public DatabaseReference getLeaveBalanceRef(String companyKey, String employeePhone) {
        return getCompanyEmployeeRef(companyKey, employeePhone).child("leaveBalance");
    }
}