package com.example.staffattendance.utils;

import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.HashMap;
import java.util.Map;

public class FirebaseManager {

    private static FirebaseManager instance;
    private final FirebaseAuth auth;
    private final FirebaseDatabase database;

    private static final String TAG = "FirebaseManager";

    private FirebaseManager() {
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        // Safe persistence enable (prevents crash)
        try {
            database.setPersistenceEnabled(true);
        } catch (DatabaseException e) {
            Log.w(TAG, "Persistence already enabled or Firebase already initialized");
        }
    }

    public static synchronized FirebaseManager getInstance() {
        if (instance == null) {
            instance = new FirebaseManager();
        }
        return instance;
    }

    // ================= ROOT =================

    public DatabaseReference getRootRef() {
        return database.getReference();
    }

    public DatabaseReference getDatabaseReference() {
        return database.getReference();
    }

    // ================= AUTH =================

    public FirebaseAuth getAuth() {
        return auth;
    }

    public boolean isLoggedIn() {
        return auth.getCurrentUser() != null;
    }

    public String getCurrentUserId() {
        if (auth.getCurrentUser() != null) {
            return auth.getCurrentUser().getUid();
        }
        return null;
    }

    public String getCurrentUserPhone() {
        if (auth.getCurrentUser() != null) {
            return auth.getCurrentUser().getPhoneNumber();
        }
        return null;
    }

    public String getCurrentUserEmail() {
        if (auth.getCurrentUser() != null) {
            return auth.getCurrentUser().getEmail();
        }
        return null;
    }

    public void logout() {
        auth.signOut();
        Log.d(TAG, "Firebase logout successful");
    }

    // ================= USERS =================

    public DatabaseReference getUsersRef() {
        return getRootRef().child("Users");
    }

    public DatabaseReference getUserRef(@NonNull String userId) {
        return getUsersRef().child(userId);
    }

    public DatabaseReference getUserByPhoneRef(@NonNull String phone) {
        return getUsersRef().child(phone);
    }

    // ================= COMPANIES =================

    public DatabaseReference getCompaniesRef() {
        return getRootRef().child("Companies");
    }

    public DatabaseReference getCompanyRef(@NonNull String companyKey) {

        if (TextUtils.isEmpty(companyKey)) {
            Log.e(TAG, "CompanyKey is EMPTY or NULL");
            throw new IllegalArgumentException("CompanyKey cannot be null or empty");
        }

        return getCompaniesRef().child(companyKey);
    }

    public DatabaseReference getCompanyNameRef(String companyKey) {
        return getCompanyRef(companyKey).child("companyName");
    }

    public DatabaseReference getOwnerPhoneRef(String companyKey) {
        return getCompanyRef(companyKey).child("ownerPhone");
    }

    public DatabaseReference getLastEmployeeNoRef(String companyKey) {
        return getCompanyRef(companyKey).child("lastEmployeeNo");
    }

    public DatabaseReference getCompanyLocationRef(String companyKey) {
        return getCompanyRef(companyKey).child("officeLocation");
    }

    public DatabaseReference getCompanyOfficeTimeRef(String companyKey) {
        return getCompanyRef(companyKey).child("officeTime");
    }

    // ================= ADMINS =================

    public DatabaseReference getCompanyAdminsRef(String companyKey) {
        return getCompanyRef(companyKey).child("Admins");
    }

    public DatabaseReference getCompanyAdminRef(String companyKey, String adminId) {
        return getCompanyAdminsRef(companyKey).child(adminId);
    }

    // ================= EMPLOYEES =================

    public DatabaseReference getCompanyEmployeesRef(String companyKey) {
        return getCompanyRef(companyKey).child("Employees");
    }

    public DatabaseReference getCompanyEmployeeRef(String companyKey, String employeeId) {
        return getCompanyEmployeesRef(companyKey).child(employeeId);
    }

    public DatabaseReference getEmployeeOfficeLocationRef(String companyKey, String employeeId) {
        return getCompanyEmployeeRef(companyKey, employeeId).child("officeLocation");
    }

    public Query getEmployeeByPhone(String companyKey, String phone) {
        return getCompanyEmployeesRef(companyKey)
                .orderByChild("phone")
                .equalTo(phone);
    }

    // ================= EMPLOYEE ACTIVITY =================

    public DatabaseReference getEmployeeStatusRef(String companyKey, String employeeId) {
        return getCompanyEmployeeRef(companyKey, employeeId).child("appStatus");
    }

    public DatabaseReference getEmployeeLastActiveRef(String companyKey, String employeeId) {
        return getCompanyEmployeeRef(companyKey, employeeId).child("lastActive");
    }

    public void setEmployeeOnline(String companyKey, String employeeId) {

        Map<String, Object> map = new HashMap<>();
        map.put("appStatus", "ONLINE");
        map.put("lastActive", System.currentTimeMillis());

        getCompanyEmployeeRef(companyKey, employeeId).updateChildren(map);

        Log.d(TAG, "Employee set ONLINE");
    }

    public void setEmployeeOffline(String companyKey, String employeeId) {

        Map<String, Object> map = new HashMap<>();
        map.put("appStatus", "OFFLINE");
        map.put("lastActive", System.currentTimeMillis());

        getCompanyEmployeeRef(companyKey, employeeId).updateChildren(map);

        Log.d(TAG, "Employee set OFFLINE");
    }

    // ================= ATTENDANCE =================

    public DatabaseReference getCompanyAttendanceRef(String companyKey) {
        return getCompanyRef(companyKey).child("Attendance");
    }

    public DatabaseReference getEmployeeAttendanceRef(String companyKey, String employeeId) {
        return getCompanyAttendanceRef(companyKey).child(employeeId);
    }

    public DatabaseReference getDateAttendanceRef(String companyKey, String employeeId, String date) {
        return getEmployeeAttendanceRef(companyKey, employeeId).child(date);
    }

    // ================= TEST =================

    public void testConnection() {
        getRootRef()
                .child("connection_test")
                .setValue(System.currentTimeMillis())
                .addOnSuccessListener(unused ->
                        Log.d(TAG, "Firebase connected"))
                .addOnFailureListener(e ->
                        Log.e(TAG, "Firebase error: " + e.getMessage()));
    }
}