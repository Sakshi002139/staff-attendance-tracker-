package com.example.staffattendance.Model;

public class Employee {

    private String empId;
    private String name;
    private boolean present;
    private String email;
    private String phone;
    private String department;
    private String designation;

    public Employee() {
        // Required for Firebase
    }

    public Employee(String empId, String name, boolean present) {
        this.empId = empId;
        this.name = name;
        this.present = present;
    }

    // Additional constructor with more fields
    public Employee(String empId, String name, String email, String phone,
                    String department, String designation, boolean present) {
        this.empId = empId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.designation = designation;
        this.present = present;
    }

    public String getEmpId() {
        return empId;
    }

    // Add this setter method to fix the error
    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    // Add this setter method
    public void setName(String name) {
        this.name = name;
    }

    public boolean isPresent() {
        return present;
    }

    // Add this setter method
    public void setPresent(boolean present) {
        this.present = present;
    }

    // Getter for email
    public String getEmail() {
        return email;
    }

    // Setter for email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for phone
    public String getPhone() {
        return phone;
    }

    // Setter for phone
    public void setPhone(String phone) {
        this.phone = phone;
    }

    // Getter for department
    public String getDepartment() {
        return department;
    }

    // Setter for department
    public void setDepartment(String department) {
        this.department = department;
    }

    // Getter for designation
    public String getDesignation() {
        return designation;
    }

    // Setter for designation
    public void setDesignation(String designation) {
        this.designation = designation;
    }
}