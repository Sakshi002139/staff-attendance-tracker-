package com.example.staffattendance;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.staffattendance.utils.FirebaseManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LiveLocationActivity extends AppCompatActivity {

    private static final String TAG = "LiveLocationActivity";

    // UI Components
    private Toolbar toolbar;
    private TextView tvEmployeeName, tvEmployeeId;
    private TextView tvDate, tvAddress, tvCity, tvCoordinates, tvTimestamp;
    private MaterialButton btnOpenMaps, btnRefresh;
    private ProgressBar progressBar;
    private View emptyState;
    private MaterialCardView cardLocationDetails;

    // Data
    private String employeeId, employeeName, companyKey;
    private double latitude = 0.0;
    private double longitude = 0.0;
    private String address = "";
    private String city = "";
    private String date = "";
    private String timestamp = "";

    // Firebase
    private FirebaseManager firebaseManager;
    private DatabaseReference locationRef;
    private ValueEventListener locationListener;

    // Date Formatters
    private final SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private final SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
    private final SimpleDateFormat inputTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private final SimpleDateFormat outputTimeFormat = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_location);

        Log.d(TAG, "=== LIVE LOCATION ACTIVITY STARTED ===");

        initializeViews();
        getIntentData();
        setupToolbar();
        setupFirebase();
        setupClickListeners();
        loadLocationData();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        tvEmployeeName = findViewById(R.id.tvEmployeeName);
        tvEmployeeId = findViewById(R.id.tvEmployeeId);
        tvDate = findViewById(R.id.tvDate);
        tvAddress = findViewById(R.id.tvAddress);
        tvCity = findViewById(R.id.tvCity);
        tvCoordinates = findViewById(R.id.tvCoordinates);
        tvTimestamp = findViewById(R.id.tvTimestamp);
        btnOpenMaps = findViewById(R.id.btnOpenMaps);
        btnRefresh = findViewById(R.id.btnRefresh);
        progressBar = findViewById(R.id.progressBar);
        emptyState = findViewById(R.id.emptyState);
        cardLocationDetails = findViewById(R.id.cardLocationDetails);
    }

    private void getIntentData() {
        employeeId = getIntent().getStringExtra("employeeId");
        employeeName = getIntent().getStringExtra("employeeName");
        companyKey = getIntent().getStringExtra("companyKey");

        Log.d(TAG, "Intent Data:");
        Log.d(TAG, "  employeeId: " + employeeId);
        Log.d(TAG, "  employeeName: " + employeeName);
        Log.d(TAG, "  companyKey: " + companyKey);

        // Set employee info
        tvEmployeeName.setText(employeeName != null ? employeeName : "Unknown Employee");
        tvEmployeeId.setText("ID: " + (employeeId != null ? employeeId : "N/A"));
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Live Location");
        }

        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupFirebase() {
        firebaseManager = FirebaseManager.getInstance();

        if (companyKey != null && employeeId != null) {
            // Path: Companies/{companyKey}/EmployeeLocations/{employeeId}
            locationRef = firebaseManager.getCompanyRef(companyKey)
                    .child("EmployeeLocations")
                    .child(employeeId);
        } else {
            Log.e(TAG, "Missing companyKey or employeeId");
            Toast.makeText(this, "Error: Missing employee information", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setupClickListeners() {
        btnOpenMaps.setOnClickListener(v -> openInMaps());
        btnRefresh.setOnClickListener(v -> loadLocationData());
    }

    private void loadLocationData() {
        if (locationRef == null) return;

        showLoading(true);

        if (locationListener != null) {
            locationRef.removeEventListener(locationListener);
        }

        locationListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                showLoading(false);

                if (snapshot.exists()) {
                    Log.d(TAG, "Location data found for employee: " + employeeId);
                    Log.d(TAG, "Number of location entries: " + snapshot.getChildrenCount());

                    // Get the most recent location based on timestamp
                    DataSnapshot latestLocation = null;
                    long latestTimestamp = 0;

                    for (DataSnapshot locationSnapshot : snapshot.getChildren()) {
                        String timestampStr = locationSnapshot.child("timestamp").getValue(String.class);
                        if (timestampStr != null) {
                            try {
                                Date date = inputTimeFormat.parse(timestampStr);
                                if (date != null && date.getTime() > latestTimestamp) {
                                    latestTimestamp = date.getTime();
                                    latestLocation = locationSnapshot;
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (latestLocation != null) {
                        Log.d(TAG, "Using latest location with key: " + latestLocation.getKey());
                        parseLocationData(latestLocation);
                        updateUI();
                        showEmptyState(false);
                    } else {
                        // If no timestamp found, just use the first child
                        DataSnapshot firstChild = snapshot.getChildren().iterator().next();
                        if (firstChild != null) {
                            Log.d(TAG, "Using first location with key: " + firstChild.getKey());
                            parseLocationData(firstChild);
                            updateUI();
                            showEmptyState(false);
                        } else {
                            showEmptyState(true);
                        }
                    }
                } else {
                    Log.d(TAG, "No location data found for employee: " + employeeId);
                    showEmptyState(true);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                showLoading(false);
                Log.e(TAG, "Error loading location: " + error.getMessage());
                Toast.makeText(LiveLocationActivity.this,
                        "Error loading location: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
                showEmptyState(true);
            }
        };

        locationRef.addValueEventListener(locationListener);

        // Timeout
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar.getVisibility() == View.VISIBLE) {
                showLoading(false);
                Toast.makeText(this, "Loading timeout. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }, 10000);
    }

    private void parseLocationData(DataSnapshot snapshot) {
        // Parse data exactly as in your database
        address = snapshot.child("address").getValue(String.class);
        city = snapshot.child("city").getValue(String.class);
        date = snapshot.child("date").getValue(String.class);
        timestamp = snapshot.child("timestamp").getValue(String.class);

        Double lat = snapshot.child("latitude").getValue(Double.class);
        Double lng = snapshot.child("longitude").getValue(Double.class);

        if (lat != null) latitude = lat;
        if (lng != null) longitude = lng;

        Log.d(TAG, "=== PARSED LOCATION DATA ===");
        Log.d(TAG, "  Address: " + address);
        Log.d(TAG, "  City: " + city);
        Log.d(TAG, "  Date: " + date);
        Log.d(TAG, "  Timestamp: " + timestamp);
        Log.d(TAG, "  Latitude: " + latitude);
        Log.d(TAG, "  Longitude: " + longitude);
    }

    private void updateUI() {
        // Update address
        if (address != null && !address.isEmpty() && !address.equals("null")) {
            tvAddress.setText(address);
        } else {
            tvAddress.setText("Address not available");
        }

        // Update city
        if (city != null && !city.isEmpty() && !city.equals("null")) {
            tvCity.setText(city);
        } else {
            tvCity.setText("City not available");
        }

        // Update date
        if (date != null && !date.isEmpty() && !date.equals("null")) {
            try {
                Date dateObj = inputDateFormat.parse(date);
                if (dateObj != null) {
                    tvDate.setText(outputDateFormat.format(dateObj));
                } else {
                    tvDate.setText(date);
                }
            } catch (ParseException e) {
                tvDate.setText(date);
            }
        } else {
            tvDate.setText("Date not available");
        }

        // Update coordinates
        if (latitude != 0.0 && longitude != 0.0) {
            tvCoordinates.setText(String.format(Locale.US, "%.6f, %.6f", latitude, longitude));
        } else {
            tvCoordinates.setText("Coordinates not available");
        }

        // Update timestamp
        if (timestamp != null && !timestamp.isEmpty() && !timestamp.equals("null")) {
            try {
                Date timeObj = inputTimeFormat.parse(timestamp);
                if (timeObj != null) {
                    tvTimestamp.setText(outputTimeFormat.format(timeObj));
                } else {
                    tvTimestamp.setText(timestamp);
                }
            } catch (ParseException e) {
                tvTimestamp.setText(timestamp);
            }
        } else {
            tvTimestamp.setText("Timestamp not available");
        }
    }

    private void openInMaps() {
        if (latitude == 0.0 && longitude == 0.0) {
            Toast.makeText(this, "Location coordinates not available", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create URI for Google Maps with the address
        String query = address != null && !address.isEmpty() ?
                address : latitude + "," + longitude;

        Uri geoUri = Uri.parse("geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude + "(" + employeeName + ")");

        Intent mapIntent = new Intent(Intent.ACTION_VIEW, geoUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Fallback to web browser
            Uri webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + latitude + "," + longitude);
            Intent webIntent = new Intent(Intent.ACTION_VIEW, webUri);
            startActivity(webIntent);
        }
    }

    private void showLoading(boolean show) {
        if (show) {
            progressBar.setVisibility(View.VISIBLE);
            cardLocationDetails.setVisibility(View.GONE);
            emptyState.setVisibility(View.GONE);
            btnOpenMaps.setEnabled(false);
            btnRefresh.setEnabled(false);
        } else {
            progressBar.setVisibility(View.GONE);
            btnOpenMaps.setEnabled(true);
            btnRefresh.setEnabled(true);
        }
    }

    private void showEmptyState(boolean show) {
        if (show) {
            emptyState.setVisibility(View.VISIBLE);
            cardLocationDetails.setVisibility(View.GONE);
        } else {
            emptyState.setVisibility(View.GONE);
            cardLocationDetails.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Activity destroyed, removing listeners");
        if (locationListener != null && locationRef != null) {
            locationRef.removeEventListener(locationListener);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}