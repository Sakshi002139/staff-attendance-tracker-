package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.example.staffattendance.Model.OfficeTime;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class SetOfficeTimeActivity extends AppCompatActivity {

    // UI Components
    private TextView txtCurrentStartTime, txtCurrentEndTime;
    private TextInputEditText etStartTime, etEndTime, etBreakStart, etBreakEnd;
    private Chip chipMonday, chipTuesday, chipWednesday, chipThursday, chipFriday, chipSaturday, chipSunday;
    private SwitchMaterial switchApplyToAll;
    private MaterialButton btnSaveOfficeTime;
    private MaterialButton btnViewHistory;

    // Firebase
    private DatabaseReference databaseReference;
    private DatabaseReference companyRef;
    private SessionManager sessionManager;

    // Time picker
    private Calendar calendar;
    private SimpleDateFormat timeFormatter;

    // Office time data
    private String companyKey;
    private OfficeTime currentOfficeTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_office_time);

        // Initialize components
        initializeViews();

        // Initialize Firebase and session
        databaseReference = FirebaseDatabase.getInstance().getReference();
        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(this, "Company information not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        companyRef = databaseReference.child("Companies").child(companyKey);

        // Initialize time formatter
        calendar = Calendar.getInstance();
        timeFormatter = new SimpleDateFormat("hh:mm a", Locale.getDefault());

        // Setup click listeners
        setupClickListeners();

        // Load current office time
        loadCurrentOfficeTime();

        // Set up toolbar
        setupToolbar();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Set Office Time");
        }
    }

    private void initializeViews() {
        // Current time display
        txtCurrentStartTime = findViewById(R.id.txtCurrentStartTime);
        txtCurrentEndTime = findViewById(R.id.txtCurrentEndTime);

        // Time input fields
        etStartTime = findViewById(R.id.etStartTime);
        etEndTime = findViewById(R.id.etEndTime);
        etBreakStart = findViewById(R.id.etBreakStart);
        etBreakEnd = findViewById(R.id.etBreakEnd);

        // Day chips
        chipMonday = findViewById(R.id.chipMonday);
        chipTuesday = findViewById(R.id.chipTuesday);
        chipWednesday = findViewById(R.id.chipWednesday);
        chipThursday = findViewById(R.id.chipThursday);
        chipFriday = findViewById(R.id.chipFriday);
        chipSaturday = findViewById(R.id.chipSaturday);
        chipSunday = findViewById(R.id.chipSunday);

        // Other components
        switchApplyToAll = findViewById(R.id.switchApplyToAll);
        btnSaveOfficeTime = findViewById(R.id.btnSaveOfficeTime);
    }

    private void setupClickListeners() {
        // Time pickers
        etStartTime.setOnClickListener(v -> showTimePicker(etStartTime, "Select Start Time"));
        etEndTime.setOnClickListener(v -> showTimePicker(etEndTime, "Select End Time"));
        etBreakStart.setOnClickListener(v -> showTimePicker(etBreakStart, "Select Break Start Time"));
        etBreakEnd.setOnClickListener(v -> showTimePicker(etBreakEnd, "Select Break End Time"));

        // Day chips - make them toggleable
        setupChipListeners();

        // Save button
        btnSaveOfficeTime.setOnClickListener(v -> saveOfficeTime());

        // View history button - check if it exists first
        if (btnViewHistory != null) {
            btnViewHistory.setOnClickListener(v -> {
                Toast.makeText(this, "View History clicked", Toast.LENGTH_SHORT).show();
                // TODO: Implement history activity here
            });
        }
    }

    private void setupChipListeners() {
        View.OnClickListener chipClickListener = v -> {
            Chip chip = (Chip) v;
            chip.setChecked(!chip.isChecked());
            updateChipStyle(chip, chip.isChecked());
        };

        chipMonday.setOnClickListener(chipClickListener);
        chipTuesday.setOnClickListener(chipClickListener);
        chipWednesday.setOnClickListener(chipClickListener);
        chipThursday.setOnClickListener(chipClickListener);
        chipFriday.setOnClickListener(chipClickListener);
        chipSaturday.setOnClickListener(chipClickListener);
        chipSunday.setOnClickListener(chipClickListener);

        // Set initial chip states (Mon-Sat selected by default)
        chipMonday.setChecked(true);
        chipTuesday.setChecked(true);
        chipWednesday.setChecked(true);
        chipThursday.setChecked(true);
        chipFriday.setChecked(true);
        chipSaturday.setChecked(true); // Changed to true
        chipSunday.setChecked(false);

        // Apply styles
        updateChipStyle(chipMonday, true);
        updateChipStyle(chipTuesday, true);
        updateChipStyle(chipWednesday, true);
        updateChipStyle(chipThursday, true);
        updateChipStyle(chipFriday, true);
        updateChipStyle(chipSaturday, true); // Changed to true
        updateChipStyle(chipSunday, false);
    }

    private void updateChipStyle(Chip chip, boolean isChecked) {
        chip.setChecked(isChecked);
        if (isChecked) {
            chip.setChipBackgroundColorResource(R.color.primary_color);
            chip.setTextColor(ContextCompat.getColor(this, android.R.color.white));
        } else {
            chip.setChipBackgroundColorResource(R.color.chip_unselected);
            chip.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
        }
    }

    private void showTimePicker(TextInputEditText editText, String title) {
        Calendar currentTime = Calendar.getInstance();
        int hour = currentTime.get(Calendar.HOUR_OF_DAY);
        int minute = currentTime.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute1) -> {
                    Calendar selectedTime = Calendar.getInstance();
                    selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedTime.set(Calendar.MINUTE, minute1);
                    String formattedTime = timeFormatter.format(selectedTime.getTime());
                    editText.setText(formattedTime);
                },
                hour,
                minute,
                false
        );
        timePickerDialog.setTitle(title);
        timePickerDialog.show();
    }

    private void loadCurrentOfficeTime() {
        companyRef.child("officeTime").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Load existing office time
                    currentOfficeTime = snapshot.getValue(OfficeTime.class);
                    if (currentOfficeTime != null) {
                        updateCurrentTimeDisplay();
                        prefillTimeInputs();
                    } else {
                        setDefaultOfficeTime();
                    }
                } else {
                    setDefaultOfficeTime();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(SetOfficeTimeActivity.this,
                        "Error loading office time: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                setDefaultOfficeTime();
            }
        });
    }

    private void setDefaultOfficeTime() {
        currentOfficeTime = new OfficeTime();
        currentOfficeTime.setStartTime("09:00 AM");
        currentOfficeTime.setEndTime("06:00 PM");
        currentOfficeTime.setBreakStart("01:00 PM");
        currentOfficeTime.setBreakEnd("02:00 PM");

        // Create a list for working days instead of array
        List<String> defaultWorkingDays = new ArrayList<>();
        defaultWorkingDays.add("Monday");
        defaultWorkingDays.add("Tuesday");
        defaultWorkingDays.add("Wednesday");
        defaultWorkingDays.add("Thursday");
        defaultWorkingDays.add("Friday");
        defaultWorkingDays.add("Saturday"); // Added Saturday

        currentOfficeTime.setWorkingDays(defaultWorkingDays);

        currentOfficeTime.setApplyToAll(true);
        currentOfficeTime.setCreatedAt(System.currentTimeMillis());
        currentOfficeTime.setUpdatedAt(System.currentTimeMillis());
        currentOfficeTime.setLastUpdatedBy(sessionManager.getUserName());

        updateCurrentTimeDisplay();
        prefillTimeInputs();
    }

    private void updateCurrentTimeDisplay() {
        if (currentOfficeTime != null) {
            txtCurrentStartTime.setText(currentOfficeTime.getStartTime());
            txtCurrentEndTime.setText(currentOfficeTime.getEndTime());
        }
    }

    private void prefillTimeInputs() {
        if (currentOfficeTime != null) {
            etStartTime.setText(currentOfficeTime.getStartTime());
            etEndTime.setText(currentOfficeTime.getEndTime());

            if (currentOfficeTime.getBreakStart() != null && !currentOfficeTime.getBreakStart().isEmpty()) {
                etBreakStart.setText(currentOfficeTime.getBreakStart());
            }

            if (currentOfficeTime.getBreakEnd() != null && !currentOfficeTime.getBreakEnd().isEmpty()) {
                etBreakEnd.setText(currentOfficeTime.getBreakEnd());
            }

            // Reset all chips first
            chipMonday.setChecked(false);
            chipTuesday.setChecked(false);
            chipWednesday.setChecked(false);
            chipThursday.setChecked(false);
            chipFriday.setChecked(false);
            chipSaturday.setChecked(false);
            chipSunday.setChecked(false);

            // Set working days chips based on current office time
            List<String> workingDays = currentOfficeTime.getWorkingDays();
            if (workingDays != null && !workingDays.isEmpty()) {
                for (String day : workingDays) {
                    if (day != null) {
                        String dayTrimmed = day.trim();
                        switch (dayTrimmed) {
                            case "Monday":
                                chipMonday.setChecked(true);
                                break;
                            case "Tuesday":
                                chipTuesday.setChecked(true);
                                break;
                            case "Wednesday":
                                chipWednesday.setChecked(true);
                                break;
                            case "Thursday":
                                chipThursday.setChecked(true);
                                break;
                            case "Friday":
                                chipFriday.setChecked(true);
                                break;
                            case "Saturday":
                                chipSaturday.setChecked(true);
                                break;
                            case "Sunday":
                                chipSunday.setChecked(true);
                                break;
                        }
                    }
                }
            }

            // Update chip styles
            updateChipStyle(chipMonday, chipMonday.isChecked());
            updateChipStyle(chipTuesday, chipTuesday.isChecked());
            updateChipStyle(chipWednesday, chipWednesday.isChecked());
            updateChipStyle(chipThursday, chipThursday.isChecked());
            updateChipStyle(chipFriday, chipFriday.isChecked());
            updateChipStyle(chipSaturday, chipSaturday.isChecked());
            updateChipStyle(chipSunday, chipSunday.isChecked());

            switchApplyToAll.setChecked(currentOfficeTime.isApplyToAll());
        }
    }

    private void saveOfficeTime() {
        // Validate inputs
        String startTime = etStartTime.getText().toString().trim();
        String endTime = etEndTime.getText().toString().trim();
        String breakStart = etBreakStart.getText().toString().trim();
        String breakEnd = etBreakEnd.getText().toString().trim();

        if (startTime.isEmpty()) {
            etStartTime.setError("Please select start time");
            etStartTime.requestFocus();
            return;
        }

        if (endTime.isEmpty()) {
            etEndTime.setError("Please select end time");
            etEndTime.requestFocus();
            return;
        }

        // Validate break time if provided
        if ((!breakStart.isEmpty() && breakEnd.isEmpty()) || (breakStart.isEmpty() && !breakEnd.isEmpty())) {
            Toast.makeText(this, "Please provide both break start and end times", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get selected working days as List
        List<String> workingDaysList = new ArrayList<>();
        if (chipMonday.isChecked()) workingDaysList.add("Monday");
        if (chipTuesday.isChecked()) workingDaysList.add("Tuesday");
        if (chipWednesday.isChecked()) workingDaysList.add("Wednesday");
        if (chipThursday.isChecked()) workingDaysList.add("Thursday");
        if (chipFriday.isChecked()) workingDaysList.add("Friday");
        if (chipSaturday.isChecked()) workingDaysList.add("Saturday");
        if (chipSunday.isChecked()) workingDaysList.add("Sunday");

        if (workingDaysList.isEmpty()) {
            Toast.makeText(this, "Please select at least one working day", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate time format
        if (!isValidTime(startTime) || !isValidTime(endTime)) {
            Toast.makeText(this, "Please enter valid time format (hh:mm AM/PM)", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate break times if provided
        if (!breakStart.isEmpty() && !breakEnd.isEmpty()) {
            if (!isValidTime(breakStart) || !isValidTime(breakEnd)) {
                Toast.makeText(this, "Please enter valid break time format (hh:mm AM/PM)", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Create new office time object
        OfficeTime newOfficeTime = new OfficeTime();
        newOfficeTime.setStartTime(startTime);
        newOfficeTime.setEndTime(endTime);
        newOfficeTime.setBreakStart(breakStart.isEmpty() ? null : breakStart);
        newOfficeTime.setBreakEnd(breakEnd.isEmpty() ? null : breakEnd);
        newOfficeTime.setWorkingDays(workingDaysList); // Set List instead of array
        newOfficeTime.setApplyToAll(switchApplyToAll.isChecked());
        newOfficeTime.setCreatedAt(currentOfficeTime != null ? currentOfficeTime.getCreatedAt() : System.currentTimeMillis());
        newOfficeTime.setUpdatedAt(System.currentTimeMillis());
        newOfficeTime.setLastUpdatedBy(sessionManager.getUserName());

        // Save to Firebase
        saveToFirebase(newOfficeTime);
    }

    private boolean isValidTime(String time) {
        try {
            timeFormatter.parse(time);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void saveToFirebase(OfficeTime officeTime) {
        // Show loading
        btnSaveOfficeTime.setEnabled(false);
        btnSaveOfficeTime.setText("Saving...");

        // Save to company office time
        companyRef.child("officeTime").setValue(officeTime)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Office time saved successfully!", Toast.LENGTH_SHORT).show();

                    // If apply to all is checked, update all employees
                    if (officeTime.isApplyToAll()) {
                        updateAllEmployeesOfficeTime(officeTime);
                    } else {
                        finishActivity();
                    }
                })
                .addOnFailureListener(e -> {
                    btnSaveOfficeTime.setEnabled(true);
                    btnSaveOfficeTime.setText("Save Office Time");
                    Toast.makeText(this, "Failed to save office time: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void updateAllEmployeesOfficeTime(OfficeTime officeTime) {
        companyRef.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int totalEmployees = (int) snapshot.getChildrenCount();

                if (totalEmployees == 0) {
                    Toast.makeText(SetOfficeTimeActivity.this,
                            "No employees found to update", Toast.LENGTH_SHORT).show();
                    finishActivity();
                    return;
                }

                final int[] updatedCount = {0};

                for (DataSnapshot employeeSnap : snapshot.getChildren()) {
                    String employeeId = employeeSnap.getKey();
                    if (employeeId != null) {
                        // Update each employee's individual office time
                        companyRef.child("Employees").child(employeeId).child("officeTime")
                                .setValue(officeTime)
                                .addOnSuccessListener(aVoid -> {
                                    updatedCount[0]++;
                                    if (updatedCount[0] == totalEmployees) {
                                        Toast.makeText(SetOfficeTimeActivity.this,
                                                "Office time updated for all " + totalEmployees + " employees",
                                                Toast.LENGTH_SHORT).show();
                                        finishActivity();
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    updatedCount[0]++;
                                    if (updatedCount[0] == totalEmployees) {
                                        Toast.makeText(SetOfficeTimeActivity.this,
                                                "Office time updated with some errors",
                                                Toast.LENGTH_SHORT).show();
                                        finishActivity();
                                    }
                                });
                    } else {
                        updatedCount[0]++;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(SetOfficeTimeActivity.this,
                        "Error loading employees: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                finishActivity();
            }
        });
    }

    private void finishActivity() {
        btnSaveOfficeTime.setEnabled(true);
        btnSaveOfficeTime.setText("Save Office Time");
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}