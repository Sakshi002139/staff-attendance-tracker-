package com.example.staffattendance.models;

public class Company {
    private String companyId;
    private String companyName;
    private String ownerPhone;
    private String ownerName;
    private String ownerEmail;
    private String companyKey;
    private int totalEmployees;
    private long createdAt;

    // Default constructor required for Firebase
    public Company() {
    }

    // Constructor matching SignUpActivity data
    public Company(String companyId, String companyName, String ownerPhone,
                   String ownerName, String ownerEmail, String companyKey) {
        this.companyId = companyId;
        this.companyName = companyName;
        this.ownerPhone = ownerPhone;
        this.ownerName = ownerName;
        this.ownerEmail = ownerEmail;
        this.companyKey = companyKey;
        this.totalEmployees = 0;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and Setters

    // This is what SignUpActivity calls "companyId" (displayCompanyId)
    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    // This is what SignUpActivity calls "companyName"
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    // Additional getters for compatibility with old code
    public String getName() {
        return companyName;
    }

    public void setName(String name) {
        this.companyName = name;
    }

    public String getId() {
        return companyId;
    }

    public void setId(String id) {
        this.companyId = id;
    }

    // Fields from SignUpActivity
    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    public String getCompanyKey() {
        return companyKey;
    }

    public void setCompanyKey(String companyKey) {
        this.companyKey = companyKey;
    }

    public int getTotalEmployees() {
        return totalEmployees;
    }

    public void setTotalEmployees(int totalEmployees) {
        this.totalEmployees = totalEmployees;
    }

    // For backward compatibility
    public int getEmployeeCount() {
        return totalEmployees;
    }

    public void setEmployeeCount(int employeeCount) {
        this.totalEmployees = employeeCount;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    // For backward compatibility with old code
    public long getUpdatedAt() {
        return createdAt;
    }

    public void setUpdatedAt(long updatedAt) {
        // Not used in SignUpActivity
    }

    // Additional fields that might be useful later
    private String address;
    private String phone;
    private String email;
    private String logoUrl;
    private String website;
    private String industry;
    private String status = "active";

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Helper method to check if company is active
    public boolean isActive() {
        return "active".equalsIgnoreCase(status);
    }

    // Helper method to get display info
    public String getDisplayInfo() {
        return companyName + " (" + companyId + ")";
    }

    // Helper method to get owner info
    public String getOwnerInfo() {
        return ownerName + " (" + ownerPhone + ")";
    }

    // toString for debugging
    @Override
    public String toString() {
        return "Company{" +
                "companyId='" + companyId + '\'' +
                ", companyName='" + companyName + '\'' +
                ", ownerPhone='" + ownerPhone + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", ownerEmail='" + ownerEmail + '\'' +
                ", companyKey='" + companyKey + '\'' +
                ", totalEmployees=" + totalEmployees +
                ", createdAt=" + createdAt +
                '}';
    }
}