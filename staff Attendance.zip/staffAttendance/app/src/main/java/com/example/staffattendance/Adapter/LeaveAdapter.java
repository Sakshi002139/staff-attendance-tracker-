package com.example.staffattendance.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.LeaveItem;
import com.example.staffattendance.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class LeaveAdapter extends RecyclerView.Adapter<LeaveAdapter.LeaveViewHolder> {

    private final List<LeaveItem> leaveList;
    private Context context;

    public LeaveAdapter(List<LeaveItem> leaveList) {
        this.leaveList = leaveList;
    }

    @NonNull
    @Override
    public LeaveViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_leave, parent, false);
        return new LeaveViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LeaveViewHolder holder, int position) {
        LeaveItem item = leaveList.get(position);

        holder.txtType.setText(item.getLeaveType());
        holder.txtDate.setText(item.getStartDate() + " - " + item.getEndDate());
        holder.txtDays.setText(item.getDays() + " days");
        holder.txtStatus.setText(item.getStatus());

        // Hide buttons if approved
        if ("approved".equalsIgnoreCase(item.getStatus())) {
            holder.btnEdit.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
        } else {
            holder.btnEdit.setVisibility(View.VISIBLE);
            holder.btnDelete.setVisibility(View.VISIBLE);
        }

        // Edit leave
        holder.btnEdit.setOnClickListener(v -> showEditDialog(item, position));

        // Delete leave
        holder.btnDelete.setOnClickListener(v -> showDeleteDialog(item, position));
    }

    // ------------------------- EDIT FUNCTION -------------------------
    private void showEditDialog(LeaveItem item, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Leave");

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputType = new EditText(context);
        inputType.setHint("Leave Type");
        inputType.setText(item.getLeaveType());
        layout.addView(inputType);

        final EditText inputStart = new EditText(context);
        inputStart.setHint("Start Date (YYYY-MM-DD)");
        inputStart.setInputType(InputType.TYPE_CLASS_DATETIME);
        inputStart.setText(item.getStartDate());
        layout.addView(inputStart);

        final EditText inputEnd = new EditText(context);
        inputEnd.setHint("End Date (YYYY-MM-DD)");
        inputEnd.setInputType(InputType.TYPE_CLASS_DATETIME);
        inputEnd.setText(item.getEndDate());
        layout.addView(inputEnd);

        final EditText inputDays = new EditText(context);
        inputDays.setHint("Days");
        inputDays.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputDays.setText(item.getDays());
        layout.addView(inputDays);

        final EditText inputReason = new EditText(context);
        inputReason.setHint("Reason");
        inputReason.setText(item.getReason());
        layout.addView(inputReason);

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            // Update item locally
            String oldStartDate = item.getStartDate(); // old key
            item.setLeaveType(inputType.getText().toString());
            item.setStartDate(inputStart.getText().toString());
            item.setEndDate(inputEnd.getText().toString());
            item.setDays(inputDays.getText().toString());
            item.setReason(inputReason.getText().toString());
            item.setTimestamp(System.currentTimeMillis());

            // Delete old entry if startDate changed
            if (!oldStartDate.equals(item.getStartDate())) {
                FirebaseDatabase.getInstance()
                        .getReference("Companies")
                        .child(item.getCompanyKey())
                        .child("Leaves")
                        .child(item.getEmpId())
                        .child(oldStartDate)
                        .removeValue();
            }

            // Save updated leave
            FirebaseDatabase.getInstance()
                    .getReference("Companies")
                    .child(item.getCompanyKey())
                    .child("Leaves")
                    .child(item.getEmpId())
                    .child(item.getStartDate())
                    .setValue(item)
                    .addOnSuccessListener(unused -> {
                        notifyItemChanged(position);
                        Toast.makeText(context, "Leave updated", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show());
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ------------------------- DELETE FUNCTION -------------------------
    private void showDeleteDialog(LeaveItem item, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Leave")
                .setMessage("Are you sure you want to delete this leave?")
                .setPositiveButton("Delete", (dialog, which) -> deleteLeave(item, position))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteLeave(LeaveItem item, int position) {
        if (item == null || item.getCompanyKey() == null || item.getEmpId() == null || item.getStartDate() == null) {
            Toast.makeText(context, "Invalid leave data", Toast.LENGTH_SHORT).show();
            return;
        }

        // Safety check: ensure position exists in list
        if (position < 0 || position >= leaveList.size()) {
            Toast.makeText(context, "Leave item not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Delete leave from Firebase
        FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(item.getCompanyKey())
                .child("Leaves")
                .child(item.getEmpId())
                .child(item.getStartDate())
                .removeValue()
                .addOnSuccessListener(unused -> {
                    // Remove attendance for the same date (optional)
                    FirebaseDatabase.getInstance()
                            .getReference("Companies")
                            .child(item.getCompanyKey())
                            .child("Attendance")
                            .child(item.getEmpId())
                            .child(item.getStartDate())
                            .removeValue();

                    // Remove from local list safely
                    leaveList.remove(position);
                    notifyItemRemoved(position);
                    Toast.makeText(context, "Leave deleted successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return leaveList.size();
    }

    // ------------------------- VIEW HOLDER -------------------------
    static class LeaveViewHolder extends RecyclerView.ViewHolder {
        TextView txtType, txtDate, txtDays, txtStatus;
        MaterialButton btnEdit, btnDelete;

        public LeaveViewHolder(@NonNull View itemView) {
            super(itemView);
            txtType = itemView.findViewById(R.id.txtLeaveType);
            txtDate = itemView.findViewById(R.id.txtLeaveDate);
            txtDays = itemView.findViewById(R.id.txtLeaveDays);
            txtStatus = itemView.findViewById(R.id.txtLeaveStatus);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
