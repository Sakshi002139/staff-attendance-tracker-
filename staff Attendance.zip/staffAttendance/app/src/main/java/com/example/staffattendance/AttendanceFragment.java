package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.CalendarDayModel;
import com.example.staffattendance.Model.OfficeTime;
import com.example.staffattendance.R;
import com.example.staffattendance.Adapter.CalendarAdapter;
import com.example.staffattendance.utils.DateUtils;
import com.example.staffattendance.utils.SessionManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AttendanceFragment extends Fragment {

    private TextView txtCurrentTime, tvTodayDate, txtCurrentMonth, txtCurrentYear;
    private TextView tvPresentDays, tvAbsentDays, tvLeaveDays, tvHalfDay;
    private TextView tvPunchInTime, tvPunchInStatus, tvPunchOutTime, tvPunchOutStatus;
    private TextView tvTotalHours, tvOvertime, tvRemainingHours, tvTodayStatus;
    private ImageButton btnPrevMonth, btnNextMonth, btnMonthSelector;
    private RecyclerView recyclerCalendar;

    // Day header TextViews
    private TextView txtMon, txtTue, txtWed, txtThu, txtFri, txtSat, txtSun;

    private Calendar currentMonth;
    private List<CalendarDayModel> dayList = new ArrayList<>();
    private CalendarAdapter adapter;

    private String companyKey, empId;
    private DatabaseReference companyRef;
    private DatabaseReference attendanceRef;
    private ValueEventListener monthAttendanceListener;
    private ValueEventListener todayAttendanceListener;
    private SessionManager sessionManager;

    private Handler timeHandler;
    private Runnable timeRunnable;
    private final SimpleDateFormat keyDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private final SimpleDateFormat monthKeyFormat = new SimpleDateFormat("yyyy-MM", Locale.getDefault());

    // Office timing variables (loaded from Firebase)
    private String officeStartTime = "09:00"; // Default
    private String officeEndTime = "18:00"; // Default
    private double requiredWorkingHours = 9.0; // Default 9 hours (9 AM to 6 PM)
    private int lateThresholdMinutes = 15; // Default 15 minutes
    private int halfDayThresholdHours = 4; // Default 4 hours
    private List<String> workingDays = new ArrayList<>(); // Empty list - will be loaded from Firebase

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_attendance, container, false);

        initializeViews(view);

        currentMonth = Calendar.getInstance();
        recyclerCalendar.setLayoutManager(new GridLayoutManager(getContext(), 7));

        // Initialize SessionManager
        sessionManager = new SessionManager(requireContext());

        // Get data from SessionManager
        companyKey = sessionManager.getCompanyKey();
        empId = sessionManager.getEmpId();

        // Alternative - get from Bundle arguments if SessionManager doesn't have data
        if (companyKey == null || empId == null) {
            Bundle args = getArguments();
            if (args != null) {
                companyKey = args.getString("companyKey");
                empId = args.getString("empId");
            }
        }

        // If still null, show error
        if (companyKey == null || empId == null) {
            Toast.makeText(getContext(), "Error: Missing employee information", Toast.LENGTH_SHORT).show();
            return view;
        }

        // Initialize Firebase references
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        companyRef = database.getReference("Companies").child(companyKey);
        attendanceRef = companyRef.child("Attendance").child(empId);

        setupClickListeners();

        updateUIWithCurrentMonth();
        setupDayHeaders();

        // Load office time first, then setup calendar and listeners
        loadOfficeTime();

        startLiveTime();

        return view;
    }

    private void initializeViews(View view) {
        txtCurrentTime = view.findViewById(R.id.txtCurrentTime);
        tvTodayDate = view.findViewById(R.id.tvTodayDate);
        txtCurrentMonth = view.findViewById(R.id.txtCurrentMonth);
        txtCurrentYear = view.findViewById(R.id.txtCurrentYear);

        btnPrevMonth = view.findViewById(R.id.btnPrevMonth);
        btnNextMonth = view.findViewById(R.id.btnNextMonth);
        btnMonthSelector = view.findViewById(R.id.btnMonthSelector);

        recyclerCalendar = view.findViewById(R.id.recyclerCalendar);

        // Initialize day headers
        txtMon = view.findViewById(R.id.txtMon);
        txtTue = view.findViewById(R.id.txtTue);
        txtWed = view.findViewById(R.id.txtWed);
        txtThu = view.findViewById(R.id.txtThu);
        txtFri = view.findViewById(R.id.txtFri);
        txtSat = view.findViewById(R.id.txtSat);
        txtSun = view.findViewById(R.id.txtSun);

        tvPunchInTime = view.findViewById(R.id.tvPunchInTime);
        tvPunchInStatus = view.findViewById(R.id.tvPunchInStatus);
        tvPunchOutTime = view.findViewById(R.id.tvPunchOutTime);
        tvPunchOutStatus = view.findViewById(R.id.tvPunchOutStatus);
        tvTotalHours = view.findViewById(R.id.tvTotalHours);
        tvOvertime = view.findViewById(R.id.tvOvertime);
        tvRemainingHours = view.findViewById(R.id.tvRemainingHours);
        tvTodayStatus = view.findViewById(R.id.tvTodayStatus);

        tvPresentDays = view.findViewById(R.id.tvPresentDays);
        tvAbsentDays = view.findViewById(R.id.tvAbsentDays);
        tvLeaveDays = view.findViewById(R.id.tvLeaveDays);
        tvHalfDay = view.findViewById(R.id.tvHalfDay);
    }

    private void setupDayHeaders() {
        if (getContext() != null) {
            txtMon.setTextColor(getContext().getColor(R.color.text_primary));
            txtTue.setTextColor(getContext().getColor(R.color.text_primary));
            txtWed.setTextColor(getContext().getColor(R.color.text_primary));
            txtThu.setTextColor(getContext().getColor(R.color.text_primary));
            txtFri.setTextColor(getContext().getColor(R.color.text_primary));
            txtSat.setTextColor(getContext().getColor(R.color.text_primary));
            txtSun.setTextColor(getContext().getColor(R.color.gray_default));
        }
    }

    private void loadOfficeTime() {
        if (companyRef == null) return;

        companyRef.child("officeTime").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    OfficeTime officeTime = snapshot.getValue(OfficeTime.class);
                    if (officeTime != null) {
                        updateOfficeTimeSettings(officeTime);
                        Log.d("AttendanceFragment", "Office time loaded: " + officeTime.getStartTime() + " to " + officeTime.getEndTime());
                        Log.d("AttendanceFragment", "Working days: " + officeTime.getWorkingDays());
                    } else {
                        // If officeTime exists but is null, set default
                        setDefaultOfficeTime();
                    }
                } else {
                    // If no officeTime exists, set default
                    setDefaultOfficeTime();
                }

                // After loading office time, setup calendar and listeners
                loadCalendar();
                setupMonthAttendanceListener();
                setupTodayAttendanceListener();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Use default settings and continue
                setDefaultOfficeTime();
                loadCalendar();
                setupMonthAttendanceListener();
                setupTodayAttendanceListener();
            }
        });
    }

    private void setDefaultOfficeTime() {
        // Default working days (Mon-Sat)
        workingDays.clear();
        workingDays.add("Monday");
        workingDays.add("Tuesday");
        workingDays.add("Wednesday");
        workingDays.add("Thursday");
        workingDays.add("Friday");
        workingDays.add("Saturday"); // Include Saturday by default

        officeStartTime = "09:00";
        officeEndTime = "18:00";
        requiredWorkingHours = 9.0; // 9 hours from 9 AM to 6 PM
        lateThresholdMinutes = 15;
        halfDayThresholdHours = 4;

        Log.d("AttendanceFragment", "Default working days set: " + workingDays);
    }

    private void updateOfficeTimeSettings(OfficeTime officeTime) {
        if (officeTime == null) {
            setDefaultOfficeTime();
            return;
        }

        // Update office timings
        if (officeTime.getStartTime() != null && !officeTime.getStartTime().isEmpty()) {
            officeStartTime = convertTo24HourFormat(officeTime.getStartTime());
        } else {
            officeStartTime = "09:00";
        }

        if (officeTime.getEndTime() != null && !officeTime.getEndTime().isEmpty()) {
            officeEndTime = convertTo24HourFormat(officeTime.getEndTime());
        } else {
            officeEndTime = "18:00";
        }

        // Calculate required working hours
        requiredWorkingHours = calculateRequiredHours(officeStartTime, officeEndTime);

        // Update working days
        if (officeTime.getWorkingDays() != null && !officeTime.getWorkingDays().isEmpty()) {
            workingDays.clear();
            workingDays.addAll(officeTime.getWorkingDays());
            Log.d("AttendanceFragment", "Updated working days from Firebase: " + workingDays);
        } else {
            // If workingDays is null or empty, use default (Mon-Sat)
            setDefaultOfficeTime();
        }

        // Debug log
        Log.d("AttendanceFragment", "Office time set to: " + officeStartTime + " to " + officeEndTime);
        Log.d("AttendanceFragment", "Required working hours: " + requiredWorkingHours);
    }

    private String convertTo24HourFormat(String time12Hour) {
        try {
            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date date = sdf12.parse(time12Hour);
            return sdf24.format(date);
        } catch (ParseException e) {
            // Try to parse as 24-hour format already
            try {
                SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
                Date date = sdf24.parse(time12Hour);
                return sdf24.format(date);
            } catch (ParseException e2) {
                return "09:00"; // Default fallback
            }
        }
    }

    private double calculateRequiredHours(String startTime, String endTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date start = sdf.parse(startTime);
            Date end = sdf.parse(endTime);

            long diff = end.getTime() - start.getTime();
            long totalMinutes = diff / (1000 * 60);

            return totalMinutes / 60.0;
        } catch (Exception e) {
            return 9.0; // Default fallback
        }
    }

    private void setupClickListeners() {
        btnPrevMonth.setOnClickListener(v -> navigateMonth(-1));
        btnNextMonth.setOnClickListener(v -> navigateMonth(1));
        btnMonthSelector.setOnClickListener(v -> showMonthSelectorDialog());
    }

    private void navigateMonth(int months) {
        currentMonth.add(Calendar.MONTH, months);
        updateUIWithCurrentMonth();
        reloadCalendarData();
    }

    private void updateUIWithCurrentMonth() {
        String month = new SimpleDateFormat("MMMM", Locale.getDefault()).format(currentMonth.getTime());
        String year = new SimpleDateFormat("yyyy", Locale.getDefault()).format(currentMonth.getTime());

        txtCurrentMonth.setText(month.toUpperCase());
        txtCurrentYear.setText(year);
    }

    // ---------------------- LIVE TIME ----------------------
    private void startLiveTime() {
        if (txtCurrentTime == null || getContext() == null) return;

        timeHandler = new Handler(Looper.getMainLooper());
        timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isAdded()) return;
                try {
                    String currentTime = DateUtils.getCurrentDate(DateUtils.FORMAT_TIME_24H_WITH_SECONDS);
                    String amPmTime = convertTo12HourFormat(currentTime);
                    txtCurrentTime.setText(amPmTime);

                    String todayDate = new SimpleDateFormat("EEE, MMM dd", Locale.getDefault()).format(new Date());
                    tvTodayDate.setText(todayDate);
                } catch (Exception ignored) {}
                timeHandler.postDelayed(this, 1000);
            }
        };
        timeHandler.post(timeRunnable);
    }

    private String convertTo12HourFormat(String time24) {
        try {
            SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
            Date date = sdf24.parse(time24);
            return sdf12.format(date);
        } catch (ParseException e) {
            return time24;
        }
    }

    private String convertTo12HourFormatShort(String time24) {
        try {
            SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date date = sdf24.parse(time24);
            return sdf12.format(date);
        } catch (ParseException e) {
            return time24;
        }
    }

    private void stopLiveTime() {
        if (timeHandler != null && timeRunnable != null) {
            timeHandler.removeCallbacks(timeRunnable);
        }
    }

    // ---------------------- CALENDAR ----------------------
    private void loadCalendar() {
        dayList.clear();

        String monthKey = monthKeyFormat.format(currentMonth.getTime());

        Calendar temp = (Calendar) currentMonth.clone();
        temp.set(Calendar.DAY_OF_MONTH, 1);

        int firstDay = temp.get(Calendar.DAY_OF_WEEK) - 1; // Monday = 0
        int maxDay = temp.getActualMaximum(Calendar.DAY_OF_MONTH);

        // Add empty cells for days before the 1st of the month
        for (int i = 0; i < firstDay; i++) {
            dayList.add(new CalendarDayModel("", "EMPTY"));
        }

        // Add days of the month
        for (int day = 1; day <= maxDay; day++) {
            String date = monthKey + "-" + String.format(Locale.getDefault(), "%02d", day);
            Date cellDate = DateUtils.parseDate(date, DateUtils.FORMAT_DATE_ONLY);

            if (cellDate != null) {
                Calendar dayCalendar = Calendar.getInstance();
                dayCalendar.setTime(cellDate);

                // Get day name (Monday, Tuesday, etc.)
                String dayOfWeek = new SimpleDateFormat("EEEE", Locale.getDefault()).format(cellDate);

                String status = "EMPTY";

                if (DateUtils.isFutureDate(cellDate)) {
                    status = "FUTURE";
                } else if (!isWorkingDay(dayOfWeek)) {
                    status = "HOLIDAY"; // This includes Sundays and non-working days
                } else if (DateUtils.isToday(cellDate)) {
                    status = "TODAY";
                } else {
                    status = "PENDING";
                }

                CalendarDayModel model = new CalendarDayModel(date, status);
                dayList.add(model);
            } else {
                dayList.add(new CalendarDayModel(date, "EMPTY"));
            }
        }

        if (adapter == null) {
            adapter = new CalendarAdapter(requireContext(), dayList);
            recyclerCalendar.setAdapter(adapter);
        } else {
            adapter.updateData(dayList);
        }

        Log.d("AttendanceFragment", "Calendar loaded. Working days: " + workingDays);
    }

    private boolean isWorkingDay(String dayOfWeek) {
        if (workingDays == null || workingDays.isEmpty()) {
            // Default working days (Mon-Sat) if no data loaded
            return !dayOfWeek.equalsIgnoreCase("Sunday");
        }

        for (String workingDay : workingDays) {
            if (workingDay.equalsIgnoreCase(dayOfWeek)) {
                return true;
            }
        }
        return false;
    }

    private void reloadCalendarData() {
        loadCalendar();
        setupMonthAttendanceListener();
    }

    private void showMonthSelectorDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                (view, year, month, dayOfMonth) -> {
                    currentMonth.set(Calendar.YEAR, year);
                    currentMonth.set(Calendar.MONTH, month);
                    updateUIWithCurrentMonth();
                    reloadCalendarData();
                },
                currentMonth.get(Calendar.YEAR),
                currentMonth.get(Calendar.MONTH),
                currentMonth.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    // ---------------------- MONTH ATTENDANCE LISTENER ----------------------
    private void setupMonthAttendanceListener() {
        if (attendanceRef == null) return;

        if (monthAttendanceListener != null) {
            attendanceRef.removeEventListener(monthAttendanceListener);
        }

        monthAttendanceListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;

                // Process each day in the calendar
                for (CalendarDayModel model : dayList) {
                    if (model.isEmptyCell() || model.getDate() == null || model.getDate().isEmpty()) {
                        continue;
                    }

                    DataSnapshot daySnap = snapshot.child(model.getDate());
                    if (daySnap.exists()) {
                        updateDayModelFromFirebase(model, daySnap);
                    } else {
                        markNoDataDay(model);
                    }
                }

                // Update adapter
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }

                // Calculate monthly stats
                calculateMonthlyStats();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (isAdded()) {
                    Toast.makeText(getContext(), "Error loading attendance: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        };

        attendanceRef.addValueEventListener(monthAttendanceListener);
    }

    private void updateDayModelFromFirebase(CalendarDayModel model, DataSnapshot daySnap) {
        clearModel(model);

        // Check for leave
        String leaveStatus = daySnap.child("leaveStatus").getValue(String.class);
        String leaveReason = daySnap.child("leaveReason").getValue(String.class);
        String leaveType = daySnap.child("leaveType").getValue(String.class);

        boolean hasLeave = leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null") && !leaveStatus.equals("NONE");

        if (hasLeave) {
            model.setLeaveStatus(leaveStatus);
            model.setLeaveReason(leaveReason);
            model.setLeaveType(leaveType);

            if ("APPROVED".equalsIgnoreCase(leaveStatus)) {
                model.setStatus("LEAVE");
            } else if ("PENDING".equalsIgnoreCase(leaveStatus)) {
                model.setStatus("LEAVE_PENDING");
            } else if ("REJECTED".equalsIgnoreCase(leaveStatus)) {
                model.setStatus("LEAVE_REJECTED");
            } else {
                model.setStatus("LEAVE");
            }

            model.setInStatus("Leave Day");
            model.setOutStatus("Leave Day");
            model.setTotalHours("0h 0m");
            model.setOvertime("0h 0m");
            return;
        }

        // Get punch data
        String punchIn = daySnap.child("punchIn").getValue(String.class);
        String punchOut = daySnap.child("punchOut").getValue(String.class);
        String punchInTime = daySnap.child("punchInTime").getValue(String.class);
        String punchOutTime = daySnap.child("punchOutTime").getValue(String.class);

        String actualPunchIn = punchIn != null && !punchIn.isEmpty() ? punchIn : punchInTime;
        String actualPunchOut = punchOut != null && !punchOut.isEmpty() ? punchOut : punchOutTime;

        if (actualPunchIn != null && !actualPunchIn.isEmpty() && !actualPunchIn.equals("null")) {
            model.setPunchIn(actualPunchIn);
            model.setPunchOut(actualPunchOut);

            String inStatus = calculatePunchInStatus(actualPunchIn);
            model.setInStatus(inStatus);

            if (actualPunchOut != null && !actualPunchOut.isEmpty() && !actualPunchOut.equals("null")) {
                String totalHours = calculateTotalHours(actualPunchIn, actualPunchOut);
                model.setTotalHours(totalHours);

                String status = calculateAttendanceStatus(actualPunchIn, actualPunchOut);
                model.setStatus(status);
                model.setOutStatus(status);

                calculateOvertime(model);
            } else {
                model.setStatus("HALF_DAY");
                model.setOutStatus("No Punch Out");
                model.setTotalHours("0h 0m");
                model.setOvertime("0h 0m");
            }
        } else {
            markNoDataDay(model);
        }
    }

    private void markNoDataDay(CalendarDayModel model) {
        clearModel(model);

        Date date = DateUtils.parseDate(model.getDate(), DateUtils.FORMAT_DATE_ONLY);
        if (date == null) return;

        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        String dayOfWeek = new SimpleDateFormat("EEEE", Locale.getDefault()).format(date);

        if (DateUtils.isFutureDate(date)) {
            model.setStatus("FUTURE");
            return;
        }

        if (!isWorkingDay(dayOfWeek)) {
            model.setStatus("HOLIDAY");
            return;
        }

        if (DateUtils.isToday(date)) {
            model.setStatus("TODAY");
            return;
        }

        if (DateUtils.isPastDate(date)) {
            model.setStatus("ABSENT");
            model.setInStatus("No Punch");
            model.setOutStatus("No Punch");
            model.setTotalHours("0h 0m");
            model.setOvertime("0h 0m");
        }
    }

    private void clearModel(CalendarDayModel model) {
        model.setPunchIn(null);
        model.setPunchOut(null);
        model.setTotalHours("0h 0m");
        model.setOvertime("0h 0m");
        model.setInStatus(null);
        model.setOutStatus(null);
        model.setLeaveReason(null);
        model.setLeaveStatus(null);
        model.setLeaveType(null);
    }

    // ---------------------- CALCULATION METHODS ----------------------
    private String calculatePunchInStatus(String punchInTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date punchIn = sdf.parse(punchInTime);
            Date officeStart = sdf.parse(officeStartTime);

            long diff = punchIn.getTime() - officeStart.getTime();
            long minutesLate = diff / (1000 * 60);

            if (minutesLate <= 0) {
                return "Early";
            } else if (minutesLate <= lateThresholdMinutes) {
                return "On Time";
            } else {
                return "Late";
            }
        } catch (Exception e) {
            return "On Time";
        }
    }

    private String calculateAttendanceStatus(String punchIn, String punchOut) {
        try {
            double totalHours = calculateTotalHoursDecimal(punchIn, punchOut);
            boolean isLate = isLatePunch(punchIn);

            if (totalHours >= requiredWorkingHours) {
                return isLate ? "LATE" : "PRESENT";
            } else if (totalHours >= halfDayThresholdHours) {
                return "HALF_DAY";
            } else {
                return "ABSENT";
            }
        } catch (Exception e) {
            return "PRESENT";
        }
    }

    private boolean isLatePunch(String punchInTime) {
        try {
            if (punchInTime == null || punchInTime.isEmpty() || punchInTime.equals("--:--")) {
                return false;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date punchIn = sdf.parse(punchInTime);
            Date officeStart = sdf.parse(officeStartTime);

            long diff = punchIn.getTime() - officeStart.getTime();
            long minutesLate = diff / (1000 * 60);

            return minutesLate > lateThresholdMinutes;
        } catch (Exception e) {
            return false;
        }
    }

    private double calculateTotalHoursDecimal(String punchIn, String punchOut) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date inTime = sdf.parse(punchIn);
            Date outTime = sdf.parse(punchOut);

            long diff = outTime.getTime() - inTime.getTime();
            long totalMinutes = diff / (1000 * 60);

            return totalMinutes / 60.0;
        } catch (Exception e) {
            return 0.0;
        }
    }

    private String calculateTotalHours(String punchIn, String punchOut) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date inTime = sdf.parse(punchIn);
            Date outTime = sdf.parse(punchOut);

            long diff = outTime.getTime() - inTime.getTime();
            long totalMinutes = diff / (1000 * 60);
            long hours = totalMinutes / 60;
            long minutes = totalMinutes % 60;

            return hours + "h " + minutes + "m";
        } catch (Exception e) {
            return "0h 0m";
        }
    }

    private void calculateOvertime(CalendarDayModel model) {
        try {
            String totalHours = model.getTotalHours();
            if (totalHours == null || totalHours.equals("0h 0m")) {
                model.setOvertime("0h 0m");
                return;
            }

            String[] parts = totalHours.split("h ");
            int hours = Integer.parseInt(parts[0]);
            int minutes = parts.length > 1 ? Integer.parseInt(parts[1].replace("m", "")) : 0;

            int requiredTotalMinutes = (int)(requiredWorkingHours * 60);
            int workedTotalMinutes = (hours * 60) + minutes;

            if (workedTotalMinutes > requiredTotalMinutes) {
                int overtimeMinutes = workedTotalMinutes - requiredTotalMinutes;
                int overtimeHours = overtimeMinutes / 60;
                int overtimeMins = overtimeMinutes % 60;

                model.setOvertime(overtimeHours + "h " + overtimeMins + "m");
            } else {
                model.setOvertime("0h 0m");
            }
        } catch (Exception e) {
            model.setOvertime("0h 0m");
        }
    }

    // ---------------------- TODAY ATTENDANCE ----------------------
    private void setupTodayAttendanceListener() {
        String todayKey = keyDateFormat.format(new Date());
        DatabaseReference todayRef = attendanceRef.child(todayKey);

        if (todayAttendanceListener != null) {
            todayRef.removeEventListener(todayAttendanceListener);
        }

        todayAttendanceListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                updateTodayPunchCard(snapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (isAdded()) {
                    Toast.makeText(getContext(), "Error loading today's attendance", Toast.LENGTH_SHORT).show();
                }
            }
        };

        todayRef.addValueEventListener(todayAttendanceListener);
    }

    @SuppressLint("SetTextI18n")
    private void updateTodayPunchCard(DataSnapshot todaySnapshot) {
        if (!isAdded()) return;

        // Default values
        tvPunchInTime.setText("--:--");
        tvPunchInStatus.setText("Not Punched");
        tvPunchOutTime.setText("--:--");
        tvPunchOutStatus.setText("Not Punched");
        tvTotalHours.setText("0h 0m");
        tvOvertime.setText("0h 0m");
        tvRemainingHours.setText(getRequiredHoursString());
        tvTodayStatus.setText("Not Punched");
        setStatusColor(tvTodayStatus, "NOT_PUNCHED");

        if (!todaySnapshot.exists()) {
            return;
        }

        // Check for leave
        String leaveStatus = todaySnapshot.child("leaveStatus").getValue(String.class);
        if (leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null")) {
            updateTodayLeaveUI(leaveStatus);
            return;
        }

        // Get punch data
        String punchIn = todaySnapshot.child("punchIn").getValue(String.class);
        String punchOut = todaySnapshot.child("punchOut").getValue(String.class);
        String punchInTime = todaySnapshot.child("punchInTime").getValue(String.class);
        String punchOutTime = todaySnapshot.child("punchOutTime").getValue(String.class);

        String actualPunchIn = punchIn != null && !punchIn.isEmpty() ? punchIn : punchInTime;
        String actualPunchOut = punchOut != null && !punchOut.isEmpty() ? punchOut : punchOutTime;

        // Update punch in
        if (actualPunchIn != null && !actualPunchIn.isEmpty()) {
            tvPunchInTime.setText(convertTo12HourFormatShort(actualPunchIn));
            String inStatus = calculatePunchInStatus(actualPunchIn);
            tvPunchInStatus.setText(inStatus);
            setStatusColor(tvPunchInStatus, inStatus);
        }

        // Update punch out
        if (actualPunchOut != null && !actualPunchOut.isEmpty()) {
            tvPunchOutTime.setText(convertTo12HourFormatShort(actualPunchOut));
            tvPunchOutStatus.setText("Punched Out");
            setStatusColor(tvPunchOutStatus, "PRESENT");
        } else {
            tvPunchOutStatus.setText("Not Punched");
            setStatusColor(tvPunchOutStatus, "NOT_PUNCHED");
        }

        // Calculate total hours
        String totalHours = "0h 0m";
        if (actualPunchIn != null && !actualPunchIn.isEmpty()) {
            if (actualPunchOut != null && !actualPunchOut.isEmpty()) {
                totalHours = calculateTotalHours(actualPunchIn, actualPunchOut);
            } else {
                String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                totalHours = calculateTotalHours(actualPunchIn, currentTime);
            }
        }
        tvTotalHours.setText(totalHours);

        // Calculate overtime
        String overtime = calculateTodayOvertime(totalHours);
        tvOvertime.setText(overtime);

        // Calculate remaining hours
        tvRemainingHours.setText(calculateRemainingHours(totalHours));

        // Set today's status
        String todayStatus = calculateTodayStatus(actualPunchIn, actualPunchOut, totalHours);
        tvTodayStatus.setText(todayStatus);
        setStatusColor(tvTodayStatus, todayStatus);
    }

    private String getRequiredHoursString() {
        int hours = (int) requiredWorkingHours;
        int minutes = (int) ((requiredWorkingHours - hours) * 60);
        return hours + "h " + minutes + "m";
    }

    private void updateTodayLeaveUI(String leaveStatus) {
        tvPunchInTime.setText("Leave Day");
        tvPunchInStatus.setText(leaveStatus);
        tvPunchOutTime.setText("--:--");
        tvPunchOutStatus.setText("Leave Day");
        tvTotalHours.setText("0h 0m");
        tvOvertime.setText("0h 0m");
        tvRemainingHours.setText(getRequiredHoursString());
        tvTodayStatus.setText("Leave (" + leaveStatus + ")");

        if ("APPROVED".equalsIgnoreCase(leaveStatus)) {
            tvTodayStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.blue_info));
        } else if ("PENDING".equalsIgnoreCase(leaveStatus)) {
            tvTodayStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.orange_warning));
        } else if ("REJECTED".equalsIgnoreCase(leaveStatus)) {
            tvTodayStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.red_error));
        }
    }

    private String calculateTodayOvertime(String totalHours) {
        try {
            if (totalHours == null || totalHours.equals("0h 0m")) {
                return "0h 0m";
            }

            String[] parts = totalHours.split("h ");
            int hours = Integer.parseInt(parts[0]);
            int minutes = parts.length > 1 ? Integer.parseInt(parts[1].replace("m", "")) : 0;

            int requiredTotalMinutes = (int)(requiredWorkingHours * 60);
            int workedTotalMinutes = (hours * 60) + minutes;

            if (workedTotalMinutes > requiredTotalMinutes) {
                int overtimeMinutes = workedTotalMinutes - requiredTotalMinutes;
                int overtimeHours = overtimeMinutes / 60;
                int overtimeMins = overtimeMinutes % 60;

                return overtimeHours + "h " + overtimeMins + "m";
            } else {
                return "0h 0m";
            }
        } catch (Exception e) {
            return "0h 0m";
        }
    }

    private String calculateRemainingHours(String totalHours) {
        try {
            String[] parts = totalHours.split("h ");
            int workedHours = Integer.parseInt(parts[0]);
            int workedMinutes = parts.length > 1 ? Integer.parseInt(parts[1].replace("m", "")) : 0;

            int requiredTotalMinutes = (int)(requiredWorkingHours * 60);
            int totalWorkedMinutes = (workedHours * 60) + workedMinutes;

            int remainingMinutes = Math.max(0, requiredTotalMinutes - totalWorkedMinutes);

            int remainingHours = remainingMinutes / 60;
            int remainingMins = remainingMinutes % 60;

            return remainingHours + "h " + remainingMins + "m";
        } catch (Exception e) {
            return getRequiredHoursString();
        }
    }

    private String calculateTodayStatus(String punchIn, String punchOut, String totalHours) {
        if (punchIn == null || punchIn.isEmpty()) {
            return "Not Punched";
        }

        if (punchOut == null || punchOut.isEmpty()) {
            return "Working";
        }

        try {
            double totalHoursDecimal = calculateTotalHoursDecimal(punchIn, punchOut);
            boolean isLate = isLatePunch(punchIn);

            if (totalHoursDecimal >= requiredWorkingHours) {
                return isLate ? "Late" : "Present";
            } else if (totalHoursDecimal >= halfDayThresholdHours) {
                return "Half Day";
            } else {
                return "Short Hours";
            }
        } catch (Exception e) {
            return "Present";
        }
    }

    // ---------------------- MONTHLY STATS ----------------------
    private void calculateMonthlyStats() {
        int presentDays = 0;
        int absentDays = 0;
        int leaveDays = 0;
        int halfDays = 0;
        int lateDays = 0;

        String currentMonthKey = monthKeyFormat.format(currentMonth.getTime());

        for (CalendarDayModel model : dayList) {
            if (model.isEmptyCell() || model.getDate() == null || model.getDate().isEmpty()) {
                continue;
            }

            if (!model.getDate().startsWith(currentMonthKey)) {
                continue;
            }

            Date date = DateUtils.parseDate(model.getDate(), DateUtils.FORMAT_DATE_ONLY);
            if (date != null) {
                String dayOfWeek = new SimpleDateFormat("EEEE", Locale.getDefault()).format(date);

                // Skip future dates and non-working days
                if (DateUtils.isFutureDate(date) || !isWorkingDay(dayOfWeek)) {
                    continue;
                }
            }

            String status = model.getStatus();
            if (status == null) continue;

            switch (status.toUpperCase()) {
                case "PRESENT":
                    presentDays++;
                    break;
                case "ABSENT":
                    absentDays++;
                    break;
                case "LEAVE":
                    leaveDays++;
                    break;
                case "HALF_DAY":
                    halfDays++;
                    break;
                case "LATE":
                    lateDays++;
                    break;
                case "LEAVE_PENDING":
                case "LEAVE_REJECTED":
                    leaveDays++;
                    break;
            }
        }

        // Update UI
        tvPresentDays.setText(String.valueOf(presentDays));
        tvAbsentDays.setText(String.valueOf(absentDays));
        tvLeaveDays.setText(String.valueOf(leaveDays));
        tvHalfDay.setText(String.valueOf(halfDays));
    }

    private void setStatusColor(TextView textView, String status) {
        if (getContext() == null || textView == null) return;

        int colorId;
        switch (status != null ? status.toUpperCase() : "") {
            case "PRESENT":
            case "ON TIME":
                colorId = R.color.green_success;
                break;
            case "HALF_DAY":
            case "LATE":
            case "SHORT HOURS":
                colorId = R.color.orange_warning;
                break;
            case "ABSENT":
            case "LEAVE_REJECTED":
                colorId = R.color.red_error;
                break;
            case "LEAVE":
                colorId = R.color.blue_info;
                break;
            case "LEAVE_PENDING":
                colorId = R.color.orange_warning;
                break;
            case "WORKING":
                colorId = R.color.blue_info;
                break;
            case "HOLIDAY":
            case "SUNDAY":
                colorId = R.color.gray_default;
                break;
            case "NOT_PUNCHED":
            case "NO PUNCH":
                colorId = R.color.gray_default;
                break;
            default:
                colorId = R.color.text_primary;
                break;
        }

        textView.setTextColor(ContextCompat.getColor(getContext(), colorId));
    }

    // ---------------------- LIFECYCLE METHODS ----------------------
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        stopLiveTime();

        if (monthAttendanceListener != null && attendanceRef != null) {
            attendanceRef.removeEventListener(monthAttendanceListener);
        }

        if (todayAttendanceListener != null && attendanceRef != null) {
            String todayKey = keyDateFormat.format(new Date());
            DatabaseReference todayRef = attendanceRef.child(todayKey);
            todayRef.removeEventListener(todayAttendanceListener);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        stopLiveTime();
    }

    @Override
    public void onResume() {
        super.onResume();
        startLiveTime();
    }
}