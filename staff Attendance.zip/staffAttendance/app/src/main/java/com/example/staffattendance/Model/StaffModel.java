package com.example.staffattendance.Model;

public class StaffModel {

    // Core fields from Firebase Employees node
    private String empId;
    private String name;
    private String phone;
    private String email;
    private String department;
    private String role;
    private String joiningDate;
    private String address;
    private String companyName;
    private String password;

    private String accountStatus;

    // ✅ ADDED
    private String activeStatus;
    private Long lastActive;

    private String attendanceStatus;
    private boolean firstLogin;

    // Daily attendance fields - consolidated
    private String status;
    private String punchIn;
    private String punchOut;
    // Keep these for backward compatibility
    private String checkIn;
    private String checkOut;

    // App related fields
    private boolean appActive;
    private String profileImage;
    private long lastUpdated;

    // Required empty constructor for Firebase
    public StaffModel() {
        this.status = "NO_PUNCH";
        this.accountStatus = "inactive";
    }

    // Constructor with minimum required fields
    public StaffModel(String empId, String name, String phone) {
        this.empId = empId;
        this.name = name;
        this.phone = phone;
        this.status = "NO_PUNCH";
        this.accountStatus = "inactive";
        this.firstLogin = true;
        this.appActive = false;
    }

    // Full constructor
    public StaffModel(String empId, String name, String phone, String email,
                      String department, String role, String joiningDate,
                      String address, String companyName, String password,
                      String accountStatus, String attendanceStatus, boolean firstLogin) {
        this.empId = empId;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.department = department;
        this.role = role;
        this.joiningDate = joiningDate;
        this.address = address;
        this.companyName = companyName;
        this.password = password;
        this.accountStatus = accountStatus;
        this.attendanceStatus = attendanceStatus;
        this.firstLogin = firstLogin;
        this.status = "NO_PUNCH";
        this.appActive = "active".equalsIgnoreCase(accountStatus);
    }

    // ===== GETTERS =====

    public String getEmpId() {
        return empId != null ? empId : "";
    }

    public String getName() {
        return name != null ? name : "";
    }

    public String getPhone() {
        return phone != null ? phone : "";
    }

    public String getEmail() {
        return email != null ? email : "";
    }

    public String getDepartment() {
        return department != null ? department : "";
    }

    public String getRole() {
        return role != null ? role : "";
    }

    public String getJoiningDate() {
        return joiningDate != null ? joiningDate : "";
    }

    public String getAddress() {
        return address != null ? address : "";
    }

    public String getCompanyName() {
        return companyName != null ? companyName : "";
    }

    public String getPassword() {
        return password != null ? password : "";
    }

    public String getAccountStatus() {
        return accountStatus != null ? accountStatus : "inactive";
    }

    // ✅ ADDED
    public String getActiveStatus() {
        return activeStatus != null ? activeStatus : "offline";
    }

    public Long getLastActive() {
        return lastActive != null ? lastActive : 0L;
    }

    public String getAttendanceStatus() {
        return attendanceStatus != null ? attendanceStatus : "NOT_MARKED";
    }

    public boolean isFirstLogin() {
        return firstLogin;
    }

    public String getStatus() {
        return status != null ? status : "NO_PUNCH";
    }

    public String getPunchIn() {
        return punchIn;
    }

    public String getPunchOut() {
        return punchOut;
    }

    /**
     * FIXED: Get check-in time - returns formatted time string
     * Returns "--" if no time is available for adapter display
     */
    public String getCheckIn() {
        // First try punchIn
        if (punchIn != null && !punchIn.isEmpty() && !"--".equals(punchIn) && !"null".equals(punchIn)) {
            return formatTime(punchIn);
        }
        // Then try checkIn
        if (checkIn != null && !checkIn.isEmpty() && !"--".equals(checkIn) && !"null".equals(checkIn)) {
            return formatTime(checkIn);
        }
        // Return "--" for adapter to display as no punch
        return "--";
    }

    /**
     * FIXED: Get check-out time - returns formatted time string
     * Returns "--" if no time is available for adapter display
     */
    public String getCheckOut() {
        // First try punchOut
        if (punchOut != null && !punchOut.isEmpty() && !"--".equals(punchOut) && !"null".equals(punchOut)) {
            return formatTime(punchOut);
        }
        // Then try checkOut
        if (checkOut != null && !checkOut.isEmpty() && !"--".equals(checkOut) && !"null".equals(checkOut)) {
            return formatTime(checkOut);
        }
        // Return "--" for adapter to display as no punch
        return "--";
    }

    /**
     * Helper method to format time consistently
     */
    private String formatTime(String time) {
        if (time == null || time.isEmpty() || "--".equals(time) || "null".equals(time)) {
            return "--";
        }

        // If time already contains AM/PM, return as is
        if (time.contains("AM") || time.contains("PM") || time.contains("am") || time.contains("pm")) {
            return time;
        }

        // If time is in HH:mm format, try to convert to hh:mm AM/PM
        try {
            if (time.matches("\\d{2}:\\d{2}")) {
                String[] parts = time.split(":");
                int hour = Integer.parseInt(parts[0]);
                int minute = Integer.parseInt(parts[1]);

                String period = hour >= 12 ? "PM" : "AM";
                int displayHour = hour > 12 ? hour - 12 : hour;
                if (displayHour == 0) displayHour = 12;

                return String.format("%02d:%02d %s", displayHour, minute, period);
            }
        } catch (Exception e) {
            // Return original if parsing fails
        }

        return time;
    }

    public boolean isAppActive() {
        return appActive || "active".equalsIgnoreCase(accountStatus);
    }

    public String getProfileImage() {
        return profileImage != null ? profileImage : "";
    }

    public long getLastUpdated() {
        return lastUpdated;
    }

    public String getEmployeeId() {
        return getEmpId();
    }

    // ===== SETTERS =====

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
        this.appActive = "active".equalsIgnoreCase(accountStatus);
    }

    // ✅ ADDED
    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public void setLastActive(Long lastActive) {
        this.lastActive = lastActive;
    }

    public void setAttendanceStatus(String attendanceStatus) {
        this.attendanceStatus = attendanceStatus;
    }

    public void setFirstLogin(boolean firstLogin) {
        this.firstLogin = firstLogin;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setPunchIn(String punchIn) {
        this.punchIn = punchIn;
        // Also update checkIn for backward compatibility
        if (punchIn != null && !punchIn.isEmpty() && !"--".equals(punchIn)) {
            this.checkIn = punchIn;
        }
    }

    public void setPunchOut(String punchOut) {
        this.punchOut = punchOut;
        // Also update checkOut for backward compatibility
        if (punchOut != null && !punchOut.isEmpty() && !"--".equals(punchOut)) {
            this.checkOut = punchOut;
        }
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = checkIn;
        // Also update punchIn for backward compatibility
        if (checkIn != null && !checkIn.isEmpty() && !"--".equals(checkIn)) {
            this.punchIn = checkIn;
        }
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = checkOut;
        // Also update punchOut for backward compatibility
        if (checkOut != null && !checkOut.isEmpty() && !"--".equals(checkOut)) {
            this.punchOut = checkOut;
        }
    }

    public void setAppActive(boolean appActive) {
        this.appActive = appActive;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public void setEmployeeId(String employeeId) {
        this.empId = employeeId;
    }

    @Override
    public String toString() {
        return "StaffModel{" +
                "empId='" + empId + '\'' +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", status='" + status + '\'' +
                ", accountStatus='" + accountStatus + '\'' +
                ", punchIn='" + punchIn + '\'' +
                ", punchOut='" + punchOut + '\'' +
                ", checkIn='" + checkIn + '\'' +
                ", checkOut='" + checkOut + '\'' +
                '}';
    }
}