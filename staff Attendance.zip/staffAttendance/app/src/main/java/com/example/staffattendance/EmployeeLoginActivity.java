package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.staffattendance.Model.EmployeesModel;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeLoginActivity extends AppCompatActivity {

    // UI Components
    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView forgotEmpId, switchToAdmin, quickPunch, helpSupport;
    private View topDecoration, bottomDecoration;

    private EmployeesModel matchedEmployee;

    private String selectedCompanyKey = "";
    private String selectedCompanyName = "";
    private String selectedEmpId = "";

    private final Map<String, String> companyMap = new HashMap<>();
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_login);

        sessionManager = new SessionManager(this);

        // Clear session if coming from logout
        boolean fromLogout = getIntent().getBooleanExtra("fromLogout", false);
        if (fromLogout) {
            sessionManager.logout();
        }

        // Check if user is already logged in
        if (!fromLogout &&
                sessionManager.isLoggedIn() &&
                !sessionManager.isSessionExpired() &&
                !TextUtils.isEmpty(sessionManager.getCompanyKey()) &&
                !TextUtils.isEmpty(sessionManager.getEmpId())) {
            openDashboardDirect();
            return;
        }

        initViews();
        setListeners();
        setupAnimations();
    }

    private void initViews() {
        topDecoration = findViewById(R.id.topDecoration);
        bottomDecoration = findViewById(R.id.bottomDecoration);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etEmpId); // This is actually password field based on your XML
        btnLogin = findViewById(R.id.btnLogin);
        forgotEmpId = findViewById(R.id.forgotEmpId);
        switchToAdmin = findViewById(R.id.switchToAdmin);
        quickPunch = findViewById(R.id.quickPunch);
        helpSupport = findViewById(R.id.helpSupport);
    }

    private void setListeners() {
        btnLogin.setOnClickListener(v -> {
            v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100));
            validateInputs();
        });

        forgotEmpId.setOnClickListener(v -> {
            showForgotPasswordDialog();
        });

        switchToAdmin.setOnClickListener(v -> {
            Intent intent = new Intent(EmployeeLoginActivity.this, LoginActivity.class);
            intent.putExtra("isAdminLogin", true);
            startActivity(intent);
            finish();
        });

        quickPunch.setOnClickListener(v -> {
            Toast.makeText(this, "Quick Punch - Coming Soon", Toast.LENGTH_SHORT).show();
        });

        helpSupport.setOnClickListener(v -> {
            openHelpSupport();
        });
    }

    private void setupAnimations() {
        topDecoration.animate()
                .translationY(-20)
                .setDuration(2000)
                .alpha(0.1f)
                .start();

        bottomDecoration.animate()
                .translationY(20)
                .setDuration(2000)
                .alpha(0.05f)
                .start();
    }

    private void validateInputs() {
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Enter Email Address");
            etEmail.requestFocus();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter valid email address");
            etEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Enter Password");
            etPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            etPassword.requestFocus();
            return;
        }

        btnLogin.setText("Logging in...");
        btnLogin.setEnabled(false);

        checkCredentials(email, password);
    }

    private void checkCredentials(String email, String password) {
        FirebaseDatabase.getInstance()
                .getReference("Companies")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        companyMap.clear();
                        matchedEmployee = null;

                        for (DataSnapshot companySnap : snapshot.getChildren()) {
                            String companyKey = companySnap.getKey();
                            String companyName = companySnap.child("companyName").getValue(String.class);

                            if (companyKey == null || companyName == null) continue;

                            DataSnapshot employeesSnapshot = companySnap.child("Employees");
                            if (!employeesSnapshot.exists()) continue;

                            for (DataSnapshot empSnap : employeesSnapshot.getChildren()) {
                                EmployeesModel emp = empSnap.getValue(EmployeesModel.class);
                                if (emp == null) continue;

                                // Get password from Firebase - NO DEFAULT PASSWORD
                                String storedPassword = empSnap.child("password").getValue(String.class);

                                // Check if password exists in database
                                if (storedPassword == null || storedPassword.isEmpty()) {
                                    // If no password is set, show message to contact admin
                                    if (email.equalsIgnoreCase(emp.getEmail())) {
                                        btnLogin.setText("Login");
                                        btnLogin.setEnabled(true);
                                        Toast.makeText(EmployeeLoginActivity.this,
                                                "No password set. Please contact admin.",
                                                Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    continue;
                                }

                                // Check email and password
                                if (email.equalsIgnoreCase(emp.getEmail()) && password.equals(storedPassword)) {
                                    matchedEmployee = emp;
                                    selectedEmpId = empSnap.getKey(); // Get employee ID from Firebase key
                                    companyMap.put(companyName, companyKey);
                                }
                            }
                        }

                        if (matchedEmployee == null) {
                            btnLogin.setText("Login");
                            btnLogin.setEnabled(true);
                            Toast.makeText(EmployeeLoginActivity.this,
                                    "Invalid email or password",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        showCompanyPopup();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        btnLogin.setText("Login");
                        btnLogin.setEnabled(true);
                        Toast.makeText(EmployeeLoginActivity.this,
                                "Error: " + error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showCompanyPopup() {
        if (companyMap.size() == 1) {
            for (Map.Entry<String, String> entry : companyMap.entrySet()) {
                selectedCompanyName = entry.getKey();
                selectedCompanyKey = entry.getValue();
            }
            saveSessionAndOpenDashboard();
            return;
        }

        View view = LayoutInflater.from(this)
                .inflate(R.layout.dialog_select_company, null);

        AutoCompleteTextView spCompany = view.findViewById(R.id.spCompany);

        List<String> companies = new ArrayList<>(companyMap.keySet());
        spCompany.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                companies
        ));

        if (!companies.isEmpty()) {
            spCompany.setText(companies.get(0), false);
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Company")
                .setMessage("Select your company:")
                .setView(view)
                .setCancelable(false)
                .setPositiveButton("Continue", (dialog, which) -> {
                    String companyName = spCompany.getText().toString().trim();

                    if (!companyMap.containsKey(companyName)) {
                        Toast.makeText(this, "Select a valid company", Toast.LENGTH_SHORT).show();
                        resetLoginButton();
                        return;
                    }

                    selectedCompanyName = companyName;
                    selectedCompanyKey = companyMap.get(companyName);
                    saveSessionAndOpenDashboard();
                })
                .setNegativeButton("Cancel", (dialog, which) -> resetLoginButton())
                .show();
    }

    private void resetLoginButton() {
        btnLogin.setText("Login");
        btnLogin.setEnabled(true);
    }

    private void saveSessionAndOpenDashboard() {
        if (TextUtils.isEmpty(selectedCompanyKey) ||
                TextUtils.isEmpty(selectedCompanyName) ||
                TextUtils.isEmpty(selectedEmpId) ||
                matchedEmployee == null) {

            Toast.makeText(this, "Login error. Try again.", Toast.LENGTH_SHORT).show();
            resetLoginButton();
            return;
        }

        // Save session
        sessionManager.createLoginSession(
                matchedEmployee.getEmail(),
                "employee",
                selectedCompanyKey,
                selectedEmpId,
                selectedCompanyName,
                matchedEmployee.getName()
        );

        // Save employee data
        sessionManager.saveEmployeeData(
                matchedEmployee.getName(),
                matchedEmployee.getEmail(),
                matchedEmployee.getPhone(),
                matchedEmployee.getRole(),
                matchedEmployee.getStatus()
        );

        // Navigate to dashboard
        Intent intent = new Intent(this, EmployeeDashboardActivity.class);
        intent.putExtra("companyKey", selectedCompanyKey);
        intent.putExtra("companyName", selectedCompanyName);
        intent.putExtra("empId", selectedEmpId);
        intent.putExtra("userName", matchedEmployee.getName());
        startActivity(intent);
        finish();
    }

    private void openDashboardDirect() {
        Intent intent = new Intent(this, EmployeeDashboardActivity.class);
        intent.putExtra("companyKey", sessionManager.getCompanyKey());
        intent.putExtra("empId", sessionManager.getEmpId());
        intent.putExtra("companyName", sessionManager.getCompanyName());
        intent.putExtra("userName", sessionManager.getUserName());
        startActivity(intent);
        finish();
    }

    private void showForgotPasswordDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Forgot Password?")
                .setMessage("Please contact your company administrator to reset your password.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Contact Admin", (dialog, which) -> {
                    // Open email or phone contact
                    Toast.makeText(this, "Contact admin via email/phone", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void openHelpSupport() {
        new AlertDialog.Builder(this)
                .setTitle("Help & Support")
                .setMessage("For assistance, please contact:\n\n" +
                        "• Email: support@company.com\n" +
                        "• Phone: +91-XXXXXXXXXX\n" +
                        "• Hours: 9 AM - 6 PM (Mon-Sat)")
                .setPositiveButton("OK", null)
                .setNeutralButton("Send Email", (dialog, which) -> {
                    Intent emailIntent = new Intent(Intent.ACTION_SEND);
                    emailIntent.setType("message/rfc822");
                    emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"support@company.com"});
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Employee Login Support");
                    startActivity(Intent.createChooser(emailIntent, "Send email..."));
                })
                .show();
    }

    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Exit App")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", (dialog, which) -> finishAffinity())
                .setNegativeButton("No", null)
                .show();
    }
}