package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.staffattendance.Model.EmployeesModel;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.*;

import java.security.MessageDigest;
import java.util.*;

public class EmployeeLoginActivity extends AppCompatActivity {

    private static final String TAG = "EmployeeLogin";

    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView forgotEmpId, switchToAdmin, tvInvalidMessage;

    private EmployeesModel matchedEmployee;
    private String selectedCompanyKey = "", selectedCompanyName = "", selectedEmpId = "";
    private final Map<String, String> companyMap = new HashMap<>();
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_login);

        sessionManager = new SessionManager(this);

        if (sessionManager.isLoggedIn()
                && !sessionManager.isSessionExpired()
                && !TextUtils.isEmpty(sessionManager.getCompanyKey())
                && !TextUtils.isEmpty(sessionManager.getEmpId())) {

            openDashboardDirect();
            return;
        }

        initViews();
        setListeners();
    }

    private void initViews() {

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etEmpId);
        btnLogin = findViewById(R.id.btnLogin);
        forgotEmpId = findViewById(R.id.forgotEmpId);
        switchToAdmin = findViewById(R.id.switchToAdmin);
        tvInvalidMessage = findViewById(R.id.tvInvalidMessage);
    }

    private void setListeners() {

        btnLogin.setOnClickListener(v -> validateInputs());

        forgotEmpId.setOnClickListener(v -> showForgotPasswordDialog());

        switchToAdmin.setOnClickListener(v -> {
            startActivity(new Intent(EmployeeLoginActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void validateInputs() {

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Enter Email");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Enter Password");
            return;
        }

        btnLogin.setText("Logging in...");
        btnLogin.setEnabled(false);

        checkCredentials(email, password);
    }

    private void checkCredentials(String email, String password) {

        Log.d(TAG, "Login attempt: " + email);

        FirebaseDatabase.getInstance()
                .getReference("Companies")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        matchedEmployee = null;
                        companyMap.clear();

                        String hashedInput = hashPassword(password);

                        for (DataSnapshot companySnap : snapshot.getChildren()) {

                            String companyKey = companySnap.getKey();
                            String companyName = companySnap.child("companyName").getValue(String.class);

                            if (!companySnap.hasChild("Employees")) continue;

                            for (DataSnapshot empSnap : companySnap.child("Employees").getChildren()) {

                                EmployeesModel emp = empSnap.getValue(EmployeesModel.class);
                                if (emp == null) continue;

                                String empEmail = emp.getEmail();
                                // FIXED: Get password field correctly
                                String storedPassword = empSnap.child("password").getValue(String.class);

                                if (storedPassword == null) continue;

                                if (email.equalsIgnoreCase(empEmail)
                                        && hashedInput.equals(storedPassword)) {

                                    matchedEmployee = emp;
                                    selectedEmpId = empSnap.getKey();
                                    companyMap.put(companyName, companyKey);

                                    // Update first login if needed
                                    Boolean firstLogin = empSnap.child("firstLogin").getValue(Boolean.class);
                                    if (firstLogin != null && firstLogin) {
                                        empSnap.getRef().child("firstLogin").setValue(false);
                                    }
                                    break;
                                }
                            }

                            if (matchedEmployee != null) break;
                        }

                        if (matchedEmployee == null) {

                            btnLogin.setText("Login");
                            btnLogin.setEnabled(true);

                            Toast.makeText(EmployeeLoginActivity.this,
                                    "Invalid email or password",
                                    Toast.LENGTH_SHORT).show();

                            return;
                        }

                        if (companyMap.size() == 1) {

                            for (Map.Entry<String, String> entry : companyMap.entrySet()) {
                                selectedCompanyName = entry.getKey();
                                selectedCompanyKey = entry.getValue();
                            }

                            saveSessionAndOpenDashboard();

                        } else {

                            showCompanyPopup();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                        btnLogin.setText("Login");
                        btnLogin.setEnabled(true);

                        Toast.makeText(EmployeeLoginActivity.this,
                                error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showCompanyPopup() {

        View view = LayoutInflater.from(this)
                .inflate(R.layout.dialog_select_company, null);

        AutoCompleteTextView spCompany = view.findViewById(R.id.spCompany);

        List<String> companies = new ArrayList<>(companyMap.keySet());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                companies
        );

        spCompany.setAdapter(adapter);

        new AlertDialog.Builder(this)
                .setTitle("Select Company")
                .setView(view)
                .setPositiveButton("Continue", (dialog, which) -> {

                    String companyName = spCompany.getText().toString().trim();

                    selectedCompanyName = companyName;
                    selectedCompanyKey = companyMap.get(companyName);

                    saveSessionAndOpenDashboard();
                })
                .show();
    }

    private void saveSessionAndOpenDashboard() {

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(selectedCompanyKey)
                .child("Employees")
                .child(selectedEmpId);

        Map<String, Object> updates = new HashMap<>();
        updates.put("accountStatus", "active");
        updates.put("lastLogin", System.currentTimeMillis());

        ref.updateChildren(updates);

        sessionManager.createLoginSession(
                matchedEmployee.getEmail(),
                "employee",
                selectedCompanyKey,
                selectedEmpId,
                selectedCompanyName,
                matchedEmployee.getName()
        );

        Intent intent = new Intent(this, EmployeeDashboardActivity.class);
        intent.putExtra("companyKey", selectedCompanyKey);
        intent.putExtra("empId", selectedEmpId);
        intent.putExtra("companyName", selectedCompanyName);
        intent.putExtra("userName", matchedEmployee.getName());

        startActivity(intent);
        finish();
    }

    private void openDashboardDirect() {

        Intent intent = new Intent(this, EmployeeDashboardActivity.class);

        intent.putExtra("companyKey", sessionManager.getCompanyKey());
        intent.putExtra("empId", sessionManager.getEmpId());
        intent.putExtra("companyName", sessionManager.getCompanyName());
        intent.putExtra("userName", sessionManager.getUserName());

        startActivity(intent);
        finish();
    }

    private void showForgotPasswordDialog() {

        new AlertDialog.Builder(this)
                .setTitle("Forgot Password?")
                .setMessage("Contact admin to reset password")
                .setPositiveButton("OK", null)
                .show();
    }

    private String hashPassword(String password) {

        try {

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes());

            StringBuilder sb = new StringBuilder();

            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();

        } catch (Exception e) {
            return password;
        }
    }

    @SuppressLint({"MissingSuperCall", "GestureBackNavigation"})
    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Close app?")
                .setPositiveButton("Yes", (d, w) -> finishAffinity())
                .setNegativeButton("No", null)
                .show();
    }
}