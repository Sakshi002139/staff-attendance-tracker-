package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class AdminChangePasswordActivity extends AppCompatActivity {

    private static final String TAG = "AdminChangePassword";

    private MaterialToolbar toolbar;
    private TextInputEditText etCurrentPassword, etNewPassword, etConfirmPassword;
    private MaterialButton btnChangePassword;
    private ProgressBar progressBar;
    private TextInputLayout layoutCurrentPassword, layoutNewPassword, layoutConfirmPassword;

    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private SessionManager sessionManager;

    private String companyKey;
    private String adminPhone;
    private String adminEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_change_password);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        sessionManager = new SessionManager(this);

        // Get session data
        companyKey = sessionManager.getCompanyKey();
        adminPhone = sessionManager.getUserPhone();
        adminEmail = sessionManager.getUserEmail();

        FirebaseUser currentUser = mAuth.getCurrentUser();

        Log.d(TAG, "Company Key: " + companyKey);
        Log.d(TAG, "Admin Phone: " + adminPhone);
        Log.d(TAG, "Admin Email: " + adminEmail);

        // Initialize views
        initViews();

        // Setup toolbar
        setupToolbar();

        // Check if user is logged in
        if (currentUser == null) {
            Toast.makeText(this, "Please login again", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Setup click listener
        btnChangePassword.setOnClickListener(v -> validateAndChangePassword());
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);

        layoutCurrentPassword = findViewById(R.id.layoutCurrentPassword);
        layoutNewPassword = findViewById(R.id.layoutNewPassword);
        layoutConfirmPassword = findViewById(R.id.layoutConfirmPassword);

        etCurrentPassword = findViewById(R.id.etCurrentPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnChangePassword = findViewById(R.id.btnChangePassword);
        progressBar = findViewById(R.id.progressBar);

        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Change Password");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void validateAndChangePassword() {
        String currentPassword = etCurrentPassword.getText() != null ? etCurrentPassword.getText().toString().trim() : "";
        String newPassword = etNewPassword.getText() != null ? etNewPassword.getText().toString().trim() : "";
        String confirmPassword = etConfirmPassword.getText() != null ? etConfirmPassword.getText().toString().trim() : "";

        // Validate inputs
        if (TextUtils.isEmpty(currentPassword)) {
            layoutCurrentPassword.setError("Current password is required");
            etCurrentPassword.requestFocus();
            return;
        } else {
            layoutCurrentPassword.setError(null);
        }

        if (TextUtils.isEmpty(newPassword)) {
            layoutNewPassword.setError("New password is required");
            etNewPassword.requestFocus();
            return;
        } else {
            layoutNewPassword.setError(null);
        }

        if (newPassword.length() < 6) {
            layoutNewPassword.setError("Password must be at least 6 characters");
            etNewPassword.requestFocus();
            return;
        } else {
            layoutNewPassword.setError(null);
        }

        if (TextUtils.isEmpty(confirmPassword)) {
            layoutConfirmPassword.setError("Please confirm your password");
            etConfirmPassword.requestFocus();
            return;
        } else {
            layoutConfirmPassword.setError(null);
        }

        if (!newPassword.equals(confirmPassword)) {
            layoutConfirmPassword.setError("Passwords do not match");
            etConfirmPassword.requestFocus();
            return;
        } else {
            layoutConfirmPassword.setError(null);
        }

        // Verify current password using Firebase Auth
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        showLoading(true);
        btnChangePassword.setText("Verifying...");

        // Re-authenticate the user to verify current password
        com.google.firebase.auth.AuthCredential credential =
                com.google.firebase.auth.EmailAuthProvider.getCredential(adminEmail, currentPassword);

        user.reauthenticate(credential)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Current password is correct, now update password
                        updatePassword(user, newPassword);
                    } else {
                        showLoading(false);
                        btnChangePassword.setText("Change Password");
                        layoutCurrentPassword.setError("Current password is incorrect");
                        etCurrentPassword.requestFocus();

                        String errorMsg = task.getException() != null ?
                                task.getException().getMessage() : "Unknown error";
                        Log.e(TAG, "Re-authentication failed: " + errorMsg);
                    }
                });
    }

    private void updatePassword(FirebaseUser user, String newPassword) {
        user.updatePassword(newPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Password updated in Auth, now update in Database
                        updatePasswordInDatabase(newPassword);
                    } else {
                        showLoading(false);
                        btnChangePassword.setText("Change Password");
                        String errorMsg = task.getException() != null ?
                                task.getException().getMessage() : "Unknown error";
                        Toast.makeText(this, "Failed: " + errorMsg, Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void updatePasswordInDatabase(String newPassword) {
        String hashedPassword = hashPassword(newPassword);

        DatabaseReference adminRef = databaseReference.child("Companies")
                .child(companyKey)
                .child("Admins")
                .child(adminPhone);

        adminRef.child("password").setValue(hashedPassword)
                .addOnSuccessListener(aVoid -> {
                    showLoading(false);
                    Toast.makeText(this, "Password changed successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    showLoading(false);
                    btnChangePassword.setText("Change Password");
                    Toast.makeText(this, "Failed to update in database: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void showLoading(boolean show) {
        if (progressBar != null) {
            progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        }
        btnChangePassword.setEnabled(!show);
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes());

            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return password;
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}