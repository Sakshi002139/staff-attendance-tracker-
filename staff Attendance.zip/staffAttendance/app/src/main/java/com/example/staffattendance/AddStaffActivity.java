package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.security.MessageDigest;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class AddStaffActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPhone,
            etRole, etJoiningDate, etAddress;

    private AppCompatAutoCompleteTextView etDepartment;
    private MaterialButton btnAddEmployee;

    private DatabaseReference rootRef;
    private FirebaseAuth auth;

    private String companyKey;
    private String companyName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_staff);

        rootRef = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();

        companyKey = getIntent().getStringExtra("companyKey");

        initViews();
        setupDepartmentDropdown();
        fetchCompanyInfo();

        etJoiningDate.setOnClickListener(v -> showDatePicker());
        btnAddEmployee.setOnClickListener(v -> saveEmployee());
    }

    private void initViews() {

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etRole = findViewById(R.id.etRole);
        etJoiningDate = findViewById(R.id.etJoiningDate);
        etAddress = findViewById(R.id.etAddress);
        etDepartment = findViewById(R.id.etDepartment);
        btnAddEmployee = findViewById(R.id.btnAddEmployee);
    }

    private void setupDepartmentDropdown() {

        String[] departments = {
                "Human Resources",
                "Information Technology",
                "Accounts & Finance",
                "Sales & Marketing",
                "Operations",
                "Customer Support",
                "Administration",
                "Software Development",
                "Android Development",
                "Web Development"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                departments
        );

        etDepartment.setAdapter(adapter);
    }

    private void fetchCompanyInfo() {

        rootRef.child("Companies").child(companyKey)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        companyName = snapshot.child("companyName").getValue(String.class);

                        if (companyName == null) {
                            companyName = "Company";
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void showDatePicker() {

        Calendar c = Calendar.getInstance();

        new DatePickerDialog(this,
                (view, year, month, day) ->
                        etJoiningDate.setText(day + "/" + (month + 1) + "/" + year),
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void saveEmployee() {

        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String role = etRole.getText().toString().trim();
        String joiningDate = etJoiningDate.getText().toString().trim();
        String address = etAddress.getText().toString().trim();
        String department = etDepartment.getText().toString().trim();

        if (!validate(name, email, phone, role, joiningDate, department))
            return;

        createEmployee(name, email, phone, role, joiningDate, address, department);
    }

    private boolean validate(String name, String email, String phone,
                             String role, String joiningDate, String department) {

        if (name.isEmpty()) {
            etName.setError("Enter name");
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter valid email");
            return false;
        }

        if (phone.length() != 10) {
            etPhone.setError("Enter valid phone");
            return false;
        }

        if (role.isEmpty()) {
            etRole.setError("Enter role");
            return false;
        }

        if (joiningDate.isEmpty()) {
            etJoiningDate.setError("Select date");
            return false;
        }

        if (department.isEmpty()) {
            etDepartment.setError("Select department");
            return false;
        }

        return true;
    }

    private void createEmployee(String name, String email, String phone,
                                String role, String joiningDate,
                                String address, String department) {

        String defaultPassword = "123456";

        auth.createUserWithEmailAndPassword(email, defaultPassword)
                .addOnSuccessListener(authResult -> {

                    String uid = authResult.getUser().getUid();

                    generateEmployeeId(uid, name, email, phone, role,
                            joiningDate, address, department, defaultPassword);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }

    // FIXED: This method now finds the smallest available employee ID
    private void generateEmployeeId(String uid, String name, String email,
                                    String phone, String role,
                                    String joiningDate, String address,
                                    String department, String password) {

        DatabaseReference employeesRef = rootRef.child("Companies")
                .child(companyKey)
                .child("Employees");

        employeesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                // Track which employee numbers are already used
                Set<Integer> usedNumbers = new HashSet<>();
                int maxNumber = 0;

                for (DataSnapshot empSnapshot : snapshot.getChildren()) {
                    String empId = empSnapshot.getKey();
                    if (empId != null && empId.startsWith("EMP_")) {
                        try {
                            String numStr = empId.substring(4); // Remove "EMP_"
                            int num = Integer.parseInt(numStr);
                            usedNumbers.add(num);
                            if (num > maxNumber) {
                                maxNumber = num;
                            }
                        } catch (NumberFormatException e) {
                            // Skip invalid IDs
                            Log.e("AddStaff", "Invalid employee ID format: " + empId);
                        }
                    }
                }

                // Find the smallest available number (fill gaps)
                int nextNumber = 1;
                while (usedNumbers.contains(nextNumber)) {
                    nextNumber++;
                }

                String empId = String.format("EMP_%03d", nextNumber);

                // Update counter to max number for future reference
                if (nextNumber > maxNumber) {
                    rootRef.child("Companies")
                            .child(companyKey)
                            .child("employeeCounter")
                            .setValue(nextNumber);
                } else {
                    rootRef.child("Companies")
                            .child(companyKey)
                            .child("employeeCounter")
                            .setValue(maxNumber);
                }

                // Create employee data
                Map<String, Object> empData = new HashMap<>();
                empData.put("uid", uid);
                empData.put("empId", empId);
                empData.put("name", name);
                empData.put("email", email);
                empData.put("phone", phone);
                empData.put("role", role);
                empData.put("joiningDate", joiningDate);
                empData.put("address", address);
                empData.put("department", department);
                empData.put("companyName", companyName);
                empData.put("firstLogin", true);
                empData.put("accountStatus", "inactive");
                empData.put("attendanceStatus", "NOT_MARKED");
                empData.put("password", hashPassword(password));

                // Save to Firebase
                employeesRef.child(empId)
                        .setValue(empData)
                        .addOnSuccessListener(v -> {
                            Log.d("AddStaff", "Employee created with ID: " + empId);
                            showSuccessDialog(empId, password);
                        })
                        .addOnFailureListener(e -> {
                            Log.e("AddStaff", "Failed to save: " + e.getMessage());
                            Toast.makeText(AddStaffActivity.this,
                                    "Failed to save: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AddStaffActivity.this,
                        "Error: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String hashPassword(String password) {

        try {

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes());

            StringBuilder sb = new StringBuilder();

            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();

        } catch (Exception e) {
            return password;
        }
    }

    private void showSuccessDialog(String empId, String password) {

        new AlertDialog.Builder(this)
                .setTitle("Employee Created")
                .setMessage(
                        "Employee ID: " + empId +
                                "\nTemporary Password: " + password +
                                "\n\nEmployee must change password on first login."
                )
                .setPositiveButton("OK", (d, w) -> finish())
                .show();
    }
}