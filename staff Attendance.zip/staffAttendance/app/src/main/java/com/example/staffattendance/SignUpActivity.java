package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.staffattendance.utils.SessionManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {

    private EditText etCompany, etName, etEmail, etPassword, etConfirmPassword, etPhone;
    private Button btnRegister;
    private TextView txtLogin;

    private FirebaseAuth auth;
    private DatabaseReference rootRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etCompany = findViewById(R.id.etCompany);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        etPhone = findViewById(R.id.etPhone);
        btnRegister = findViewById(R.id.btnRegister);
        txtLogin = findViewById(R.id.txtLogin);

        auth = FirebaseAuth.getInstance();
        rootRef = FirebaseDatabase.getInstance().getReference();

        btnRegister.setOnClickListener(v -> registerAdmin());

        txtLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void registerAdmin() {
        String companyName = etCompany.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        if (TextUtils.isEmpty(companyName) ||
                TextUtils.isEmpty(name) ||
                TextUtils.isEmpty(email) ||
                TextUtils.isEmpty(phone) ||
                TextUtils.isEmpty(password)) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        btnRegister.setEnabled(false);

        String companyKey = generateCompanyKey(companyName);

        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {

                    // Update Firebase Auth profile
                    auth.getCurrentUser().updateProfile(
                            new UserProfileChangeRequest.Builder()
                                    .setDisplayName(name)
                                    .build()
                    );

                    saveAllData(companyName, name, email, phone, companyKey);

                })
                .addOnFailureListener(e -> {
                    btnRegister.setEnabled(true);
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    private void saveAllData(String companyName, String name, String email, String phone, String companyKey) {

        phone = phone.trim(); // ensure no extra spaces

        Map<String, Object> updates = new HashMap<>();

        // ================= COMPANY =================
        updates.put("Companies/" + companyKey + "/companyName", companyName);
        updates.put("Companies/" + companyKey + "/createdAt", System.currentTimeMillis());
        updates.put("Companies/" + companyKey + "/ownerPhone", phone);

        // ================= ADMIN (PHONE KEY) =================
        updates.put("Companies/" + companyKey + "/Admins/" + phone + "/name", name);
        updates.put("Companies/" + companyKey + "/Admins/" + phone + "/email", email);
        updates.put("Companies/" + companyKey + "/Admins/" + phone + "/phone", phone);
        updates.put("Companies/" + companyKey + "/Admins/" + phone + "/role", "admin");

        // ================= USERS (PHONE KEY) =================
        updates.put("Users/" + phone + "/name", name);
        updates.put("Users/" + phone + "/email", email);
        updates.put("Users/" + phone + "/phone", phone);
        updates.put("Users/" + phone + "/role", "admin");
        updates.put("Users/" + phone + "/companyKey", companyKey);
        updates.put("Users/" + phone + "/companyName", companyName);

        String finalPhone = phone;
        rootRef.updateChildren(updates)
                .addOnSuccessListener(unused -> {
                    // ================= SESSION =================
                    SessionManager session = new SessionManager(this);
                    session.createLoginSession(finalPhone, "admin", companyKey);
                    session.saveUserData(name, email);
                    session.setCompanyName(companyName);

                    Toast.makeText(this, "Account created successfully!", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnRegister.setEnabled(true);
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    private String generateCompanyKey(String companyName) {
        return companyName.toLowerCase()
                .replaceAll("[^a-z0-9]", "_")
                + "_" + System.currentTimeMillis();
    }
}
