package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.LeaveAdapter;
import com.example.staffattendance.Model.LeaveItem;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LeaveListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ExtendedFloatingActionButton fab;
    private MaterialToolbar toolbar;

    private LeaveAdapter leaveAdapter;
    private final List<LeaveItem> leaveList = new ArrayList<>();

    private DatabaseReference leavesRef;
    private SessionManager sessionManager;

    private String companyKey;
    private String empId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_list);

        toolbar = findViewById(R.id.toolbar);
        recyclerView = findViewById(R.id.recyclerView);
        fab = findViewById(R.id.fab);

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("My Leave Requests");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();
        empId = sessionManager.getEmpId();

        if (companyKey == null || empId == null) {
            Toast.makeText(this, "Session expired. Login again.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, EmployeeLoginActivity.class));
            finish();
            return;
        }

        leaveAdapter = new LeaveAdapter(leaveList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(leaveAdapter);

        fab.setOnClickListener(v -> startActivity(new Intent(this, LeaveRequestActivity.class)));

        loadLeaveData();
    }

    private void loadLeaveData() {
        leavesRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Leaves")
                .child(empId);

        leavesRef.orderByChild("timestamp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                leaveList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    LeaveItem item = snap.getValue(LeaveItem.class);
                    if (item != null) {
                        // Ensure leaveId, companyKey, empId are set
                        item.setLeaveId(snap.getKey());
                        item.setCompanyKey(companyKey);
                        item.setEmpId(empId);
                        leaveList.add(item);
                    }
                }

                Collections.sort(leaveList, (a, b) -> Long.compare(b.getTimestamp(), a.getTimestamp()));
                leaveAdapter.notifyDataSetChanged();

                if (leaveList.isEmpty()) {
                    Toast.makeText(LeaveListActivity.this, "No leave requests found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(LeaveListActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
