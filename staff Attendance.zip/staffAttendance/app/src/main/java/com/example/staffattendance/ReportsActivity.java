package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.example.staffattendance.Model.AttendanceReportItem;
import com.example.staffattendance.Model.Employee;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReportsActivity extends AppCompatActivity {

    // UI Components
    private TextInputEditText etEmployee, etMonth, etYear;
    private MaterialButton btnGenerateReport, btnPrintReport, btnExportPdf;
    private TextView tvPresentDays, tvAbsentDays, tvLeaveDays, tvReportPeriod, tvTotalWorkingDays;
    private LinearLayout emptyStateContainer, tableRowsContainer;

    // Firebase
    private DatabaseReference databaseReference;
    private DatabaseReference companyRef;
    private SessionManager sessionManager;

    // Data
    private String companyKey, selectedEmployeeId = "all";
    private int selectedMonth = -1, selectedYear = -1;
    private List<Employee> employeeList = new ArrayList<>();
    private List<AttendanceReportItem> reportItems = new ArrayList<>();

    // Counters as class members to fix the error
    private int presentCount;
    private int absentCount;
    private int leaveCount;
    private int workingDaysCount;

    // Month names
    private final String[] months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
    };

    // Current year and years list
    private int currentYear;
    private List<Integer> yearsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        // Initialize components
        initializeViews();

        // Initialize Firebase and session
        databaseReference = FirebaseDatabase.getInstance().getReference();
        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(this, "Company information not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        companyRef = databaseReference.child("Companies").child(companyKey);

        // Set current year
        Calendar calendar = Calendar.getInstance();
        currentYear = calendar.get(Calendar.YEAR);

        // Setup years list (last 5 years and next 1 year)
        for (int i = currentYear - 5; i <= currentYear + 1; i++) {
            yearsList.add(i);
        }

        // Set current month and year as default
        selectedMonth = calendar.get(Calendar.MONTH);
        selectedYear = currentYear;

        // Set default values in UI
        etMonth.setText(months[selectedMonth]);
        etYear.setText(String.valueOf(selectedYear));

        // Setup toolbar
        setupToolbar();

        // Setup click listeners
        setupClickListeners();

        // Load employees
        loadEmployees();
    }

    private void initializeViews() {
        // Initialize input fields
        etEmployee = findViewById(R.id.etEmployee);
        etMonth = findViewById(R.id.etMonth);
        etYear = findViewById(R.id.etYear);

        // Initialize buttons
        btnGenerateReport = findViewById(R.id.btnGenerateReport);
        btnPrintReport = findViewById(R.id.btnPrintReport);
        btnExportPdf = findViewById(R.id.btnExportPdf);

        // Initialize text views
        tvPresentDays = findViewById(R.id.tvPresentDays);
        tvAbsentDays = findViewById(R.id.tvAbsentDays);
        tvLeaveDays = findViewById(R.id.tvLeaveDays);
        tvReportPeriod = findViewById(R.id.tvReportPeriod);
        tvTotalWorkingDays = findViewById(R.id.tvTotalWorkingDays);

        // Initialize containers
        emptyStateContainer = findViewById(R.id.emptyStateContainer);
        tableRowsContainer = findViewById(R.id.tableRowsContainer);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Attendance Report");
        }

        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupClickListeners() {
        // Employee dropdown
        etEmployee.setOnClickListener(v -> showEmployeeSelectionDialog());

        // Month dropdown
        etMonth.setOnClickListener(v -> showMonthSelectionDialog());

        // Year dropdown
        etYear.setOnClickListener(v -> showYearSelectionDialog());

        // Generate report button
        btnGenerateReport.setOnClickListener(v -> {
            if (validateFilters()) {
                generateReport();
            }
        });

        // Print report button
        btnPrintReport.setOnClickListener(v -> {
            if (reportItems.isEmpty()) {
                Toast.makeText(this, "No report data to print", Toast.LENGTH_SHORT).show();
                return;
            }
            printReport();
        });

        // Export PDF button
        btnExportPdf.setOnClickListener(v -> {
            if (reportItems.isEmpty()) {
                Toast.makeText(this, "No report data to export", Toast.LENGTH_SHORT).show();
                return;
            }
            exportToPdf();
        });
    }

    private void showEmployeeSelectionDialog() {
        List<String> employeeNames = new ArrayList<>();
        employeeNames.add("All Employees");

        for (Employee employee : employeeList) {
            employeeNames.add(employee.getName() + " (" + employee.getEmpId() + ")");
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Employee")
                .setItems(employeeNames.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) {
                        // "All Employees" selected
                        selectedEmployeeId = "all";
                        etEmployee.setText("All Employees");
                    } else {
                        Employee selectedEmployee = employeeList.get(which - 1);
                        selectedEmployeeId = selectedEmployee.getEmpId();
                        etEmployee.setText(selectedEmployee.getName());
                    }
                })
                .show();
    }

    private void showMonthSelectionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Select Month")
                .setItems(months, (dialog, which) -> {
                    selectedMonth = which;
                    etMonth.setText(months[which]);
                })
                .show();
    }

    private void showYearSelectionDialog() {
        String[] yearStrings = new String[yearsList.size()];
        for (int i = 0; i < yearsList.size(); i++) {
            yearStrings[i] = String.valueOf(yearsList.get(i));
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Year")
                .setItems(yearStrings, (dialog, which) -> {
                    selectedYear = yearsList.get(which);
                    etYear.setText(String.valueOf(selectedYear));
                })
                .show();
    }

    private boolean validateFilters() {
        if (selectedMonth == -1) {
            Toast.makeText(this, "Please select a month", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (selectedYear == -1) {
            Toast.makeText(this, "Please select a year", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void loadEmployees() {
        companyRef.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                employeeList.clear();

                for (DataSnapshot employeeSnap : snapshot.getChildren()) {
                    Employee employee = employeeSnap.getValue(Employee.class);
                    if (employee != null) {
                        employee.setEmpId(employeeSnap.getKey());
                        employeeList.add(employee);
                    }
                }

                // Set default selection to "All Employees"
                etEmployee.setText("All Employees");
                selectedEmployeeId = "all";
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReportsActivity.this,
                        "Error loading employees: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generateReport() {
        // Show loading
        btnGenerateReport.setEnabled(false);
        btnGenerateReport.setText("Generating...");

        // Clear previous data
        reportItems.clear();
        tableRowsContainer.removeAllViews();

        // Set report period
        String reportPeriod = months[selectedMonth] + " " + selectedYear;
        tvReportPeriod.setText(reportPeriod);

        // Calculate days in month
        Calendar calendar = Calendar.getInstance();
        calendar.set(selectedYear, selectedMonth, 1);
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        // Reset counters using class member variables
        presentCount = 0;
        absentCount = 0;
        leaveCount = 0;
        workingDaysCount = 0;

        // If "All Employees" selected, generate for all employees
        if (selectedEmployeeId.equals("all")) {
            generateReportForAllEmployees(daysInMonth, calendar);
        } else {
            generateReportForSingleEmployee(selectedEmployeeId, daysInMonth, calendar);
        }
    }

    private void generateReportForSingleEmployee(String empId, int daysInMonth, Calendar calendar) {
        DatabaseReference employeeAttendanceRef = companyRef.child("Attendance").child(empId);

        // Clear report items before processing
        reportItems.clear();

        employeeAttendanceRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Reset counters at the beginning of processing
                presentCount = 0;
                absentCount = 0;
                leaveCount = 0;
                workingDaysCount = 0;
                reportItems.clear();

                // Process each day of the month
                for (int day = 1; day <= daysInMonth; day++) {
                    calendar.set(Calendar.DAY_OF_MONTH, day);
                    Date date = calendar.getTime();

                    // Format date for Firebase key
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    String dateKey = dateFormat.format(date);

                    // Get day name
                    SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
                    String dayName = dayFormat.format(date);

                    // Check if it's a working day
                    boolean isWorkingDay = !dayName.equalsIgnoreCase("Sunday");

                    if (isWorkingDay) {
                        workingDaysCount++;
                    }

                    // Get attendance data for this day
                    DataSnapshot daySnapshot = snapshot.child(dateKey);

                    AttendanceReportItem item = new AttendanceReportItem();
                    item.setDate(dateKey);
                    item.setDay(dayName);

                    if (daySnapshot.exists()) {
                        // Check for leave
                        String leaveStatus = daySnapshot.child("leaveStatus").getValue(String.class);
                        if (leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null")) {
                            item.setStatus("LEAVE");
                            item.setLeaveReason(daySnapshot.child("leaveReason").getValue(String.class));
                            leaveCount++;
                        } else {
                            // Get punch data
                            String punchIn = daySnapshot.child("punchIn").getValue(String.class);
                            String punchOut = daySnapshot.child("punchOut").getValue(String.class);
                            String punchInTime = daySnapshot.child("punchInTime").getValue(String.class);
                            String punchOutTime = daySnapshot.child("punchOutTime").getValue(String.class);

                            String actualPunchIn = punchIn != null && !punchIn.isEmpty() ? punchIn : punchInTime;
                            String actualPunchOut = punchOut != null && !punchOut.isEmpty() ? punchOut : punchOutTime;

                            if (actualPunchIn != null && !actualPunchIn.isEmpty()) {
                                item.setPunchIn(actualPunchIn);
                                item.setPunchOut(actualPunchOut);

                                // Calculate status
                                if (actualPunchOut != null && !actualPunchOut.isEmpty()) {
                                    double totalHours = calculateTotalHours(actualPunchIn, actualPunchOut);
                                    if (totalHours >= 8.0) {
                                        item.setStatus("PRESENT");
                                        presentCount++;
                                    } else if (totalHours >= 4.0) {
                                        item.setStatus("HALF_DAY");
                                        presentCount++;
                                    } else {
                                        item.setStatus("ABSENT");
                                        absentCount++;
                                    }
                                    item.setTotalHours(formatHours(totalHours));
                                } else {
                                    item.setStatus("HALF_DAY");
                                    presentCount++;
                                }
                            } else {
                                if (isWorkingDay) {
                                    item.setStatus("ABSENT");
                                    absentCount++;
                                } else {
                                    item.setStatus("HOLIDAY");
                                }
                            }
                        }
                    } else {
                        if (isWorkingDay) {
                            item.setStatus("ABSENT");
                            absentCount++;
                        } else {
                            item.setStatus("HOLIDAY");
                        }
                    }

                    reportItems.add(item);
                }

                // Update UI with results
                updateReportUI();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                btnGenerateReport.setEnabled(true);
                btnGenerateReport.setText("Generate");
                Toast.makeText(ReportsActivity.this,
                        "Error loading attendance data: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generateReportForAllEmployees(int daysInMonth, Calendar calendar) {
        // For all employees, we'll show aggregated data
        // This is a simplified version - you might want to show totals only
        // or create a different view for all employees

        // Clear any existing data
        reportItems.clear();
        tableRowsContainer.removeAllViews();

        // Calculate working days
        workingDaysCount = 0;
        for (int day = 1; day <= daysInMonth; day++) {
            calendar.set(Calendar.DAY_OF_MONTH, day);
            Date date = calendar.getTime();
            SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
            String dayName = dayFormat.format(date);
            if (!dayName.equalsIgnoreCase("Sunday")) {
                workingDaysCount++;
            }
        }

        // For now, we'll just show a message
        updateReportUI();
        showEmptyTableWithMessage("Select a specific employee to view detailed report");

        btnGenerateReport.setEnabled(true);
        btnGenerateReport.setText("Generate");
    }

    private double calculateTotalHours(String punchIn, String punchOut) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date inTime = sdf.parse(punchIn);
            Date outTime = sdf.parse(punchOut);

            long diff = outTime.getTime() - inTime.getTime();
            long totalMinutes = diff / (1000 * 60);

            return totalMinutes / 60.0;
        } catch (ParseException e) {
            return 0.0;
        }
    }

    private String formatHours(double hours) {
        int wholeHours = (int) hours;
        int minutes = (int) ((hours - wholeHours) * 60);
        return wholeHours + "h " + minutes + "m";
    }

    @SuppressLint("SetTextI18n")
    private void updateReportUI() {
        // Update summary cards
        tvPresentDays.setText(String.valueOf(presentCount));
        tvAbsentDays.setText(String.valueOf(absentCount));
        tvLeaveDays.setText(String.valueOf(leaveCount));
        tvTotalWorkingDays.setText(String.valueOf(workingDaysCount));

        // Update table rows
        if (reportItems.isEmpty()) {
            emptyStateContainer.setVisibility(View.VISIBLE);
            tableRowsContainer.setVisibility(View.GONE);
        } else {
            emptyStateContainer.setVisibility(View.GONE);
            tableRowsContainer.setVisibility(View.VISIBLE);

            // Add table rows
            for (AttendanceReportItem item : reportItems) {
                View rowView = LayoutInflater.from(this).inflate(R.layout.item_report_row, null);

                TextView tvDate = rowView.findViewById(R.id.tvDate);
                TextView tvDay = rowView.findViewById(R.id.tvDay);
                TextView tvStatus = rowView.findViewById(R.id.tvStatus);
                TextView tvPunchIn = rowView.findViewById(R.id.tvPunchIn);
                TextView tvPunchOut = rowView.findViewById(R.id.tvPunchOut);
                TextView tvTotalHours = rowView.findViewById(R.id.tvTotalHours);
                TextView tvOvertime = rowView.findViewById(R.id.tvOvertime);
                TextView tvNotes = rowView.findViewById(R.id.tvNotes);

                // Format date
                try {
                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM", Locale.getDefault());
                    Date date = inputFormat.parse(item.getDate());
                    tvDate.setText(outputFormat.format(date));
                } catch (ParseException e) {
                    tvDate.setText(item.getDate());
                }

                tvDay.setText(item.getDay());
                tvStatus.setText(item.getStatus());
                tvPunchIn.setText(item.getPunchIn() != null ? item.getPunchIn() : "--:--");
                tvPunchOut.setText(item.getPunchOut() != null ? item.getPunchOut() : "--:--");
                tvTotalHours.setText(item.getTotalHours() != null ? item.getTotalHours() : "0h 0m");
                tvOvertime.setText(item.getOvertime() != null ? item.getOvertime() : "0h 0m");
                tvNotes.setText(item.getLeaveReason() != null ? item.getLeaveReason() : "");

                // Set status color
                setStatusColor(tvStatus, item.getStatus());

                tableRowsContainer.addView(rowView);
            }
        }

        // Re-enable generate button
        btnGenerateReport.setEnabled(true);
        btnGenerateReport.setText("Generate");
    }

    private void showEmptyTableWithMessage(String message) {
        emptyStateContainer.setVisibility(View.VISIBLE);
        tableRowsContainer.setVisibility(View.GONE);

        TextView emptyMessage = emptyStateContainer.findViewById(R.id.text_empty_message);
        if (emptyMessage != null) {
            emptyMessage.setText(message);
        }
    }

    private void setStatusColor(TextView textView, String status) {
        if (status == null) return;

        int colorId;
        switch (status.toUpperCase()) {
            case "PRESENT":
                colorId = R.color.green_success;
                break;
            case "ABSENT":
                colorId = R.color.red_error;
                break;
            case "LEAVE":
                colorId = R.color.blue_info;
                break;
            case "HALF_DAY":
                colorId = R.color.orange_warning;
                break;
            case "HOLIDAY":
                colorId = R.color.gray_default;
                break;
            default:
                colorId = R.color.text_primary;
                break;
        }
        textView.setTextColor(ContextCompat.getColor(this, colorId));
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void printReport() {
        // Create HTML for printing
        String htmlContent = generateHtmlForPrint();

        // Create WebView for printing
        WebView webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                createPrintJob(webView);
            }
        });

        // Load HTML content
        webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null);
    }

    private String generateHtmlForPrint() {
        StringBuilder html = new StringBuilder();

        // HTML header
        html.append("<!DOCTYPE html><html><head>")
                .append("<meta charset=\"UTF-8\">")
                .append("<title>Attendance Report</title>")
                .append("<style>")
                .append("body { font-family: Arial, sans-serif; margin: 20px; }")
                .append("h1 { color: #333; text-align: center; }")
                .append("h3 { color: #666; text-align: center; }")
                .append("table { width: 100%; border-collapse: collapse; margin-top: 20px; }")
                .append("th { background-color: #4F46E5; color: white; padding: 10px; text-align: center; }")
                .append("td { border: 1px solid #ddd; padding: 8px; text-align: center; }")
                .append(".present { color: green; font-weight: bold; }")
                .append(".absent { color: red; font-weight: bold; }")
                .append(".leave { color: blue; font-weight: bold; }")
                .append(".summary { margin-top: 30px; padding: 15px; background-color: #f5f5f5; border-radius: 5px; }")
                .append("</style>")
                .append("</head><body>");

        // Report title
        html.append("<h1>Attendance Report</h1>")
                .append("<h3>").append(months[selectedMonth]).append(" ").append(selectedYear).append("</h3>");

        // Summary section
        html.append("<div class=\"summary\">")
                .append("<strong>Summary:</strong><br>")
                .append("Present Days: ").append(tvPresentDays.getText()).append("<br>")
                .append("Absent Days: ").append(tvAbsentDays.getText()).append("<br>")
                .append("Leave Days: ").append(tvLeaveDays.getText()).append("<br>")
                .append("Total Working Days: ").append(tvTotalWorkingDays.getText())
                .append("</div>");

        // Table header
        html.append("<table>")
                .append("<tr>")
                .append("<th>Date</th>")
                .append("<th>Day</th>")
                .append("<th>Status</th>")
                .append("<th>Punch In</th>")
                .append("<th>Punch Out</th>")
                .append("<th>Total Hours</th>")
                .append("<th>Overtime</th>")
                .append("<th>Notes/Leave</th>")
                .append("</tr>");

        // Table rows
        for (AttendanceReportItem item : reportItems) {
            String statusClass = "";
            switch (item.getStatus().toUpperCase()) {
                case "PRESENT":
                    statusClass = "present";
                    break;
                case "ABSENT":
                    statusClass = "absent";
                    break;
                case "LEAVE":
                    statusClass = "leave";
                    break;
            }

            html.append("<tr>")
                    .append("<td>").append(formatDateForDisplay(item.getDate())).append("</td>")
                    .append("<td>").append(item.getDay()).append("</td>")
                    .append("<td class=\"").append(statusClass).append("\">").append(item.getStatus()).append("</td>")
                    .append("<td>").append(item.getPunchIn() != null ? item.getPunchIn() : "--:--").append("</td>")
                    .append("<td>").append(item.getPunchOut() != null ? item.getPunchOut() : "--:--").append("</td>")
                    .append("<td>").append(item.getTotalHours() != null ? item.getTotalHours() : "0h 0m").append("</td>")
                    .append("<td>").append(item.getOvertime() != null ? item.getOvertime() : "0h 0m").append("</td>")
                    .append("<td>").append(item.getLeaveReason() != null ? item.getLeaveReason() : "").append("</td>")
                    .append("</tr>");
        }

        html.append("</table>")
                .append("<p style=\"text-align: center; margin-top: 30px; color: #666;\">")
                .append("Generated on: ").append(new SimpleDateFormat("dd-MMM-yyyy HH:mm", Locale.getDefault()).format(new Date()))
                .append("</p>")
                .append("</body></html>");

        return html.toString();
    }

    private String formatDateForDisplay(String dateStr) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
            Date date = inputFormat.parse(dateStr);
            return outputFormat.format(date);
        } catch (ParseException e) {
            return dateStr;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createPrintJob(WebView webView) {
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        String jobName = "Attendance_Report_" + months[selectedMonth] + "_" + selectedYear;

        PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter(jobName);

        if (printManager != null) {
            printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
        }
    }

    private void exportToPdf() {
        // This is a simplified PDF export using HTML
        // In a real app, you might want to use a proper PDF library like iText or PdfBox

        String htmlContent = generateHtmlForPrint();

        // Save HTML as file (can be opened as PDF by many apps)
        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            String fileName = "Attendance_Report_" + months[selectedMonth] + "_" + selectedYear + ".html";
            File file = new File(downloadsDir, fileName);

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(htmlContent.getBytes());
            fos.close();

            Toast.makeText(this, "Report saved to Downloads folder", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error saving report: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}