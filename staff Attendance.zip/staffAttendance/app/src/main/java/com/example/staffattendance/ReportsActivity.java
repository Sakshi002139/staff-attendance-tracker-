package com.example.staffattendance;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.example.staffattendance.Model.AttendanceReportItem;
import com.example.staffattendance.Model.Employee;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReportsActivity extends AppCompatActivity {

    // UI Components
    private TextInputEditText etEmployee, etMonth, etYear;
    private MaterialButton btnGenerateReport, btnPrintReport, btnExportPdf;
    private TextView tvPresentDays, tvAbsentDays, tvLeaveDays, tvHalfDays, tvReportPeriod, tvTotalWorkingDays;
    private LinearLayout emptyStateContainer, tableRowsContainer;

    // Firebase
    private DatabaseReference databaseReference;
    private DatabaseReference companyRef;
    private SessionManager sessionManager;

    // Data
    private String companyKey, selectedEmployeeId = "all", selectedEmployeeName = "All Employees";
    private int selectedMonth = -1, selectedYear = -1;
    private List<Employee> employeeList = new ArrayList<>();
    private List<AttendanceReportItem> reportItems = new ArrayList<>();

    // Counters
    private int presentCount;
    private int absentCount;
    private int leaveCount;
    private int halfDayCount;
    private int lateCount; // Added late count
    private int workingDaysCount;

    // Office timing
    private String officeStartTime = "09:30";
    private String officeEndTime = "18:00";
    private double requiredHours = 8.5; // Default 8.5 hours
    private double halfDayThreshold = 4.0; // Default 4 hours
    private int lateThresholdMinutes = 15; // Default 15 minutes late threshold

    // Progress tracking for all employees
    private int employeesProcessed = 0;

    // Month names
    private final String[] months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
    };

    // Date formatters
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private final SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
    private final SimpleDateFormat displayDateFormat = new SimpleDateFormat("dd MMM", Locale.getDefault());
    private final SimpleDateFormat timeFormat12Hour = new SimpleDateFormat("hh:mm a", Locale.getDefault());
    private final SimpleDateFormat timeFormat24Hour = new SimpleDateFormat("HH:mm", Locale.getDefault());

    // Current year and years list
    private int currentYear;
    private List<Integer> yearsList = new ArrayList<>();

    // Progress dialog
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        // Initialize components
        initializeViews();

        // Initialize Firebase and session
        databaseReference = FirebaseDatabase.getInstance().getReference();
        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(this, "Company information not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        companyRef = databaseReference.child("Companies").child(companyKey);

        // Set current year
        Calendar calendar = Calendar.getInstance();
        currentYear = calendar.get(Calendar.YEAR);

        // Setup years list (last 5 years and next 1 year)
        for (int i = currentYear - 5; i <= currentYear + 1; i++) {
            yearsList.add(i);
        }

        // Set current month and year as default
        selectedMonth = calendar.get(Calendar.MONTH);
        selectedYear = currentYear;

        // Set default values in UI
        etMonth.setText(months[selectedMonth]);
        etYear.setText(String.valueOf(selectedYear));

        // Setup toolbar
        setupToolbar();

        // Setup click listeners
        setupClickListeners();

        // Load office time settings
        loadOfficeTime();

        // Load employees
        loadEmployees();
    }

    private void initializeViews() {
        // Initialize input fields
        etEmployee = findViewById(R.id.etEmployee);
        etMonth = findViewById(R.id.etMonth);
        etYear = findViewById(R.id.etYear);

        // Initialize buttons
        btnGenerateReport = findViewById(R.id.btnGenerateReport);
        btnPrintReport = findViewById(R.id.btnPrintReport);
        btnExportPdf = findViewById(R.id.btnExportPdf);

        // Initialize text views
        tvPresentDays = findViewById(R.id.tvPresentDays);
        tvAbsentDays = findViewById(R.id.tvAbsentDays);
        tvLeaveDays = findViewById(R.id.tvLeaveDays);
        tvHalfDays = findViewById(R.id.tvHalfDays);
        tvReportPeriod = findViewById(R.id.tvReportPeriod);
        tvTotalWorkingDays = findViewById(R.id.tvTotalWorkingDays);

        // Initialize containers
        emptyStateContainer = findViewById(R.id.emptyStateContainer);
        tableRowsContainer = findViewById(R.id.tableRowsContainer);

        // Initialize progress dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Generating report...");
        progressDialog.setCancelable(false);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Attendance Report");
        }

        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupClickListeners() {
        // Employee dropdown
        etEmployee.setOnClickListener(v -> showEmployeeSelectionDialog());

        // Month dropdown
        etMonth.setOnClickListener(v -> showMonthSelectionDialog());

        // Year dropdown
        etYear.setOnClickListener(v -> showYearSelectionDialog());

        // Generate report button
        btnGenerateReport.setOnClickListener(v -> {
            if (validateFilters()) {
                generateReport();
            }
        });

        // Print report button
        btnPrintReport.setOnClickListener(v -> {
            if (reportItems.isEmpty()) {
                Toast.makeText(this, "No report data to print", Toast.LENGTH_SHORT).show();
                return;
            }
            printReport();
        });

        // Export PDF button
        btnExportPdf.setOnClickListener(v -> {
            if (reportItems.isEmpty()) {
                Toast.makeText(this, "No report data to export", Toast.LENGTH_SHORT).show();
                return;
            }
            exportToPdf();
        });
    }

    private void loadOfficeTime() {
        companyRef.child("officeTime").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Get start time
                    String startTime = snapshot.child("startTime").getValue(String.class);
                    if (startTime != null && !startTime.isEmpty()) {
                        officeStartTime = convertTo24HourFormat(startTime);
                    }

                    // Get end time
                    String endTime = snapshot.child("endTime").getValue(String.class);
                    if (endTime != null && !endTime.isEmpty()) {
                        officeEndTime = convertTo24HourFormat(endTime);
                    }

                    // Calculate required hours
                    requiredHours = calculateRequiredHours();

                    // Get half day threshold
                    Double threshold = snapshot.child("halfDayThreshold").getValue(Double.class);
                    if (threshold != null) {
                        halfDayThreshold = threshold;
                    }

                    // Get late threshold
                    Integer lateThreshold = snapshot.child("lateThreshold").getValue(Integer.class);
                    if (lateThreshold != null) {
                        lateThresholdMinutes = lateThreshold;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Use defaults
            }
        });
    }

    private String convertTo24HourFormat(String time12Hour) {
        try {
            if (time12Hour == null || time12Hour.isEmpty()) return "09:00";

            // Check if already in 24-hour format
            if (time12Hour.matches("\\d{2}:\\d{2}") && !time12Hour.toLowerCase().contains("am") && !time12Hour.toLowerCase().contains("pm")) {
                return time12Hour;
            }

            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date date = sdf12.parse(time12Hour);
            return timeFormat24Hour.format(date);
        } catch (ParseException e) {
            return "09:00";
        }
    }

    private double calculateRequiredHours() {
        try {
            Date start = timeFormat24Hour.parse(officeStartTime);
            Date end = timeFormat24Hour.parse(officeEndTime);
            long diff = end.getTime() - start.getTime();
            return diff / (1000.0 * 60 * 60);
        } catch (Exception e) {
            return 8.5;
        }
    }

    private void showEmployeeSelectionDialog() {
        List<String> employeeNames = new ArrayList<>();
        employeeNames.add("All Employees");

        for (Employee employee : employeeList) {
            employeeNames.add(employee.getName() + " (" + employee.getEmpId() + ")");
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Employee")
                .setItems(employeeNames.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) {
                        // "All Employees" selected
                        selectedEmployeeId = "all";
                        selectedEmployeeName = "All Employees";
                        etEmployee.setText("All Employees");
                    } else {
                        Employee selectedEmployee = employeeList.get(which - 1);
                        selectedEmployeeId = selectedEmployee.getEmpId();
                        selectedEmployeeName = selectedEmployee.getName();
                        etEmployee.setText(selectedEmployee.getName());
                    }
                })
                .show();
    }

    private void showMonthSelectionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Select Month")
                .setItems(months, (dialog, which) -> {
                    selectedMonth = which;
                    etMonth.setText(months[which]);
                })
                .show();
    }

    private void showYearSelectionDialog() {
        String[] yearStrings = new String[yearsList.size()];
        for (int i = 0; i < yearsList.size(); i++) {
            yearStrings[i] = String.valueOf(yearsList.get(i));
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Year")
                .setItems(yearStrings, (dialog, which) -> {
                    selectedYear = yearsList.get(which);
                    etYear.setText(String.valueOf(selectedYear));
                })
                .show();
    }

    private boolean validateFilters() {
        if (selectedMonth == -1) {
            Toast.makeText(this, "Please select a month", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (selectedYear == -1) {
            Toast.makeText(this, "Please select a year", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Allow all employees - removed the restriction
        if (employeeList.isEmpty()) {
            Toast.makeText(this, "No employees found", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void loadEmployees() {
        companyRef.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                employeeList.clear();

                for (DataSnapshot employeeSnap : snapshot.getChildren()) {
                    Employee employee = employeeSnap.getValue(Employee.class);
                    if (employee != null) {
                        employee.setEmpId(employeeSnap.getKey());
                        employeeList.add(employee);
                    }
                }

                // Set default selection to "All Employees"
                etEmployee.setText("All Employees");
                selectedEmployeeId = "all";
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReportsActivity.this,
                        "Error loading employees: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generateReport() {
        // Show progress
        progressDialog.show();

        // Reset processed counter
        employeesProcessed = 0;

        // Clear previous data
        reportItems.clear();
        tableRowsContainer.removeAllViews();

        // Set report period
        String reportPeriod = months[selectedMonth] + " " + selectedYear;
        tvReportPeriod.setText(reportPeriod + " - " + selectedEmployeeName);

        // Reset counters
        presentCount = 0;
        absentCount = 0;
        leaveCount = 0;
        halfDayCount = 0;
        lateCount = 0;
        workingDaysCount = 0;

        if (selectedEmployeeId.equals("all")) {
            // Generate report for all employees
            for (Employee employee : employeeList) {
                generateReportForEmployee(employee.getEmpId(), employee.getName());
            }
        } else {
            // Generate report for single employee
            generateReportForEmployee(selectedEmployeeId, selectedEmployeeName);
        }
    }

    private void generateReportForEmployee(String empId, String empName) {
        DatabaseReference employeeAttendanceRef = companyRef.child("Attendance").child(empId);

        // Get attendance data for the selected month
        employeeAttendanceRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Calculate days in month
                Calendar calendar = Calendar.getInstance();
                calendar.set(selectedYear, selectedMonth, 1);
                int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

                // Process each day of the month
                for (int day = 1; day <= daysInMonth; day++) {
                    calendar.set(Calendar.DAY_OF_MONTH, day);
                    Date date = calendar.getTime();

                    // Format date for Firebase key
                    String dateKey = dateFormat.format(date);

                    // Get day name
                    String dayName = dayFormat.format(date);

                    // Check if it's a working day (not Sunday by default)
                    boolean isWorkingDay = !dayName.equalsIgnoreCase("Sunday");

                    if (isWorkingDay) {
                        workingDaysCount++;
                    }

                    // Get attendance data for this day
                    DataSnapshot daySnapshot = snapshot.child(dateKey);

                    AttendanceReportItem item = new AttendanceReportItem();
                    item.setDate(dateKey);
                    item.setDay(dayName);
                    item.setEmployeeName(empName);
                    item.setEmployeeId(empId);

                    if (daySnapshot.exists()) {
                        // Log the data for debugging
                        System.out.println("Data for " + dateKey + ": " + daySnapshot.getValue());

                        // Check for leave first
                        String leaveStatus = daySnapshot.child("leaveStatus").getValue(String.class);
                        if (leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null") && !leaveStatus.equals("NONE")) {
                            item.setStatus("LEAVE");
                            item.setLeaveReason(daySnapshot.child("leaveReason").getValue(String.class));
                            item.setLeaveType(daySnapshot.child("leaveType").getValue(String.class));
                            leaveCount++;
                        } else {
                            // Get explicit status field
                            String status = daySnapshot.child("status").getValue(String.class);

                            // Get punch data - check both possible field names
                            String punchIn = daySnapshot.child("punchIn").getValue(String.class);
                            String punchOut = daySnapshot.child("punchOut").getValue(String.class);
                            String punchInTime = daySnapshot.child("punchInTime").getValue(String.class);
                            String punchOutTime = daySnapshot.child("punchOutTime").getValue(String.class);

                            String actualPunchIn = punchIn != null ? punchIn : punchInTime;
                            String actualPunchOut = punchOut != null ? punchOut : punchOutTime;

                            // Set punch times
                            if (actualPunchIn != null) {
                                item.setPunchIn(convertTo12HourFormat(actualPunchIn));
                            }
                            if (actualPunchOut != null) {
                                item.setPunchOut(convertTo12HourFormat(actualPunchOut));
                            }

                            // Determine status - FIXED: Check for late properly
                            if (status != null && !status.isEmpty()) {
                                // Use explicit status
                                if (status.equalsIgnoreCase("PRESENT") || status.equalsIgnoreCase("PUNCHED_IN") || status.equalsIgnoreCase("PUNCHED_OUT")) {
                                    // Check if they were late even if status is PRESENT
                                    if (actualPunchIn != null && isLatePunch(actualPunchIn)) {
                                        item.setStatus("LATE");
                                        lateCount++;
                                    } else {
                                        item.setStatus(status);
                                        presentCount++;
                                    }
                                } else if (status.equalsIgnoreCase("LATE")) {
                                    item.setStatus("LATE");
                                    lateCount++;
                                } else if (status.equalsIgnoreCase("HALF_DAY")) {
                                    item.setStatus("HALF_DAY");
                                    halfDayCount++;
                                } else if (status.equalsIgnoreCase("ABSENT")) {
                                    item.setStatus("ABSENT");
                                    absentCount++;
                                } else {
                                    item.setStatus(status);
                                }
                            } else if (actualPunchIn != null && actualPunchOut != null) {
                                // Both punches exist - calculate hours
                                double totalHours = calculateTotalHours(actualPunchIn, actualPunchOut);
                                item.setTotalHours(formatHours(totalHours));

                                if (totalHours >= requiredHours) {
                                    // Full day - check if late
                                    if (isLatePunch(actualPunchIn)) {
                                        item.setStatus("LATE");
                                        lateCount++;
                                    } else {
                                        item.setStatus("PRESENT");
                                        presentCount++;
                                    }
                                } else if (totalHours >= halfDayThreshold) {
                                    // Half day
                                    item.setStatus("HALF_DAY");
                                    halfDayCount++;
                                } else {
                                    // Less than half day
                                    item.setStatus("ABSENT");
                                    absentCount++;
                                }

                                // Calculate overtime
                                if (totalHours > requiredHours) {
                                    double overtime = totalHours - requiredHours;
                                    item.setOvertime(formatHours(overtime));
                                }
                            } else if (actualPunchIn != null) {
                                // Only punch in exists - check if late
                                Date currentDate = calendar.getTime();
                                if (currentDate.before(new Date())) {
                                    // Past date with only punch in - consider based on hours
                                    // Since we don't have punch out, we can't calculate full hours
                                    // Default to HALF_DAY if only punch in exists for past date
                                    item.setStatus("HALF_DAY");
                                    halfDayCount++;
                                } else {
                                    // Today or future with only punch in
                                    item.setStatus("WORKING");
                                }
                            } else {
                                // No punch data but record exists - could be marked by admin
                                if (isWorkingDay) {
                                    item.setStatus("PRESENT");
                                    presentCount++;
                                } else {
                                    item.setStatus("WEEK_OFF");
                                }
                            }
                        }
                    } else {
                        // No data for this date
                        if (isWorkingDay) {
                            // Check if date is in the past
                            Date currentDate = calendar.getTime();
                            if (currentDate.before(new Date())) {
                                item.setStatus("ABSENT");
                                absentCount++;
                            } else {
                                item.setStatus("FUTURE");
                            }
                        } else {
                            item.setStatus("WEEK_OFF");
                        }
                    }

                    reportItems.add(item);
                }

                employeesProcessed++;

                // Update UI with results
                runOnUiThread(() -> {
                    if (selectedEmployeeId.equals("all")) {
                        // For all employees, wait until all are processed
                        if (employeesProcessed == employeeList.size()) {
                            updateReportUI();
                            progressDialog.dismiss();
                        }
                    } else {
                        // For single employee, update immediately
                        updateReportUI();
                        progressDialog.dismiss();
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                employeesProcessed++;

                runOnUiThread(() -> {
                    if (selectedEmployeeId.equals("all")) {
                        if (employeesProcessed == employeeList.size()) {
                            progressDialog.dismiss();
                            updateReportUI();
                        }
                    } else {
                        progressDialog.dismiss();
                        btnGenerateReport.setEnabled(true);
                        btnGenerateReport.setText("Generate");
                        Toast.makeText(ReportsActivity.this,
                                "Error loading attendance data: " + error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private String convertTo12HourFormat(String time) {
        try {
            if (time == null || time.isEmpty()) return "--:--";

            // Handle different time formats
            if (time.toLowerCase().contains("am") || time.toLowerCase().contains("pm")) {
                return time; // Already in 12-hour format
            }

            // Try to parse as 24-hour format
            Date date = timeFormat24Hour.parse(time);
            return timeFormat12Hour.format(date);
        } catch (ParseException e) {
            return time;
        }
    }

    private double calculateTotalHours(String punchIn, String punchOut) {
        try {
            if (punchIn == null || punchOut == null) return 0.0;

            String punchIn24 = punchIn;
            String punchOut24 = punchOut;

            // Convert to 24-hour if needed
            if (punchIn.toLowerCase().contains("am") || punchIn.toLowerCase().contains("pm")) {
                Date inDate = timeFormat12Hour.parse(punchIn);
                punchIn24 = timeFormat24Hour.format(inDate);
            }

            if (punchOut.toLowerCase().contains("am") || punchOut.toLowerCase().contains("pm")) {
                Date outDate = timeFormat12Hour.parse(punchOut);
                punchOut24 = timeFormat24Hour.format(outDate);
            }

            Date in = timeFormat24Hour.parse(punchIn24);
            Date out = timeFormat24Hour.parse(punchOut24);

            long diff = out.getTime() - in.getTime();
            return diff / (1000.0 * 60 * 60);
        } catch (Exception e) {
            return 0.0;
        }
    }

    private boolean isLatePunch(String punchInTime) {
        try {
            if (punchInTime == null) return false;

            String time24 = punchInTime;
            if (punchInTime.toLowerCase().contains("am") || punchInTime.toLowerCase().contains("pm")) {
                Date date = timeFormat12Hour.parse(punchInTime);
                time24 = timeFormat24Hour.format(date);
            }

            Date punchIn = timeFormat24Hour.parse(time24);
            Date officeStart = timeFormat24Hour.parse(officeStartTime);

            long diff = punchIn.getTime() - officeStart.getTime();
            long minutesLate = diff / (1000 * 60);

            return minutesLate > lateThresholdMinutes;
        } catch (Exception e) {
            return false;
        }
    }

    private String formatHours(double hours) {
        int wholeHours = (int) hours;
        int minutes = (int) ((hours - wholeHours) * 60);
        return wholeHours + "h " + minutes + "m";
    }

    @SuppressLint("SetTextI18n")
    private void updateReportUI() {
        // Update summary cards
        tvPresentDays.setText(String.valueOf(presentCount));
        tvAbsentDays.setText(String.valueOf(absentCount));
        tvLeaveDays.setText(String.valueOf(leaveCount));
        tvHalfDays.setText(String.valueOf(halfDayCount + lateCount)); // Combine half days and late for display
        tvTotalWorkingDays.setText(String.valueOf(workingDaysCount));

        // Update table rows
        if (reportItems.isEmpty()) {
            emptyStateContainer.setVisibility(View.VISIBLE);
            tableRowsContainer.setVisibility(View.GONE);
        } else {
            emptyStateContainer.setVisibility(View.GONE);
            tableRowsContainer.setVisibility(View.VISIBLE);

            // Clear existing rows
            tableRowsContainer.removeAllViews();

            // Add table rows
            for (AttendanceReportItem item : reportItems) {
                View rowView = LayoutInflater.from(this).inflate(R.layout.item_report_row, null);

                TextView tvEmployee = rowView.findViewById(R.id.tvEmployee);
                TextView tvDate = rowView.findViewById(R.id.tvDate);
                TextView tvDay = rowView.findViewById(R.id.tvDay);
                TextView tvStatus = rowView.findViewById(R.id.tvStatus);
                TextView tvPunchIn = rowView.findViewById(R.id.tvPunchIn);
                TextView tvPunchOut = rowView.findViewById(R.id.tvPunchOut);
                TextView tvTotalHours = rowView.findViewById(R.id.tvTotalHours);
                TextView tvOvertime = rowView.findViewById(R.id.tvOvertime);
                TextView tvNotes = rowView.findViewById(R.id.tvNotes);

                // Set employee name (for all employees report)
                if (tvEmployee != null) {
                    tvEmployee.setText(item.getEmployeeName());
                }

                // Format date
                try {
                    Date date = dateFormat.parse(item.getDate());
                    tvDate.setText(displayDateFormat.format(date));
                } catch (ParseException e) {
                    tvDate.setText(item.getDate());
                }

                tvDay.setText(item.getDay().substring(0, 3)); // Show first 3 letters of day
                tvStatus.setText(item.getStatus());
                tvPunchIn.setText(item.getPunchIn() != null ? item.getPunchIn() : "--:--");
                tvPunchOut.setText(item.getPunchOut() != null ? item.getPunchOut() : "--:--");
                tvTotalHours.setText(item.getTotalHours() != null ? item.getTotalHours() : "0h 0m");
                tvOvertime.setText(item.getOvertime() != null ? item.getOvertime() : "0h 0m");
                tvNotes.setText(item.getLeaveReason() != null ? item.getLeaveReason() : "");

                // Set status color
                setStatusColor(tvStatus, item.getStatus());

                tableRowsContainer.addView(rowView);
            }
        }

        // Re-enable generate button
        btnGenerateReport.setEnabled(true);
        btnGenerateReport.setText("Generate");
    }

    private void setStatusColor(TextView textView, String status) {
        if (status == null) return;

        int colorId;
        switch (status.toUpperCase()) {
            case "PRESENT":
            case "PUNCHED_IN":
            case "PUNCHED_OUT":
                colorId = R.color.green_success;
                break;
            case "LATE":
                colorId = R.color.orange_warning;
                break;
            case "ABSENT":
                colorId = R.color.red_error;
                break;
            case "HALF_DAY":
                colorId = R.color.orange_warning;
                break;
            case "LEAVE":
            case "LEAVE_APPROVED":
                colorId = R.color.blue_info;
                break;
            case "LEAVE_PENDING":
                colorId = R.color.half_day_yellow;
                break;
            case "WEEK_OFF":
            case "HOLIDAY":
                colorId = R.color.gray_default;
                break;
            case "WORKING":
                colorId = R.color.blue_info;
                break;
            case "FUTURE":
                colorId = R.color.gray_default;
                break;
            default:
                colorId = R.color.text_primary;
                break;
        }
        textView.setTextColor(ContextCompat.getColor(this, colorId));
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void printReport() {
        // Create HTML for printing
        String htmlContent = generateHtmlForPrint();

        // Create WebView for printing
        WebView webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                createPrintJob(webView);
            }
        });

        // Load HTML content
        webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null);
    }

    private String generateHtmlForPrint() {
        StringBuilder html = new StringBuilder();

        // HTML header
        html.append("<!DOCTYPE html><html><head>")
                .append("<meta charset=\"UTF-8\">")
                .append("<title>Attendance Report</title>")
                .append("<style>")
                .append("body { font-family: Arial, sans-serif; margin: 20px; }")
                .append("h1 { color: #333; text-align: center; }")
                .append("h3 { color: #666; text-align: center; }")
                .append("table { width: 100%; border-collapse: collapse; margin-top: 20px; }")
                .append("th { background-color: #0D8A7E; color: white; padding: 10px; text-align: center; }")
                .append("td { border: 1px solid #ddd; padding: 8px; text-align: center; }")
                .append(".present { color: #4CAF50; font-weight: bold; }")
                .append(".absent { color: #F44336; font-weight: bold; }")
                .append(".late { color: #FF9800; font-weight: bold; }")
                .append(".leave { color: #2196F3; font-weight: bold; }")
                .append(".halfday { color: #FF9800; font-weight: bold; }")
                .append(".summary { margin-top: 30px; padding: 15px; background-color: #f5f5f5; border-radius: 5px; }")
                .append("</style>")
                .append("</head><body>");

        // Report title
        html.append("<h1>Attendance Report</h1>")
                .append("<h3>").append(months[selectedMonth]).append(" ").append(selectedYear)
                .append(" - ").append(selectedEmployeeName).append("</h3>");

        // Summary section
        html.append("<div class=\"summary\">")
                .append("<strong>Summary:</strong><br>")
                .append("Present Days: ").append(presentCount).append("<br>")
                .append("Late Days: ").append(lateCount).append("<br>")
                .append("Absent Days: ").append(absentCount).append("<br>")
                .append("Leave Days: ").append(leaveCount).append("<br>")
                .append("Half Days: ").append(halfDayCount).append("<br>")
                .append("Total Working Days: ").append(workingDaysCount)
                .append("</div>");

        // Table header
        html.append("<table>")
                .append("<tr>");

        // Add Employee column for all employees report
        if (selectedEmployeeId.equals("all")) {
            html.append("<th>Employee</th>");
        }

        html.append("<th>Date</th>")
                .append("<th>Day</th>")
                .append("<th>Status</th>")
                .append("<th>Punch In</th>")
                .append("<th>Punch Out</th>")
                .append("<th>Total Hours</th>")
                .append("<th>Overtime</th>")
                .append("<th>Notes</th>")
                .append("</tr>");

        // Table rows
        for (AttendanceReportItem item : reportItems) {
            String statusClass = "";
            String status = item.getStatus().toUpperCase();
            if (status.contains("PRESENT") || status.contains("PUNCHED")) {
                statusClass = "present";
            } else if (status.contains("LATE")) {
                statusClass = "late";
            } else if (status.contains("ABSENT")) {
                statusClass = "absent";
            } else if (status.contains("LEAVE")) {
                statusClass = "leave";
            } else if (status.contains("HALF")) {
                statusClass = "halfday";
            }

            html.append("<tr>");

            // Add Employee column for all employees report
            if (selectedEmployeeId.equals("all")) {
                html.append("<td>").append(item.getEmployeeName()).append("</td>");
            }

            html.append("<td>").append(formatDateForDisplay(item.getDate())).append("</td>")
                    .append("<td>").append(item.getDay().substring(0, 3)).append("</td>")
                    .append("<td class=\"").append(statusClass).append("\">").append(item.getStatus()).append("</td>")
                    .append("<td>").append(item.getPunchIn() != null ? item.getPunchIn() : "--:--").append("</td>")
                    .append("<td>").append(item.getPunchOut() != null ? item.getPunchOut() : "--:--").append("</td>")
                    .append("<td>").append(item.getTotalHours() != null ? item.getTotalHours() : "0h 0m").append("</td>")
                    .append("<td>").append(item.getOvertime() != null ? item.getOvertime() : "0h 0m").append("</td>")
                    .append("<td>").append(item.getLeaveReason() != null ? item.getLeaveReason() : "").append("</td>")
                    .append("</tr>");
        }

        html.append("</table>")
                .append("<p style=\"text-align: center; margin-top: 30px; color: #666;\">")
                .append("Generated on: ").append(new SimpleDateFormat("dd-MMM-yyyy HH:mm", Locale.getDefault()).format(new Date()))
                .append("</p>")
                .append("</body></html>");

        return html.toString();
    }

    private String formatDateForDisplay(String dateStr) {
        try {
            Date date = dateFormat.parse(dateStr);
            return displayDateFormat.format(date);
        } catch (ParseException e) {
            return dateStr;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createPrintJob(WebView webView) {
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        String jobName = "Attendance_Report_" + months[selectedMonth] + "_" + selectedYear;

        PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter(jobName);

        if (printManager != null) {
            printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
        }
    }

    private void exportToPdf() {
        String htmlContent = generateHtmlForPrint();

        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            String fileName = "Attendance_Report_" + months[selectedMonth] + "_" + selectedYear + "_" +
                    selectedEmployeeName.replace(" ", "_") + ".html";
            File file = new File(downloadsDir, fileName);

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(htmlContent.getBytes());
            fos.close();

            Toast.makeText(this, "Report saved to Downloads folder", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error saving report: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}