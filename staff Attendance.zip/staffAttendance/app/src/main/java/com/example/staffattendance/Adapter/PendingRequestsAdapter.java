package com.example.staffattendance.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.LeaveItem;
import com.example.staffattendance.Model.Employee;
import com.example.staffattendance.R;
import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PendingRequestsAdapter extends RecyclerView.Adapter<PendingRequestsAdapter.ViewHolder> {

    private List<LeaveItem> requestList;
    private Map<String, Employee> employeeMap; // FIXED: Add employee map
    private OnRequestActionListener listener;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
    private SimpleDateFormat monthDayFormat = new SimpleDateFormat("MMM dd", Locale.US);

    public interface OnRequestActionListener {
        void onApprove(LeaveItem request);
        void onReject(LeaveItem request);
    }

    // FIXED: Updated constructor to accept employeeMap
    public PendingRequestsAdapter(List<LeaveItem> requestList, Map<String, Employee> employeeMap, OnRequestActionListener listener) {
        this.requestList = requestList;
        this.employeeMap = employeeMap;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pending_request, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LeaveItem request = requestList.get(position);

        // FIXED: Get employee from map using empId
        Employee employee = employeeMap != null ? employeeMap.get(request.getEmpId()) : null;

        // Set employee details
        if (employee != null) {
            holder.tvEmployeeName.setText(employee.getName() != null ? employee.getName() : "Unknown");
            holder.tvEmployeeDept.setText(employee.getDepartment() != null ?
                    employee.getDepartment() : "Not specified");

            // Set initials
            String initials = getInitials(employee.getName());
            holder.tvEmployeeInitials.setText(initials);
        } else {
            holder.tvEmployeeName.setText("Unknown Employee");
            holder.tvEmployeeDept.setText("Not specified");
            holder.tvEmployeeInitials.setText("?");
        }

        // Set leave type and badge color
        String leaveType = request.getLeaveType() != null ? request.getLeaveType() : "Leave";
        holder.tvLeaveType.setText(leaveType.toUpperCase());

        // Set badge color based on leave type
        setBadgeColor(holder.tvLeaveType, leaveType);

        // Set dates
        String startDateStr = request.getStartDate();
        String endDateStr = request.getEndDate();

        if (startDateStr != null && endDateStr != null && !startDateStr.isEmpty() && !endDateStr.isEmpty()) {
            holder.tvDateRange.setText(formatDateRangeFromStrings(startDateStr, endDateStr));
        } else {
            holder.tvDateRange.setText("Invalid dates");
        }

        // Set days count
        int days = request.getDaysAsInt();
        holder.tvDaysCount.setText(days + " day" + (days > 1 ? "s" : ""));

        // Set applied date
        if (request.getTimestamp() > 0) {
            holder.tvAppliedDate.setText(dateFormat.format(new Date(request.getTimestamp())));
        } else {
            holder.tvAppliedDate.setText("Unknown date");
        }

        // Set reason
        holder.tvReason.setText(request.getReason() != null ? request.getReason() : "No reason provided");

        // Show/hide action buttons based on status
        if ("PENDING".equalsIgnoreCase(request.getStatus())) {
            holder.btnApprove.setVisibility(View.VISIBLE);
            holder.btnReject.setVisibility(View.VISIBLE);
        } else {
            holder.btnApprove.setVisibility(View.GONE);
            holder.btnReject.setVisibility(View.GONE);
        }

        // Set action buttons with null check
        holder.btnApprove.setOnClickListener(v -> {
            if (listener != null) listener.onApprove(request);
        });

        holder.btnReject.setOnClickListener(v -> {
            if (listener != null) listener.onReject(request);
        });
    }

    @Override
    public int getItemCount() {
        return requestList != null ? requestList.size() : 0;
    }

    private String getInitials(String name) {
        if (name == null || name.isEmpty()) return "?";
        String[] words = name.split(" ");
        StringBuilder initials = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                initials.append(word.charAt(0));
            }
        }
        return initials.toString().toUpperCase();
    }

    private String formatDateRangeFromStrings(String startDateStr, String endDateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);

            String start = monthDayFormat.format(startDate);
            String end = monthDayFormat.format(endDate);
            return start + " - " + end;
        } catch (Exception e) {
            return startDateStr + " - " + endDateStr;
        }
    }

    private void setBadgeColor(TextView badge, String leaveType) {
        if (leaveType == null) return;

        switch (leaveType.toLowerCase()) {
            case "sick":
            case "sick leave":
                badge.setBackgroundResource(R.drawable.badge_sick);
                badge.setTextColor(0xFF2196F3);
                break;
            case "casual":
            case "casual leave":
                badge.setBackgroundResource(R.drawable.badge_casual);
                badge.setTextColor(0xFFFF9800);
                break;
            case "annual":
            case "annual leave":
            case "earned leave":
                badge.setBackgroundResource(R.drawable.badge_annual);
                badge.setTextColor(0xFF4CAF50);
                break;
            default:
                badge.setBackgroundResource(R.drawable.badge_default);
                badge.setTextColor(0xFF9C27B0);
                break;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivEmployeeAvatar;
        TextView tvEmployeeInitials, tvEmployeeName, tvEmployeeDept, tvLeaveType;
        TextView tvDateRange, tvDaysCount, tvAppliedDate, tvReason;
        MaterialButton btnApprove, btnReject;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivEmployeeAvatar = itemView.findViewById(R.id.ivEmployeeAvatar);
            tvEmployeeInitials = itemView.findViewById(R.id.tvEmployeeInitials);
            tvEmployeeName = itemView.findViewById(R.id.tvEmployeeName);
            tvEmployeeDept = itemView.findViewById(R.id.tvEmployeeDept);
            tvLeaveType = itemView.findViewById(R.id.tvLeaveType);
            tvDateRange = itemView.findViewById(R.id.tvDateRange);
            tvDaysCount = itemView.findViewById(R.id.tvDaysCount);
            tvAppliedDate = itemView.findViewById(R.id.tvAppliedDate);
            tvReason = itemView.findViewById(R.id.tvReason);
            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnReject = itemView.findViewById(R.id.btnReject);
        }
    }
}