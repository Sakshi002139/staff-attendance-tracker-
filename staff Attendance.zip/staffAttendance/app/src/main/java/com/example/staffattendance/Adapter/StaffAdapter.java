package com.example.staffattendance.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.StaffModel;
import com.example.staffattendance.R;
import com.example.staffattendance.StaffDetailsActivity;
import com.example.staffattendance.utils.SessionManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StaffAdapter extends RecyclerView.Adapter<StaffAdapter.ViewHolder> {

    private static final String TAG = "StaffAdapter";
    private List<StaffModel> list;
    private Context context;

    // Company office start time and grace period
    private static final String OFFICE_START_TIME = "09:30"; // 9:30 AM
    private static final String GRACE_PERIOD_END = "09:45"; // 9:45 AM (15 minutes grace)

    // Time formatters
    private static final SimpleDateFormat TIME_FORMAT_12H = new SimpleDateFormat("hh:mm a", Locale.getDefault());
    private static final SimpleDateFormat TIME_FORMAT_24H = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private static final SimpleDateFormat TIME_FORMAT_12H_NO_AMPM = new SimpleDateFormat("hh:mm", Locale.getDefault());
    private static final SimpleDateFormat TIME_FORMAT_HOUR_MIN = new SimpleDateFormat("HH:mm", Locale.getDefault());

    public StaffAdapter(List<StaffModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_staff, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        StaffModel staff = list.get(position);

        String name = staff.getName() == null ? "Unknown" : staff.getName();
        holder.name.setText(name);

        // ===============================
        // ATTENDANCE STATUS WITH LATE MARK (9:30-9:45 GRACE PERIOD)
        // ===============================

        String status = staff.getStatus();
        String checkInTime = staff.getCheckIn();

        // Debug: Log the actual check-in time
        Log.d(TAG, "Staff: " + name + ", CheckIn Time: '" + checkInTime + "', Status: " + status);

        // Check if employee is late (after 9:45)
        boolean isLate = checkIfLate(checkInTime);
        // Check if employee checked in during grace period (9:30-9:45)
        boolean isGracePeriod = checkIfGracePeriod(checkInTime);

        // Debug: Log the results
        Log.d(TAG, "isLate: " + isLate + ", isGracePeriod: " + isGracePeriod);

        if ("PRESENT".equalsIgnoreCase(status)) {

            if (isLate) {
                holder.status.setText("LATE");
                holder.status.setTextColor(Color.parseColor("#FF9800")); // Orange for late
            } else if (isGracePeriod) {
                holder.status.setText("ON TIME (Grace)");
                holder.status.setTextColor(Color.parseColor("#4CAF50")); // Green for on time with grace
            } else {
                holder.status.setText("ON TIME");
                holder.status.setTextColor(Color.parseColor("#4CAF50"));
            }

        }
        else if ("IN".equalsIgnoreCase(status)) {

            if (isLate) {
                holder.status.setText("LATE (IN)");
                holder.status.setTextColor(Color.parseColor("#FF9800")); // Orange for late
            } else if (isGracePeriod) {
                holder.status.setText("IN (Grace)");
                holder.status.setTextColor(Color.parseColor("#4CAF50")); // Green for in with grace
            } else {
                holder.status.setText("IN OFFICE");
                holder.status.setTextColor(Color.parseColor("#4CAF50"));
            }

        }
        else if ("HALF_DAY".equalsIgnoreCase(status)) {

            holder.status.setText("HALF DAY");
            holder.status.setTextColor(Color.parseColor("#FFC107"));

        }
        else if ("LATE".equalsIgnoreCase(status)) {

            holder.status.setText("LATE");
            holder.status.setTextColor(Color.parseColor("#FF9800"));

        }
        else {

            holder.status.setText("NO PUNCH");
            holder.status.setTextColor(Color.GRAY);
        }

        // ===============================
        // PUNCH TIMES
        // ===============================

        String inTime = staff.getCheckIn() == null ? "--" : staff.getCheckIn();
        String outTime = staff.getCheckOut() == null ? "--" : staff.getCheckOut();

        holder.checkIn.setText("IN: " + inTime);
        holder.checkOut.setText("OUT: " + outTime);

        // Clear any existing compound drawables
        holder.checkIn.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);

        // Show late indicator if applicable (only for truly late, not grace period)
        if (isLate && !"--".equals(inTime)) {
            holder.checkIn.setTextColor(Color.parseColor("#FF9800"));
            holder.checkIn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_late, 0, 0, 0);
        }
        // Show grace period indicator
        else if (isGracePeriod && !"--".equals(inTime)) {
            holder.checkIn.setTextColor(Color.parseColor("#4CAF50"));
            holder.checkIn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_grace, 0, 0, 0);
        }
        else {
            holder.checkIn.setTextColor(Color.parseColor("#666666"));
        }

        // ===============================
        // AVATAR
        // ===============================

        if (!name.isEmpty()) {
            holder.initial.setText(name.substring(0, 1).toUpperCase());
        } else {
            holder.initial.setText("?");
        }

        // ===============================
        // ACCOUNT STATUS
        // ===============================

        String accountStatus = staff.getAccountStatus();

        if ("active".equalsIgnoreCase(accountStatus)) {

            holder.btnAction.setText("ACTIVE");
            holder.btnAction.setTextColor(Color.WHITE);
            setButtonColor(holder.btnAction, "#4CAF50");

        }
        else if ("inactive".equalsIgnoreCase(accountStatus)) {

            holder.btnAction.setText("INACTIVE");
            holder.btnAction.setTextColor(Color.WHITE);
            setButtonColor(holder.btnAction, "#F44336");

        }
        else {

            holder.btnAction.setText("+ INVITE");
            holder.btnAction.setTextColor(Color.WHITE);
            setButtonColor(holder.btnAction, "#00A86B");
        }

        // ===============================
        // OPEN STAFF DETAILS
        // ===============================

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(context, StaffDetailsActivity.class);

            SessionManager sessionManager = new SessionManager(context);

            intent.putExtra("employeeId", staff.getEmpId());
            intent.putExtra("employeeName", name);
            intent.putExtra("companyKey", sessionManager.getCompanyKey());

            intent.putExtra("status", staff.getStatus());
            intent.putExtra("checkIn", staff.getCheckIn());
            intent.putExtra("checkOut", staff.getCheckOut());
            intent.putExtra("isLate", isLate); // Pass late status
            intent.putExtra("isGracePeriod", isGracePeriod); // Pass grace period status

            context.startActivity(intent);
        });
    }

    /**
     * Parse time with multiple format support - FIXED VERSION
     */
    private Date parseTime(String timeString) {
        if (timeString == null || timeString.isEmpty() || "--".equals(timeString)) {
            return null;
        }

        Log.d(TAG, "Attempting to parse time: '" + timeString + "'");

        // Try to clean the time string
        String cleanTime = timeString.trim();

        // Try primary format (hh:mm a) - e.g., "09:30 AM"
        try {
            Date date = TIME_FORMAT_12H.parse(cleanTime);
            Log.d(TAG, "Successfully parsed with hh:mm a format: " + cleanTime);
            return date;
        } catch (ParseException e) {
            // Continue to next format
        }

        // Try 24-hour format (HH:mm) - e.g., "09:30"
        try {
            Date date = TIME_FORMAT_24H.parse(cleanTime);
            Log.d(TAG, "Successfully parsed with HH:mm format: " + cleanTime);
            return date;
        } catch (ParseException e) {
            // Continue to next format
        }

        // Try 12-hour without AM/PM (hh:mm) - e.g., "09:30"
        try {
            Date date = TIME_FORMAT_12H_NO_AMPM.parse(cleanTime);
            Log.d(TAG, "Successfully parsed with hh:mm format: " + cleanTime);
            return date;
        } catch (ParseException e) {
            // Continue to next format
        }

        // Try simple hour:minute format
        try {
            // Check if it's just "HHmm" format like "0930"
            if (cleanTime.length() == 4 && cleanTime.matches("\\d{4}")) {
                String formatted = cleanTime.substring(0, 2) + ":" + cleanTime.substring(2, 4);
                Date date = TIME_FORMAT_24H.parse(formatted);
                Log.d(TAG, "Successfully parsed from HHmm to " + formatted);
                return date;
            }
        } catch (Exception e) {
            // Continue
        }

        // Try to extract time from possible timestamp
        try {
            // If it's a timestamp like "2024-01-15 09:30:00"
            if (cleanTime.contains(" ")) {
                String[] parts = cleanTime.split(" ");
                for (String part : parts) {
                    if (part.contains(":")) {
                        // Found time part
                        Date date = TIME_FORMAT_24H.parse(part);
                        if (date != null) {
                            Log.d(TAG, "Successfully parsed time part: " + part);
                            return date;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // Continue
        }

        Log.e(TAG, "Could not parse time with any format: " + timeString);
        return null;
    }

    /**
     * Convert time to minutes since midnight for easier comparison
     */
    private int getTimeInMinutes(Date time) {
        if (time == null) return -1;

        SimpleDateFormat hourFormat = new SimpleDateFormat("HH", Locale.getDefault());
        SimpleDateFormat minuteFormat = new SimpleDateFormat("mm", Locale.getDefault());

        try {
            int hours = Integer.parseInt(hourFormat.format(time));
            int minutes = Integer.parseInt(minuteFormat.format(time));
            return hours * 60 + minutes;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Check if employee checked in during grace period (9:30 - 9:45)
     */
    private boolean checkIfGracePeriod(String checkInTime) {
        if (checkInTime == null || checkInTime.isEmpty() || "--".equals(checkInTime)) {
            return false;
        }

        Date checkInDate = parseTime(checkInTime);
        if (checkInDate == null) {
            return false;
        }

        int checkInMinutes = getTimeInMinutes(checkInDate);
        if (checkInMinutes == -1) return false;

        // Convert office times to minutes
        int officeStartMinutes = 9 * 60 + 30; // 9:30 = 570 minutes
        int graceEndMinutes = 9 * 60 + 45;     // 9:45 = 585 minutes

        Log.d(TAG, "checkIfGracePeriod: checkInMinutes=" + checkInMinutes +
                ", officeStart=" + officeStartMinutes + ", graceEnd=" + graceEndMinutes);

        // Check if time is between 9:30 and 9:45 (inclusive)
        return checkInMinutes >= officeStartMinutes && checkInMinutes <= graceEndMinutes;
    }

    /**
     * Check if employee checked in late (after 9:45)
     */
    private boolean checkIfLate(String checkInTime) {
        if (checkInTime == null || checkInTime.isEmpty() || "--".equals(checkInTime)) {
            return false;
        }

        Date checkInDate = parseTime(checkInTime);
        if (checkInDate == null) {
            return false;
        }

        int checkInMinutes = getTimeInMinutes(checkInDate);
        if (checkInMinutes == -1) return false;

        // Convert grace end time to minutes
        int graceEndMinutes = 9 * 60 + 45; // 9:45 = 585 minutes

        Log.d(TAG, "checkIfLate: checkInMinutes=" + checkInMinutes + ", graceEnd=" + graceEndMinutes);

        // Check if time is after 9:45
        return checkInMinutes > graceEndMinutes;
    }

    // ===============================
    // BUTTON BACKGROUND HELPER
    // ===============================

    private void setButtonColor(TextView view, String color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(50);
        bg.setColor(Color.parseColor(color));
        view.setBackground(bg);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void updateList(List<StaffModel> newList) {
        list = newList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView name, status, checkIn, checkOut, initial, btnAction;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.tvName);
            status = itemView.findViewById(R.id.tvStatus);
            checkIn = itemView.findViewById(R.id.tvCheckIn);
            checkOut = itemView.findViewById(R.id.tvCheckOut);
            initial = itemView.findViewById(R.id.tvInitial);
            btnAction = itemView.findViewById(R.id.btnAction);
        }
    }
}