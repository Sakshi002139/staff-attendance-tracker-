package com.example.staffattendance.Model;

// MonthlySummary.java
public class MonthlySummary {
    private int present;
    private int absent;
    private int halfDays;
    private int totalWorkingDays;
    private double totalWorkingHours;

    // Add leave statistics
    private int totalLeaves;        // All leave types (approved + pending + rejected)
    private int approvedLeaves;     // Only approved leaves
    private int pendingLeaves;      // Pending leave requests
    private int rejectedLeaves;     // Rejected leave requests

    // Empty constructor required for Firebase
    public MonthlySummary() {}

    // Updated constructor with leave parameters
    public MonthlySummary(int present, int absent, int halfDays,
                          int approvedLeaves, int pendingLeaves, int rejectedLeaves) {
        this.present = present;
        this.absent = absent;
        this.halfDays = halfDays;
        this.approvedLeaves = approvedLeaves;
        this.pendingLeaves = pendingLeaves;
        this.rejectedLeaves = rejectedLeaves;
        this.totalLeaves = approvedLeaves + pendingLeaves + rejectedLeaves;
        this.totalWorkingDays = present + absent + halfDays + totalLeaves;
    }

    // Getters and setters
    public int getPresent() { return present; }
    public void setPresent(int present) {
        this.present = present;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    public int getAbsent() { return absent; }
    public void setAbsent(int absent) {
        this.absent = absent;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    public int getHalfDays() { return halfDays; }
    public void setHalfDays(int halfDays) {
        this.halfDays = halfDays;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    public int getTotalWorkingDays() { return totalWorkingDays; }
    public void setTotalWorkingDays(int totalWorkingDays) { this.totalWorkingDays = totalWorkingDays; }

    public double getTotalWorkingHours() { return totalWorkingHours; }
    public void setTotalWorkingHours(double totalWorkingHours) { this.totalWorkingHours = totalWorkingHours; }

    // Leave statistics getters and setters
    public int getTotalLeaves() { return totalLeaves; }
    public void setTotalLeaves(int totalLeaves) {
        this.totalLeaves = totalLeaves;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    public int getApprovedLeaves() { return approvedLeaves; }
    public void setApprovedLeaves(int approvedLeaves) {
        this.approvedLeaves = approvedLeaves;
        this.totalLeaves = this.approvedLeaves + this.pendingLeaves + this.rejectedLeaves;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    public int getPendingLeaves() { return pendingLeaves; }
    public void setPendingLeaves(int pendingLeaves) {
        this.pendingLeaves = pendingLeaves;
        this.totalLeaves = this.approvedLeaves + this.pendingLeaves + this.rejectedLeaves;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    public int getRejectedLeaves() { return rejectedLeaves; }
    public void setRejectedLeaves(int rejectedLeaves) {
        this.rejectedLeaves = rejectedLeaves;
        this.totalLeaves = this.approvedLeaves + this.pendingLeaves + this.rejectedLeaves;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    // Helper method to update all leave counts at once
    public void updateLeaveCounts(int approved, int pending, int rejected) {
        this.approvedLeaves = approved;
        this.pendingLeaves = pending;
        this.rejectedLeaves = rejected;
        this.totalLeaves = approved + pending + rejected;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    // Method to recalculate total working days
    public void recalculateTotals() {
        this.totalLeaves = this.approvedLeaves + this.pendingLeaves + this.rejectedLeaves;
        this.totalWorkingDays = this.present + this.absent + this.halfDays + this.totalLeaves;
    }

    // Method to convert to string for debugging
    @Override
    public String toString() {
        return "MonthlySummary{" +
                "present=" + present +
                ", absent=" + absent +
                ", halfDays=" + halfDays +
                ", totalWorkingDays=" + totalWorkingDays +
                ", totalWorkingHours=" + totalWorkingHours +
                ", totalLeaves=" + totalLeaves +
                ", approvedLeaves=" + approvedLeaves +
                ", pendingLeaves=" + pendingLeaves +
                ", rejectedLeaves=" + rejectedLeaves +
                '}';
    }
}