package com.example.staffattendance.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.LeaveRequestActivity;
import com.example.staffattendance.Model.CalendarDayModel;
import com.example.staffattendance.R;
import com.example.staffattendance.utils.DateUtils;
import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.DayViewHolder> {

    private List<CalendarDayModel> calendarDays;
    private final Context context;
    private OnDateClickListener onDateClickListener;

    // Remove companyKey and empId from constructor - we'll get them from the model or intent
    public CalendarAdapter(Context context, List<CalendarDayModel> calendarDays) {
        this.context = context;
        this.calendarDays = calendarDays;
    }

    public interface OnDateClickListener {
        void onDateClick(CalendarDayModel day);
    }

    public void setOnDateClickListener(OnDateClickListener listener) {
        this.onDateClickListener = listener;
    }

    public void updateData(List<CalendarDayModel> newData) {
        this.calendarDays = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_calendar_day, parent, false);
        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        CalendarDayModel day = calendarDays.get(position);

        // Check if it's an empty cell
        if (day.isEmptyCell()) {
            holder.bindEmptyCell();
            return;
        }

        holder.bindData(day);

        // Set click listener - only for valid dates that aren't empty
        holder.itemView.setOnClickListener(v -> {
            if (onDateClickListener != null) {
                onDateClickListener.onDateClick(day);
            }
            showAttendanceDetailsDialog(day);
        });
    }

    @Override
    public int getItemCount() {
        return calendarDays.size();
    }

    private void showAttendanceDetailsDialog(CalendarDayModel day) {
        View dialogView = LayoutInflater.from(context)
                .inflate(R.layout.dialog_attendance_details, null);

        TextView txtDate = dialogView.findViewById(R.id.txtDate);
        TextView txtDay = dialogView.findViewById(R.id.txtDay);
        TextView txtPunchIn = dialogView.findViewById(R.id.txtPunchIn);
        TextView txtPunchOut = dialogView.findViewById(R.id.txtPunchOut);
        TextView txtInStatus = dialogView.findViewById(R.id.txtInStatus);
        TextView txtOutStatus = dialogView.findViewById(R.id.txtOutStatus);
        TextView txtTotalHours = dialogView.findViewById(R.id.txtTotalHours);
        TextView txtOvertime = dialogView.findViewById(R.id.txtOvertime);
        TextView txtStatus = dialogView.findViewById(R.id.txtStatus);
        Button btnRequestLeave = dialogView.findViewById(R.id.btnRequestLeave);
        TextView txtLeaveInfo = dialogView.findViewById(R.id.txtLeaveInfo);

        // Format date
        txtDate.setText(formatDate(day.getDate()));
        txtDay.setText(getDayName(day.getDate()));

        // Check if it's Sunday or Holiday FIRST
        if (day.isSunday() || day.isHoliday()) {
            setupHolidayUI(txtStatus, txtPunchIn, txtInStatus, txtPunchOut, txtOutStatus,
                    txtTotalHours, txtOvertime, btnRequestLeave, txtLeaveInfo);
        }
        // Check for leave statuses SECOND
        else if (day.isAnyLeave()) {
            setupLeaveUI(day, txtStatus, txtPunchIn, txtInStatus, txtPunchOut, txtOutStatus,
                    txtTotalHours, txtOvertime, btnRequestLeave, txtLeaveInfo);
        }
        // Normal attendance day THIRD
        else {
            setupNormalAttendanceUI(day, txtPunchIn, txtInStatus, txtPunchOut, txtOutStatus,
                    txtTotalHours, txtOvertime, txtStatus, btnRequestLeave, txtLeaveInfo);
        }

        // Setup leave request button
        setupLeaveRequestButton(day, btnRequestLeave, txtLeaveInfo);

        // Create and show dialog
        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .setPositiveButton("Close", null)
                .create();

        // Set click listener for leave request button
        btnRequestLeave.setOnClickListener(v -> {
            Intent intent = new Intent(context, LeaveRequestActivity.class);
            intent.putExtra("selectedDate", day.getDate());
            context.startActivity(intent);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void setupHolidayUI(TextView txtStatus, TextView txtPunchIn, TextView txtInStatus,
                                TextView txtPunchOut, TextView txtOutStatus, TextView txtTotalHours,
                                TextView txtOvertime, Button btnRequestLeave, TextView txtLeaveInfo) {
        txtStatus.setText("HOLIDAY");
        txtStatus.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

        txtPunchIn.setText("--:--");
        txtInStatus.setText("Holiday");
        txtInStatus.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

        txtPunchOut.setText("--:--");
        txtOutStatus.setText("Holiday");
        txtOutStatus.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

        txtTotalHours.setText("0h 0m");
        txtOvertime.setText("0h 0m");

        btnRequestLeave.setVisibility(View.GONE);
        txtLeaveInfo.setVisibility(View.GONE);
    }

    private void setupLeaveUI(CalendarDayModel day, TextView txtStatus, TextView txtPunchIn,
                              TextView txtInStatus, TextView txtPunchOut, TextView txtOutStatus,
                              TextView txtTotalHours, TextView txtOvertime, Button btnRequestLeave,
                              TextView txtLeaveInfo) {

        String leaveStatusText = "LEAVE";
        int leaveColor = R.color.blue_info;

        if (day.isLeavePending()) {
            leaveStatusText = "LEAVE (PENDING)";
            leaveColor = R.color.orange_warning;
        } else if (day.isLeaveRejected()) {
            leaveStatusText = "LEAVE (REJECTED)";
            leaveColor = R.color.red_error;
        }

        txtStatus.setText(leaveStatusText);
        txtStatus.setTextColor(ContextCompat.getColor(context, leaveColor));

        txtPunchIn.setText("--:--");
        txtInStatus.setText("Leave Day");
        txtInStatus.setTextColor(ContextCompat.getColor(context, leaveColor));

        txtPunchOut.setText("--:--");
        txtOutStatus.setText("Leave Day");
        txtOutStatus.setTextColor(ContextCompat.getColor(context, leaveColor));

        txtTotalHours.setText("0h 0m");
        txtOvertime.setText("0h 0m");

        // Show leave details
        StringBuilder leaveInfo = new StringBuilder();
        if (day.getLeaveReason() != null && !day.getLeaveReason().isEmpty()) {
            leaveInfo.append("Reason: ").append(day.getLeaveReason());
        }
        if (day.getLeaveType() != null && !day.getLeaveType().isEmpty()) {
            if (leaveInfo.length() > 0) leaveInfo.append("\n");
            leaveInfo.append("Type: ").append(day.getLeaveType());
        }

        if (leaveInfo.length() > 0) {
            txtLeaveInfo.setText(leaveInfo.toString());
            txtLeaveInfo.setVisibility(View.VISIBLE);
        } else {
            txtLeaveInfo.setVisibility(View.GONE);
        }

        // Only show request button for future dates
        if (day.isFuture()) {
            btnRequestLeave.setText("Request Leave");
            btnRequestLeave.setVisibility(View.VISIBLE);
        } else {
            btnRequestLeave.setVisibility(View.GONE);
        }
    }

    private void setupNormalAttendanceUI(CalendarDayModel day, TextView txtPunchIn, TextView txtInStatus,
                                         TextView txtPunchOut, TextView txtOutStatus, TextView txtTotalHours,
                                         TextView txtOvertime, TextView txtStatus, Button btnRequestLeave,
                                         TextView txtLeaveInfo) {

        // Punch In
        if (day.getPunchIn() != null && !TextUtils.isEmpty(day.getPunchIn())) {
            txtPunchIn.setText(convertTo12HourFormat(day.getPunchIn()));
            String inStatus = day.getInStatus() != null ? day.getInStatus() : "--";
            txtInStatus.setText(inStatus);
            setStatusColor(txtInStatus, inStatus);
        } else {
            txtPunchIn.setText("--:--");
            txtInStatus.setText("No Punch");
            txtInStatus.setTextColor(ContextCompat.getColor(context, R.color.gray_default));
        }

        // Punch Out
        if (day.getPunchOut() != null && !TextUtils.isEmpty(day.getPunchOut())) {
            txtPunchOut.setText(convertTo12HourFormat(day.getPunchOut()));
            String outStatus = day.getOutStatus() != null ? day.getOutStatus() : "--";
            txtOutStatus.setText(outStatus);
            setStatusColor(txtOutStatus, outStatus);
        } else {
            txtPunchOut.setText("--:--");
            txtOutStatus.setText("No Punch");
            txtOutStatus.setTextColor(ContextCompat.getColor(context, R.color.gray_default));
        }

        // Total hours
        String totalHours = day.getTotalHours() != null ? day.getTotalHours() : "0h 0m";
        txtTotalHours.setText(totalHours);

        // Overtime
        String overtime = day.getOvertime() != null ? day.getOvertime() : "0h 0m";
        txtOvertime.setText(overtime);

        // Status
        String displayStatus = day.getDisplayStatus();
        txtStatus.setText(displayStatus.toUpperCase());
        setStatusColor(txtStatus, displayStatus);

        // Hide leave info for non-leave days
        txtLeaveInfo.setVisibility(View.GONE);
    }

    private void setupLeaveRequestButton(CalendarDayModel day, Button btnRequestLeave, TextView txtLeaveInfo) {
        // Only show leave request button for future dates (not Sundays/holidays)
        if (day.isFuture() && !day.isSunday() && !day.isHoliday() && !day.isAnyLeave()) {
            btnRequestLeave.setText("Request Leave");
            btnRequestLeave.setVisibility(View.VISIBLE);
        } else if (day.isFuture() && day.isAnyLeave()) {
            btnRequestLeave.setText("Modify Leave");
            btnRequestLeave.setVisibility(View.VISIBLE);
        } else {
            btnRequestLeave.setVisibility(View.GONE);
        }
    }

    private String convertTo12HourFormat(String time24) {
        try {
            SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date date = sdf24.parse(time24);
            return sdf12.format(date);
        } catch (Exception e) {
            return time24;
        }
    }

    private void setStatusColor(TextView textView, String status) {
        if (status == null) return;

        String statusUpper = status.toUpperCase();
        int colorId;

        switch (statusUpper) {
            case "PRESENT":
                colorId = R.color.green_success;
                break;
            case "HALF_DAY":
            case "LATE":
                colorId = R.color.orange_warning;
                break;
            case "ABSENT":
                colorId = R.color.red_error;
                break;
            case "LEAVE":
                colorId = R.color.blue_info;
                break;
            case "LEAVE_PENDING":
            case "LEAVE PENDING":
                colorId = R.color.orange_warning;
                break;
            case "LEAVE_REJECTED":
            case "LEAVE REJECTED":
                colorId = R.color.red_error;
                break;
            case "HOLIDAY":
            case "SUNDAY":
                colorId = R.color.gray_default;
                break;
            case "TODAY":
            case "WORKING":
                colorId = R.color.blue_info;
                break;
            case "FUTURE":
                colorId = R.color.text_primary;
                break;
            default:
                colorId = R.color.gray_default;
                break;
        }

        textView.setTextColor(ContextCompat.getColor(context, colorId));
    }

    private String formatDate(String dateStr) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault());
            Date date = inputFormat.parse(dateStr);
            return outputFormat.format(date);
        } catch (Exception e) {
            return dateStr;
        }
    }

    private String getDayName(String dateStr) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
            Date date = inputFormat.parse(dateStr);
            return dayFormat.format(date);
        } catch (Exception e) {
            return "";
        }
    }

    static class DayViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtDayNumber;
        private final MaterialCardView cardView;
        private final View statusIndicator;
        private final Context context;

        DayViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDayNumber = itemView.findViewById(R.id.txtDay);
            cardView = itemView.findViewById(R.id.dayCard);
            statusIndicator = itemView.findViewById(R.id.statusIndicator);
            context = itemView.getContext();
        }

        void bindData(CalendarDayModel day) {
            // Set day number
            txtDayNumber.setText(day.getDayNumber());

            // Apply styling based on day status
            applyCardStyle(day);

            // Make card clickable only for valid dates (not empty, not future)
            cardView.setClickable(!day.isEmptyCell() && !day.isFuture());
        }

        private void applyCardStyle(CalendarDayModel day) {
            // Reset to default style first
            resetCardStyle();

            // Apply specific style based on status
            if (day.isSunday() || day.isHoliday()) {
                applyHolidayStyle();
            } else if (day.isLeaveApproved()) {
                applyLeaveApprovedStyle();
            } else if (day.isLeavePending()) {
                applyLeavePendingStyle();
            } else if (day.isLeaveRejected()) {
                applyLeaveRejectedStyle();
            } else if (day.isPresent()) {
                applyPresentStyle();
            } else if (day.isHalfDay()) {
                applyHalfDayStyle();
            } else if (day.isLate()) {
                applyLateStyle();
            } else if (day.isAbsent()) {
                applyAbsentStyle();
            } else if (day.isToday()) {
                applyTodayStyle();
            } else if (day.isFuture()) {
                applyFutureStyle();
            } else {
                // Default for other statuses (PENDING, EMPTY, etc.)
                applyDefaultStyle();
            }
        }

        private void resetCardStyle() {
            cardView.setCardBackgroundColor(Color.WHITE);
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            cardView.setStrokeWidth(1);
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }

        private void applyHolidayStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.gray_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.gray_default));
            }
        }

        private void applyPresentStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.green_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.green_success));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.green_success));
            }
        }

        private void applyHalfDayStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.orange_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.orange_warning));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.orange_warning));
            }
        }

        private void applyLateStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.blue_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.blue_info));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.blue_info));
            }
        }

        private void applyAbsentStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.red_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.red_error));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.red_error));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.red_error));
            }
        }

        private void applyLeaveApprovedStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.blue_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.blue_info));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.blue_info));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.blue_info));
            }
        }

        private void applyLeavePendingStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.orange_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.orange_warning));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.orange_warning));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.orange_warning));
            }
        }

        private void applyLeaveRejectedStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.red_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.red_error));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.red_error));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.red_error));
            }
        }

        private void applyTodayStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.blue_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.blue_info));
            cardView.setStrokeWidth(2);
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.blue_info));
            txtDayNumber.getPaint().setFakeBoldText(true);

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.blue_info));
            }
        }

        private void applyFutureStyle() {
            cardView.setCardBackgroundColor(Color.WHITE);
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }

        private void applyDefaultStyle() {
            cardView.setCardBackgroundColor(Color.WHITE);
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }

        void bindEmptyCell() {
            txtDayNumber.setText("");
            cardView.setCardBackgroundColor(Color.TRANSPARENT);
            cardView.setStrokeWidth(0);
            cardView.setClickable(false);

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }
    }
}