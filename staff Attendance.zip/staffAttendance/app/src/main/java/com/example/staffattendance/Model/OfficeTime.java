package com.example.staffattendance.Model;

import java.util.ArrayList;
import java.util.List;

public class OfficeTime {
    private String startTime;
    private String endTime;
    private String breakStart;
    private String breakEnd;
    private List<String> workingDays; // CHANGED FROM String[] TO List<String>
    private boolean applyToAll;
    private long createdAt;
    private long updatedAt;
    private String lastUpdatedBy;

    // Default constructor required for Firebase
    public OfficeTime() {
        this.workingDays = new ArrayList<>();
    }

    // Constructor with parameters
    public OfficeTime(String startTime, String endTime, List<String> workingDays) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.workingDays = workingDays != null ? workingDays : new ArrayList<>();
        this.applyToAll = true;
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = System.currentTimeMillis();
    }

    // Getters and Setters
    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getBreakStart() {
        return breakStart;
    }

    public void setBreakStart(String breakStart) {
        this.breakStart = breakStart;
    }

    public String getBreakEnd() {
        return breakEnd;
    }

    public void setBreakEnd(String breakEnd) {
        this.breakEnd = breakEnd;
    }

    public List<String> getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(List<String> workingDays) {
        this.workingDays = workingDays != null ? workingDays : new ArrayList<>();
    }

    // Helper method for backward compatibility if needed
    public void setWorkingDaysArray(String[] workingDaysArray) {
        this.workingDays = new ArrayList<>();
        if (workingDaysArray != null) {
            for (String day : workingDaysArray) {
                if (day != null && !day.trim().isEmpty()) {
                    this.workingDays.add(day);
                }
            }
        }
    }

    public boolean isApplyToAll() {
        return applyToAll;
    }

    public void setApplyToAll(boolean applyToAll) {
        this.applyToAll = applyToAll;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    // Helper methods
    public String getWorkingDaysString() {
        if (workingDays == null || workingDays.isEmpty()) {
            return "No days selected";
        }
        return String.join(", ", workingDays);
    }

    // Check if a day is working day
    public boolean isWorkingDay(String day) {
        if (workingDays == null || workingDays.isEmpty()) return false;
        for (String workingDay : workingDays) {
            if (workingDay.equalsIgnoreCase(day)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "OfficeTime{" +
                "startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", workingDays=" + workingDays +
                ", applyToAll=" + applyToAll +
                '}';
    }
}