package com.example.staffattendance;

import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.staffattendance.utils.StaticMapAPIUtils;

public class TestMapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_map);

        ImageView ivMap = findViewById(R.id.ivMap);

        // Test with your office coordinates
        double officeLat = 16.8520;
        double officeLng = 74.5620;

        // Load map
        StaticMapAPIUtils.loadPunchLocationMap(this, ivMap, officeLat, officeLng, "OFFICE");
    }
}