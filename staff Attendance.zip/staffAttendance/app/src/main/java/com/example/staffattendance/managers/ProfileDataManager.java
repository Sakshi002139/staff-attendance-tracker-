package com.example.staffattendance.managers;

import android.content.Context;
import android.util.Log;

import com.example.staffattendance.listeners.ProfileDataListener;
import com.example.staffattendance.models.Admin;
import com.example.staffattendance.models.Company;
import com.example.staffattendance.utils.FirebaseManager;
import com.example.staffattendance.utils.SessionManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class ProfileDataManager {

    private static final String TAG = "ProfileDataManager";

    private final FirebaseManager firebaseManager;
    private final SessionManager sessionManager;

    private ProfileDataListener listener;

    private ValueEventListener adminListener;
    private ValueEventListener companyListener;
    private ValueEventListener employeeListener;

    public ProfileDataManager(Context context) {
        firebaseManager = FirebaseManager.getInstance();
        sessionManager = new SessionManager(context);
    }

    public void setProfileDataListener(ProfileDataListener listener) {
        this.listener = listener;
    }

    // ================= LOAD ALL PROFILE DATA =================

    public void loadProfileData() {
        String companyKey = sessionManager.getCompanyKey();
        String phone = sessionManager.getUserPhone();

        if (companyKey == null || phone == null) {
            if (listener != null) {
                listener.onError("Session expired. Please login again.");
            }
            return;
        }

        loadAdminData(companyKey, phone);
        loadCompanyData(companyKey);
        loadEmployeeCount(companyKey);
    }

    // ================= ADMIN DATA =================

    private void loadAdminData(String companyKey, String phone) {

        DatabaseReference adminRef =
                firebaseManager.getCompanyAdminsRef(companyKey).child(phone);

        adminListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                if (!snapshot.exists()) {
                    if (listener != null) listener.onError("Admin profile not found");
                    return;
                }

                Admin admin = snapshot.getValue(Admin.class);
                if (admin == null) {
                    if (listener != null) listener.onError("Failed to parse admin data");
                    return;
                }

                admin.setPhone(phone);

                // ✅ FIXED: MATCHES YOUR SessionManager EXACTLY
                sessionManager.saveUserData(
                        admin.getName(),
                        admin.getEmail()
                );

                if (listener != null) {
                    listener.onAdminDataLoaded(admin);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (listener != null) listener.onError(error.getMessage());
            }
        };

        adminRef.addValueEventListener(adminListener);
    }

    // ================= COMPANY DATA =================

    private void loadCompanyData(String companyKey) {

        DatabaseReference companyRef =
                firebaseManager.getCompanyRef(companyKey);

        companyListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                if (!snapshot.exists()) {
                    if (listener != null) listener.onError("Company not found");
                    return;
                }

                Company company = snapshot.getValue(Company.class);
                if (company == null) {
                    if (listener != null) listener.onError("Failed to parse company data");
                    return;
                }

                sessionManager.setCompanyName(company.getCompanyName());

                if (listener != null) {
                    listener.onCompanyDataLoaded(company);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (listener != null) listener.onError(error.getMessage());
            }
        };

        companyRef.addValueEventListener(companyListener);
    }

    // ================= EMPLOYEE COUNT =================

    private void loadEmployeeCount(String companyKey) {

        DatabaseReference employeesRef =
                firebaseManager.getCompanyEmployeesRef(companyKey);

        employeeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (listener != null) {
                    listener.onEmployeeCountLoaded((int) snapshot.getChildrenCount());
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (listener != null) listener.onEmployeeCountLoaded(0);
            }
        };

        employeesRef.addValueEventListener(employeeListener);
    }

    // ================= CLEANUP =================

    public void removeListeners() {

        String companyKey = sessionManager.getCompanyKey();
        String phone = sessionManager.getUserPhone();

        if (companyKey == null) return;

        if (adminListener != null && phone != null) {
            firebaseManager.getCompanyAdminsRef(companyKey)
                    .child(phone)
                    .removeEventListener(adminListener);
        }

        if (companyListener != null) {
            firebaseManager.getCompanyRef(companyKey)
                    .removeEventListener(companyListener);
        }

        if (employeeListener != null) {
            firebaseManager.getCompanyEmployeesRef(companyKey)
                    .removeEventListener(employeeListener);
        }
    }
}
