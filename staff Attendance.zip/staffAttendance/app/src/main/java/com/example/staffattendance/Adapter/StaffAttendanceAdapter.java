package com.example.staffattendance.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Model.StaffAttendanceModel;
import com.example.staffattendance.R;
import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StaffAttendanceAdapter extends RecyclerView.Adapter<StaffAttendanceAdapter.DayViewHolder> {

    private List<StaffAttendanceModel> attendanceDays;
    private final Context context;
    private OnDateClickListener onDateClickListener;

    public StaffAttendanceAdapter(Context context, List<StaffAttendanceModel> attendanceDays) {
        this.context = context;
        this.attendanceDays = attendanceDays;
    }

    public interface OnDateClickListener {
        void onDateClick(StaffAttendanceModel day);
    }

    public void setOnDateClickListener(OnDateClickListener listener) {
        this.onDateClickListener = listener;
    }

    public void updateData(List<StaffAttendanceModel> newData) {
        this.attendanceDays = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_calendar_day, parent, false);
        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        StaffAttendanceModel day = attendanceDays.get(position);

        // Check if it's an empty cell
        if (day.isEmptyCell()) {
            holder.bindEmptyCell();
            return;
        }

        holder.bindData(day);

        // Set click listener - only for valid dates that aren't empty
        holder.itemView.setOnClickListener(v -> {
            if (onDateClickListener != null && !day.isFuture()) {
                onDateClickListener.onDateClick(day);
            }
        });
    }

    @Override
    public int getItemCount() {
        return attendanceDays.size();
    }

    private String convertTo12HourFormat(String time24) {
        try {
            SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date date = sdf24.parse(time24);
            return sdf12.format(date);
        } catch (Exception e) {
            return time24;
        }
    }

    static class DayViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtDayNumber;
        private final MaterialCardView cardView;
        private final View statusIndicator;
        private final Context context;

        DayViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDayNumber = itemView.findViewById(R.id.txtDay);
            cardView = itemView.findViewById(R.id.dayCard);
            statusIndicator = itemView.findViewById(R.id.statusIndicator);
            context = itemView.getContext();
        }

        void bindData(StaffAttendanceModel day) {
            // Set day number
            txtDayNumber.setText(day.getDayNumber());

            // Apply styling based on day status
            applyCardStyle(day);

            // Make card clickable only for valid dates (not empty, not future)
            cardView.setClickable(!day.isEmptyCell() && !day.isFuture());
        }

        private void applyCardStyle(StaffAttendanceModel day) {
            // Reset to default style first
            resetCardStyle();

            // Apply specific style based on status
            if (day.isSunday() || day.isHoliday() || "WEEK_OFF".equalsIgnoreCase(day.getStatus())) {
                applyWeekOffStyle();
            } else if (day.isLeaveApproved() || "LEAVE".equalsIgnoreCase(day.getStatus())) {
                applyLeaveApprovedStyle();
            } else if (day.isLeavePending()) {
                applyLeavePendingStyle();
            } else if (day.isLeaveRejected()) {
                applyLeaveRejectedStyle();
            } else if (day.isPresent() || "PRESENT".equalsIgnoreCase(day.getStatus())) {
                applyPresentStyle();
            } else if (day.isHalfDay() || "HALF_DAY".equalsIgnoreCase(day.getStatus())) {
                applyHalfDayStyle();
            } else if (day.isLate() || "LATE".equalsIgnoreCase(day.getStatus())) {
                applyLateStyle();
            } else if (day.isAbsent() || "ABSENT".equalsIgnoreCase(day.getStatus())) {
                applyAbsentStyle();
            } else if (day.isToday() || "TODAY".equalsIgnoreCase(day.getStatus())) {
                applyTodayStyle();
            } else if (day.isFuture() || "FUTURE".equalsIgnoreCase(day.getStatus())) {
                applyFutureStyle();
            } else {
                // Default for other statuses (PENDING, EMPTY, etc.)
                applyDefaultStyle();
            }
        }

        private void resetCardStyle() {
            cardView.setCardBackgroundColor(Color.WHITE);
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            cardView.setStrokeWidth(1);
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }

        private void applyWeekOffStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.gray_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.gray_default));
            }
        }

        private void applyPresentStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.green_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.green_success));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.green_success));
            }
        }

        private void applyHalfDayStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.orange_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.orange_warning));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.orange_warning));
            }
        }

        private void applyLateStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.orange_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.orange_warning));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.orange_warning));
            }
        }

        private void applyAbsentStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.red_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.red_error));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.red_error));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.red_error));
            }
        }

        private void applyLeaveApprovedStyle() {
            // Use purple color for approved leave
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.purple_300));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.purple_primary));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.purple_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.purple_primary));
            }
        }

        private void applyLeavePendingStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.orange_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.orange_warning));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.orange_warning));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.orange_warning));
            }
        }

        private void applyLeaveRejectedStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.red_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.red_error));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.red_error));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.red_error));
            }
        }

        private void applyTodayStyle() {
            cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.blue_light));
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.blue_info));
            cardView.setStrokeWidth(2);
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.blue_info));
            txtDayNumber.getPaint().setFakeBoldText(true);

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.VISIBLE);
                statusIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.blue_info));
            }
        }

        private void applyFutureStyle() {
            cardView.setCardBackgroundColor(Color.WHITE);
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.gray_default));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }

        private void applyDefaultStyle() {
            cardView.setCardBackgroundColor(Color.WHITE);
            cardView.setStrokeColor(ContextCompat.getColor(context, R.color.gray_default));
            txtDayNumber.setTextColor(ContextCompat.getColor(context, R.color.text_primary));

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }

        void bindEmptyCell() {
            txtDayNumber.setText("");
            cardView.setCardBackgroundColor(Color.TRANSPARENT);
            cardView.setStrokeWidth(0);
            cardView.setClickable(false);

            if (statusIndicator != null) {
                statusIndicator.setVisibility(View.GONE);
            }
        }
    }
}