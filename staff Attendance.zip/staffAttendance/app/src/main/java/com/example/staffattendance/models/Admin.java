package com.example.staffattendance.models;

public class Admin {
    private String userId;
    private String name;
    private String email;
    private String phone;
    private String role = "admin";
    private String status = "active";
    private String companyKey;
    private String companyId;
    private String companyName;
    private long createdAt;

    // Default constructor
    public Admin() {
    }

    // Constructor matching SignUpActivity
    public Admin(String name, String email, String phone, String companyKey,
                 String companyId, String companyName) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.companyKey = companyKey;
        this.companyId = companyId;
        this.companyName = companyName;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCompanyKey() { return companyKey; }
    public void setCompanyKey(String companyKey) { this.companyKey = companyKey; }

    public String getCompanyId() { return companyId; }
    public void setCompanyId(String companyId) { this.companyId = companyId; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    // For backward compatibility
    public String getId() { return userId; }
    public void setId(String id) { this.userId = id; }
}