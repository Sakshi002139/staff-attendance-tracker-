package com.example.staffattendance;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EmployeeProfileFragment extends Fragment {

    private ImageView ivProfilePicture;
    private TextView tvEmployeeName, tvEmployeeRole, tvCompanyName, tvStatus;
    private MaterialButton btnLogout;
    private MaterialCardView btnLeave, btnWorkReport, btnChangePassword;

    private DatabaseReference mDatabase;
    private String companyKey, empId, userName, companyName;
    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_employee_profile, container, false);

        // Initialize SessionManager
        sessionManager = new SessionManager(requireActivity());

        initializeViews(view);
        setupClickListeners();

        mDatabase = FirebaseDatabase.getInstance().getReference();

        // FIXED: Get data from multiple sources with priority
        // 1. First try from Bundle arguments
        Bundle args = getArguments();
        if (args != null) {
            companyKey = args.getString("companyKey");
            empId = args.getString("empId");
            userName = args.getString("userName");
            companyName = args.getString("companyName");
        }

        // 2. Then try from Activity getter methods
        if ((companyKey == null || empId == null) &&
                getActivity() != null &&
                getActivity() instanceof EmployeeDashboardActivity) {
            EmployeeDashboardActivity activity = (EmployeeDashboardActivity) getActivity();
            companyKey = activity.getCompanyKey();
            empId = activity.getEmpId();
            userName = activity.getUserName();
            companyName = activity.getCompanyName();
        }

        // 3. Then try from SessionManager
        if (companyKey == null || empId == null) {
            companyKey = sessionManager.getCompanyKey();
            empId = sessionManager.getEmpId();
            userName = sessionManager.getUserName();
            companyName = sessionManager.getCompanyName();
        }

        // Show error if still null
        if (companyKey == null || empId == null) {
            Toast.makeText(requireContext(), "Missing user information. Please login again.", Toast.LENGTH_LONG).show();

            // Redirect to login after delay
            new android.os.Handler().postDelayed(() -> {
                if (isAdded()) {
                    logout();
                }
            }, 2000);

            return view;
        }

        // Fetch user data
        fetchUserData(companyKey, empId);

        // If we already have companyName from Activity/SessionManager, use it
        if (companyName != null && !companyName.isEmpty()) {
            tvCompanyName.setText(companyName);
        } else {
            fetchCompanyData(companyKey);
        }

        return view;
    }

    private void initializeViews(View view) {
        ivProfilePicture = view.findViewById(R.id.ivProfilePicture);
        tvEmployeeName = view.findViewById(R.id.tvEmployeeName);
        tvEmployeeRole = view.findViewById(R.id.tvEmployeeRole);
        tvCompanyName = view.findViewById(R.id.tvCompanyName);
        tvStatus = view.findViewById(R.id.tvStatus);

        btnLogout = view.findViewById(R.id.btnLogout);
        btnLeave = view.findViewById(R.id.btnLeave);
        btnWorkReport = view.findViewById(R.id.btnWorkReport);
        btnChangePassword = view.findViewById(R.id.btnChangePassword); // Added this line
    }

    private void setupClickListeners() {

        btnLogout.setOnClickListener(v -> logout());

        btnLeave.setOnClickListener(v -> {
            if (companyKey == null || empId == null || userName == null) {
                Toast.makeText(requireContext(), "Cannot apply leave: Missing information", Toast.LENGTH_SHORT).show();
                return;
            }

            // Navigate to leave activity with proper data
            Intent intent = new Intent(requireActivity(), LeaveListActivity.class);
            intent.putExtra("companyKey", companyKey);
            intent.putExtra("empId", empId);
            intent.putExtra("userName", userName);

            // Pass companyName if available
            if (companyName != null) {
                intent.putExtra("companyName", companyName);
            }

            startActivity(intent);

            // Optional: Add activity transition animation
            if (getActivity() != null) {
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        btnWorkReport.setOnClickListener(v -> {
            if (companyKey == null || empId == null) {
                Toast.makeText(requireContext(), "Cannot submit report: Missing information", Toast.LENGTH_SHORT).show();
                return;
            }

            // Navigate to WorkReportActivity
            Intent intent = new Intent(requireActivity(), WorkReportActivity.class);
            intent.putExtra("companyKey", companyKey);
            intent.putExtra("empId", empId);
            intent.putExtra("userName", userName);

            if (companyName != null) {
                intent.putExtra("companyName", companyName);
            }

            startActivity(intent);

            // Optional: Add activity transition animation
            if (getActivity() != null) {
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        btnChangePassword.setOnClickListener(v -> {
            if (companyKey == null || empId == null) {
                Toast.makeText(requireContext(), "Cannot change password: Missing user information", Toast.LENGTH_SHORT).show();
                return;
            }

            // Navigate to ChangePasswordActivity
            Intent intent = new Intent(requireActivity(), ChangePasswordActivity.class);
            intent.putExtra("companyKey", companyKey);
            intent.putExtra("empId", empId);
            intent.putExtra("userName", userName);
            intent.putExtra("companyName", companyName);

            startActivity(intent);

            // Optional: Add activity transition animation
            if (getActivity() != null) {
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
    }

    private void fetchUserData(String companyKey, String empId) {
        DatabaseReference userRef = mDatabase
                .child("Companies")
                .child(companyKey)
                .child("Employees")
                .child(empId);

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;

                if (!snapshot.exists()) {
                    Toast.makeText(requireContext(), "User data not found in database", Toast.LENGTH_SHORT).show();
                    return;
                }

                String name = snapshot.child("name").getValue(String.class);
                String role = snapshot.child("role").getValue(String.class);
                String status = snapshot.child("status").getValue(String.class);
                String email = snapshot.child("email").getValue(String.class);

                if (name == null || name.isEmpty()) name = "Employee Name";
                if (role == null || role.isEmpty()) role = "Employee";
                if (status == null || status.isEmpty()) status = "Active";
                if (email == null) email = "";

                // Update session with complete user data
                sessionManager.saveUserData(name, email);

                // Store userName if not already set
                if (userName == null) {
                    userName = name;
                }

                updateUserUI(name, role, status);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(requireContext(), "Error loading user data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchCompanyData(String companyKey) {
        DatabaseReference companyRef = mDatabase.child("Companies").child(companyKey);

        companyRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;

                if (!snapshot.exists()) {
                    tvCompanyName.setText("Company Not Found");
                    return;
                }

                String fetchedCompanyName = snapshot.child("companyName").getValue(String.class);
                if (fetchedCompanyName != null && !fetchedCompanyName.isEmpty()) {
                    companyName = fetchedCompanyName;
                    tvCompanyName.setText(fetchedCompanyName);
                    // Update session with company name
                    sessionManager.setCompanyName(fetchedCompanyName);
                } else {
                    tvCompanyName.setText("Company Name");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(requireContext(), "Error loading company data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                tvCompanyName.setText("Company");
            }
        });
    }

    private void updateUserUI(String name, String role, String status) {
        tvEmployeeName.setText(name);
        tvEmployeeRole.setText(role);
        tvStatus.setText(status);

        // Set status color based on status
        if ("Active".equalsIgnoreCase(status)) {
            tvStatus.setTextColor(Color.parseColor("#FFFFFFFF")); // Green
        } else if ("Inactive".equalsIgnoreCase(status)) {
            tvStatus.setTextColor(Color.parseColor("#F44336")); // Red
        } else if ("On Leave".equalsIgnoreCase(status)) {
            tvStatus.setTextColor(Color.parseColor("#FF9800")); // Orange
        } else if ("Suspended".equalsIgnoreCase(status)) {
            tvStatus.setTextColor(Color.parseColor("#9C27B0")); // Purple
        } else {
            tvStatus.setTextColor(Color.parseColor("#9E9E9E")); // Gray
        }

        // Create letter avatar
        String firstLetter = name.isEmpty() ? "U" : name.substring(0, 1).toUpperCase();
        int avatarColor = getAvatarColor(name);

        ivProfilePicture.setImageDrawable(
                new LetterAvatarDrawable(firstLetter, avatarColor)
        );
    }

    private int getAvatarColor(String name) {
        // Generate consistent color based on name
        if (name == null || name.isEmpty()) {
            return Color.parseColor("#2196F3"); // Default blue
        }

        // Simple hash to generate color
        int hash = name.hashCode();
        int[] colors = {
                Color.parseColor("#2196F3"), // Blue
                Color.parseColor("#4CAF50"), // Green
                Color.parseColor("#FF9800"), // Orange
                Color.parseColor("#9C27B0"), // Purple
                Color.parseColor("#F44336"), // Red
                Color.parseColor("#009688"), // Teal
                Color.parseColor("#3F51B5"), // Indigo
                Color.parseColor("#E91E63")  // Pink
        };

        int index = Math.abs(hash) % colors.length;
        return colors[index];
    }

    // ✅ PROPER LOGOUT METHOD
    private void logout() {
        if (!isAdded()) return;

        // Show confirmation dialog
        new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    performLogout();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void performLogout() {
        // Clear session
        sessionManager.logout();

        // Sign out from Firebase if using authentication
        try {
            FirebaseAuth.getInstance().signOut();
        } catch (Exception ignored) {}

        // Redirect to login with clear flags
        Intent intent = new Intent(requireActivity(), EmployeeLoginActivity.class);
        intent.putExtra("fromLogout", true);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        // Finish current activity
        if (getActivity() != null) {
            getActivity().finish();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Clean up any listeners if needed
    }

    // LETTER AVATAR DRAWABLE
    private static class LetterAvatarDrawable extends android.graphics.drawable.Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String letter;

        LetterAvatarDrawable(String letter, int color) {
            this.letter = letter;
            paint.setColor(color);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setFakeBoldText(true);
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            RectF bounds = new RectF(getBounds());
            canvas.drawOval(bounds, paint);

            // Calculate text size based on bounds
            float textSize = bounds.height() * 0.4f;
            textPaint.setTextSize(textSize);

            // Center the text
            float x = bounds.centerX();
            float y = bounds.centerY() - ((textPaint.descent() + textPaint.ascent()) / 2);

            canvas.drawText(letter, x, y, textPaint);
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
            textPaint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(@Nullable android.graphics.ColorFilter cf) {
            paint.setColorFilter(cf);
            textPaint.setColorFilter(cf);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}