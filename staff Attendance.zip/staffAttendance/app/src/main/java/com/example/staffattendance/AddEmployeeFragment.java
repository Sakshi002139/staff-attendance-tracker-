package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.EmployeesAdapter;
import com.example.staffattendance.Model.EmployeesModel;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AddEmployeeFragment extends Fragment {

    private static final String TAG = "AddEmployeeFragment";

    private RecyclerView recyclerEmployees;
    private ExtendedFloatingActionButton fabAddEmployee;
    private TextInputEditText edtSearch;

    private EmployeesAdapter adapter;
    private final List<EmployeesModel> employeeList = new ArrayList<>();

    private SessionManager session;
    private String companyKey;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_employee, container, false);

        session = new SessionManager(requireContext());

        // 🔒 Session check
        if (!session.isLoggedIn()) {
            Toast.makeText(requireContext(),
                    "Session expired. Please login again.",
                    Toast.LENGTH_SHORT).show();

            startActivity(new Intent(requireContext(), LoginActivity.class));
            requireActivity().finishAffinity();
            return view;
        }

        // 🧩 Views
        recyclerEmployees = view.findViewById(R.id.recyclerEmployees);
        fabAddEmployee = view.findViewById(R.id.fabAddEmployee);
        edtSearch = view.findViewById(R.id.edtSearch);

        recyclerEmployees.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new EmployeesAdapter(employeeList, requireContext());
        recyclerEmployees.setAdapter(adapter);

        setupSearch();
        setupFab();

        // ✅ LOAD COMPANY KEY FROM SESSION (CORRECT WAY)
        loadCompanyFromSession();

        return view;
    }

    /**
     * ✅ Get companyKey directly from SessionManager
     * ❌ No Firebase query here
     */
    private void loadCompanyFromSession() {
        companyKey = session.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(requireContext(),
                    "Company not found. Please login again.",
                    Toast.LENGTH_LONG).show();

            startActivity(new Intent(requireContext(), LoginActivity.class));
            requireActivity().finishAffinity();
            return;
        }

        Log.d(TAG, "Company key from session: " + companyKey);
        loadEmployees();
    }

    /**
     * 🔍 Search employees
     */
    private void setupSearch() {
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) {
                    adapter.filter(s.toString());
                }
            }
        });
    }

    /**
     * ➕ Add employee FAB
     */
    private void setupFab() {
        fabAddEmployee.setOnClickListener(v -> {
            if (companyKey == null || companyKey.isEmpty()) {
                Toast.makeText(requireContext(),
                        "Company data not loaded",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(requireContext(), AddEmployeeActivity.class);
            intent.putExtra("companyKey", companyKey);
            startActivity(intent);
        });
    }

    /**
     * 📥 Load employees from Firebase
     */
    private void loadEmployees() {
        FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Employees")
                .addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        employeeList.clear();

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            EmployeesModel model = ds.getValue(EmployeesModel.class);
                            if (model != null) {
                                model.setKey(ds.getKey()); // EMP_001
                                employeeList.add(model);
                            }
                        }

                        adapter.updateList(employeeList);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(requireContext(),
                                "Failed to load employees: " + error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
