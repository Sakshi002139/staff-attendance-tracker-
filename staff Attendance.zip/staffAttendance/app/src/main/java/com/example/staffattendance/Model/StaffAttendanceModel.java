package com.example.staffattendance.Model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class StaffAttendanceModel {

    // 🔹 Required for calendar
    private String date;        // yyyy-MM-dd
    private String status;      // EMPTY / PRESENT / ABSENT / HALF_DAY / LATE / TODAY / FUTURE / HOLIDAY / PENDING / LEAVE / LEAVE_PENDING / LEAVE_REJECTED

    // 🔹 Extra details for popup
    private String punchIn;
    private String punchOut;
    private String totalHours;
    private String overtime;
    private String inStatus;
    private String outStatus;

    // 🔹 Photo fields
    private String photoIn;
    private String photoOut;

    // 🔹 Location fields
    private double latIn;
    private double lngIn;
    private double latOut;
    private double lngOut;
    private String locationIn;   // Place name from Geocoder
    private String locationOut;  // Place name from Geocoder
    private String addressIn;    // Full address
    private String addressOut;   // Full address

    // 🔹 Timestamp fields
    private long punchInTimestamp;
    private long punchOutTimestamp;

    // 🔹 Leave fields
    private String leaveReason;
    private String leaveStatus; // PENDING, APPROVED, REJECTED
    private String leaveType;

    // 🔹 Empty constructor (IMPORTANT for Firebase)
    public StaffAttendanceModel() {
        this.status = "EMPTY";
    }

    // 🔹 Basic constructor (for calendar only)
    public StaffAttendanceModel(String date, String status) {
        this.date = date;
        this.status = status != null ? status : "EMPTY";
    }

    // 🔹 Full constructor with all fields
    public StaffAttendanceModel(String date,
                                String status,
                                String punchIn,
                                String punchOut,
                                String totalHours,
                                String overtime,
                                String inStatus,
                                String outStatus,
                                String photoIn,
                                String photoOut,
                                double latIn,
                                double lngIn,
                                double latOut,
                                double lngOut,
                                String locationIn,
                                String locationOut,
                                String addressIn,
                                String addressOut,
                                long punchInTimestamp,
                                long punchOutTimestamp,
                                String leaveReason,
                                String leaveStatus,
                                String leaveType) {

        this.date = date;
        this.status = status != null ? status : "EMPTY";
        this.punchIn = punchIn;
        this.punchOut = punchOut;
        this.totalHours = totalHours;
        this.overtime = overtime;
        this.inStatus = inStatus;
        this.outStatus = outStatus;
        this.photoIn = photoIn;
        this.photoOut = photoOut;
        this.latIn = latIn;
        this.lngIn = lngIn;
        this.latOut = latOut;
        this.lngOut = lngOut;
        this.locationIn = locationIn;
        this.locationOut = locationOut;
        this.addressIn = addressIn;
        this.addressOut = addressOut;
        this.punchInTimestamp = punchInTimestamp;
        this.punchOutTimestamp = punchOutTimestamp;
        this.leaveReason = leaveReason;
        this.leaveStatus = leaveStatus;
        this.leaveType = leaveType;
    }

    // ================= GETTERS =================

    public String getDate() { return date; }
    public String getStatus() { return status != null ? status : "EMPTY"; }
    public String getPunchIn() { return punchIn; }
    public String getPunchOut() { return punchOut; }
    public String getTotalHours() { return totalHours != null ? totalHours : "0h 0m"; }
    public String getOvertime() { return overtime != null ? overtime : "0h 0m"; }
    public String getInStatus() { return inStatus; }
    public String getOutStatus() { return outStatus; }

    // Photo getters
    public String getPhotoIn() { return photoIn; }
    public String getPhotoOut() { return photoOut; }

    // Location getters
    public double getLatIn() { return latIn; }
    public double getLngIn() { return lngIn; }
    public double getLatOut() { return latOut; }
    public double getLngOut() { return lngOut; }
    public String getLocationIn() { return locationIn; }
    public String getLocationOut() { return locationOut; }
    public String getAddressIn() { return addressIn; }
    public String getAddressOut() { return addressOut; }

    // Timestamp getters
    public long getPunchInTimestamp() { return punchInTimestamp; }
    public long getPunchOutTimestamp() { return punchOutTimestamp; }

    // Leave getters
    public String getLeaveReason() { return leaveReason; }
    public String getLeaveStatus() { return leaveStatus; }
    public String getLeaveType() { return leaveType; }

    // ================= SETTERS =================

    public void setDate(String date) { this.date = date; }
    public void setStatus(String status) { this.status = status != null ? status : "EMPTY"; }
    public void setPunchIn(String punchIn) { this.punchIn = punchIn; }
    public void setPunchOut(String punchOut) { this.punchOut = punchOut; }
    public void setTotalHours(String totalHours) { this.totalHours = totalHours; }
    public void setOvertime(String overtime) { this.overtime = overtime; }
    public void setInStatus(String inStatus) { this.inStatus = inStatus; }
    public void setOutStatus(String outStatus) { this.outStatus = outStatus; }

    // Photo setters
    public void setPhotoIn(String photoIn) { this.photoIn = photoIn; }
    public void setPhotoOut(String photoOut) { this.photoOut = photoOut; }

    // Location setters
    public void setLatIn(double latIn) { this.latIn = latIn; }
    public void setLngIn(double lngIn) { this.lngIn = lngIn; }
    public void setLatOut(double latOut) { this.latOut = latOut; }
    public void setLngOut(double lngOut) { this.lngOut = lngOut; }
    public void setLocationIn(String locationIn) { this.locationIn = locationIn; }
    public void setLocationOut(String locationOut) { this.locationOut = locationOut; }
    public void setAddressIn(String addressIn) { this.addressIn = addressIn; }
    public void setAddressOut(String addressOut) { this.addressOut = addressOut; }

    // Timestamp setters
    public void setPunchInTimestamp(long punchInTimestamp) { this.punchInTimestamp = punchInTimestamp; }
    public void setPunchOutTimestamp(long punchOutTimestamp) { this.punchOutTimestamp = punchOutTimestamp; }

    // Leave setters
    public void setLeaveReason(String leaveReason) { this.leaveReason = leaveReason; }
    public void setLeaveStatus(String leaveStatus) { this.leaveStatus = leaveStatus; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    /**
     * Set the day number (DD) part of the date
     * This method updates the day portion of the date field while preserving year and month
     * @param dayNumber The day number as a string (01-31)
     */
    public void setDayNumber(String dayNumber) {
        if (this.date != null && this.date.length() >= 8) {
            // Assuming date format is yyyy-MM-dd
            String yearMonth = this.date.substring(0, 8); // Gets "yyyy-MM-"
            this.date = yearMonth + dayNumber;
        } else {
            // If date is null or invalid, create a new date with just the day
            // You might want to set a default year-month or handle this differently
            this.date = "2026-02-" + dayNumber; // Example default
        }
    }

    // ================= HELPER METHODS =================

    // Helper method to check if date is empty
    public boolean isEmpty() {
        return date == null || date.isEmpty() || "EMPTY".equals(status);
    }

    // Helper method to check if it's a valid date
    public boolean isValidDate() {
        return date != null && date.length() >= 10 && !isEmpty();
    }

    // Helper method to get day number
    public String getDayNumber() {
        if (date != null && date.length() >= 10) {
            return date.substring(8);
        }
        return "";
    }

    // Helper method to get month number
    public String getMonthNumber() {
        if (date != null && date.length() >= 10) {
            return date.substring(5, 7);
        }
        return "";
    }

    // Helper method to get year
    public String getYear() {
        if (date != null && date.length() >= 10) {
            return date.substring(0, 4);
        }
        return "";
    }

    // Check if it's Sunday
    public boolean isSunday() {
        try {
            if (date == null || date.isEmpty()) return false;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date parsedDate = sdf.parse(date);
            Calendar cal = Calendar.getInstance();
            cal.setTime(parsedDate);
            return cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
        } catch (ParseException e) {
            return false;
        }
    }

    // ================= SIMPLIFIED STATUS CHECKERS =================

    public boolean isPresent() {
        return "PRESENT".equalsIgnoreCase(status);
    }

    public boolean isAbsent() {
        return "ABSENT".equalsIgnoreCase(status);
    }

    public boolean isHalfDay() {
        return "HALF_DAY".equalsIgnoreCase(status);
    }

    public boolean isLate() {
        return "LATE".equalsIgnoreCase(status);
    }

    public boolean isToday() {
        return "TODAY".equalsIgnoreCase(status);
    }

    public boolean isHoliday() {
        return "HOLIDAY".equalsIgnoreCase(status) || isSunday();
    }

    public boolean isFuture() {
        return "FUTURE".equalsIgnoreCase(status);
    }

    public boolean isPending() {
        return "PENDING".equalsIgnoreCase(status);
    }

    public boolean isEmptyCell() {
        return "EMPTY".equalsIgnoreCase(status);
    }

    // LEAVE STATUS CHECKERS
    public boolean isLeaveApproved() {
        return ("LEAVE".equalsIgnoreCase(status) && "APPROVED".equalsIgnoreCase(leaveStatus)) ||
                "LEAVE_APPROVED".equalsIgnoreCase(status);
    }

    public boolean isLeavePending() {
        return ("LEAVE".equalsIgnoreCase(status) && "PENDING".equalsIgnoreCase(leaveStatus)) ||
                "LEAVE_PENDING".equalsIgnoreCase(status);
    }

    public boolean isLeaveRejected() {
        return ("LEAVE".equalsIgnoreCase(status) && "REJECTED".equalsIgnoreCase(leaveStatus)) ||
                "LEAVE_REJECTED".equalsIgnoreCase(status);
    }

    public boolean isAnyLeave() {
        return "LEAVE".equalsIgnoreCase(status) ||
                "LEAVE_PENDING".equalsIgnoreCase(status) ||
                "LEAVE_REJECTED".equalsIgnoreCase(status) ||
                "LEAVE_APPROVED".equalsIgnoreCase(status);
    }

    public boolean hasAttendanceData() {
        return punchIn != null && !punchIn.isEmpty() &&
                !"null".equalsIgnoreCase(punchIn);
    }

    public boolean hasLeaveData() {
        return leaveReason != null && !leaveReason.isEmpty() &&
                !"null".equalsIgnoreCase(leaveReason);
    }

    public boolean isWorkingDay() {
        return !isSunday() && !isHoliday() && !isEmptyCell() &&
                !isFuture() && !isAnyLeave();
    }

    public String getDisplayStatus() {
        if (isSunday()) return "HOLIDAY";
        if (isLeaveApproved()) return "LEAVE";
        if (isLeavePending()) return "LEAVE (PENDING)";
        if (isLeaveRejected()) return "LEAVE (REJECTED)";
        return status != null ? status : "PENDING";
    }

    // ================= COLOR METHODS =================

    public String getStatusColor() {
        if (status == null) return "#9E9E9E";

        String upperStatus = status.toUpperCase();
        switch (upperStatus) {
            case "PRESENT":
                return "#4CAF50"; // Green
            case "HALF_DAY":
            case "LATE":
                return "#FF9800"; // Orange
            case "ABSENT":
                return "#F44336"; // Red
            case "LEAVE":
                if ("APPROVED".equalsIgnoreCase(leaveStatus)) {
                    return "#2196F3"; // Blue for approved leave
                } else if ("PENDING".equalsIgnoreCase(leaveStatus)) {
                    return "#FF9800"; // Orange for pending leave
                } else if ("REJECTED".equalsIgnoreCase(leaveStatus)) {
                    return "#F44336"; // Red for rejected leave
                }
                return "#2196F3"; // Default blue for leave
            case "LEAVE_PENDING":
                return "#FF9800"; // Orange
            case "LEAVE_REJECTED":
                return "#F44336"; // Red
            case "LEAVE_APPROVED":
                return "#2196F3"; // Blue
            case "HOLIDAY":
                return "#7F8C8D"; // Gray
            case "TODAY":
                return "#2196F3"; // Blue
            case "FUTURE":
                return "#BDBDBD"; // Light Gray
            default:
                return "#9E9E9E"; // Gray
        }
    }

    public String getBackgroundColor() {
        if (status == null) return "#FFFFFF";

        String upperStatus = status.toUpperCase();
        switch (upperStatus) {
            case "PRESENT":
                return "#E8F5E9"; // Light Green
            case "HALF_DAY":
            case "LATE":
                return "#FFF3E0"; // Light Orange
            case "ABSENT":
                return "#FFEBEE"; // Light Red
            case "LEAVE":
                if ("APPROVED".equalsIgnoreCase(leaveStatus)) {
                    return "#E3F2FD"; // Light Blue
                } else if ("PENDING".equalsIgnoreCase(leaveStatus)) {
                    return "#FFF3E0"; // Light Orange
                } else if ("REJECTED".equalsIgnoreCase(leaveStatus)) {
                    return "#FFEBEE"; // Light Red
                }
                return "#E3F2FD"; // Default light blue
            case "LEAVE_PENDING":
                return "#FFF3E0"; // Light Orange
            case "LEAVE_REJECTED":
                return "#FFEBEE"; // Light Red
            case "LEAVE_APPROVED":
                return "#E3F2FD"; // Light Blue
            case "HOLIDAY":
                return "#F5F5F5"; // Light Gray
            case "TODAY":
                return "#E3F2FD"; // Light Blue
            case "FUTURE":
                return "#FAFAFA"; // Very Light Gray
            default:
                return "#FFFFFF"; // White
        }
    }

    @Override
    public String toString() {
        return "StaffAttendanceModel{" +
                "date='" + date + '\'' +
                ", status='" + status + '\'' +
                ", punchIn='" + punchIn + '\'' +
                ", punchOut='" + punchOut + '\'' +
                ", totalHours='" + totalHours + '\'' +
                ", overtime='" + overtime + '\'' +
                ", inStatus='" + inStatus + '\'' +
                ", outStatus='" + outStatus + '\'' +
                ", leaveReason='" + leaveReason + '\'' +
                ", leaveStatus='" + leaveStatus + '\'' +
                ", leaveType='" + leaveType + '\'' +
                '}';
    }

    // ================= CLEAR METHOD =================

    public void clear() {
        this.punchIn = null;
        this.punchOut = null;
        this.totalHours = "0h 0m";
        this.overtime = "0h 0m";
        this.inStatus = null;
        this.outStatus = null;
        this.leaveReason = null;
        this.leaveStatus = null;
        this.leaveType = null;
    }

    // ================= BUILDER PATTERN =================

    public static class Builder {
        private String date;
        private String status = "EMPTY";
        private String punchIn;
        private String punchOut;
        private String totalHours = "0h 0m";
        private String overtime = "0h 0m";
        private String inStatus;
        private String outStatus;
        private String leaveReason;
        private String leaveStatus;
        private String leaveType;

        public Builder setDate(String date) { this.date = date; return this; }
        public Builder setStatus(String status) { this.status = status; return this; }
        public Builder setPunchIn(String punchIn) { this.punchIn = punchIn; return this; }
        public Builder setPunchOut(String punchOut) { this.punchOut = punchOut; return this; }
        public Builder setTotalHours(String totalHours) { this.totalHours = totalHours; return this; }
        public Builder setOvertime(String overtime) { this.overtime = overtime; return this; }
        public Builder setInStatus(String inStatus) { this.inStatus = inStatus; return this; }
        public Builder setOutStatus(String outStatus) { this.outStatus = outStatus; return this; }
        public Builder setLeaveReason(String leaveReason) { this.leaveReason = leaveReason; return this; }
        public Builder setLeaveStatus(String leaveStatus) { this.leaveStatus = leaveStatus; return this; }
        public Builder setLeaveType(String leaveType) { this.leaveType = leaveType; return this; }

        public StaffAttendanceModel build() {
            return new StaffAttendanceModel(date, status, punchIn, punchOut, totalHours, overtime,
                    inStatus, outStatus, null, null, 0, 0, 0, 0,
                    null, null, null, null, 0, 0, leaveReason, leaveStatus, leaveType);
        }
    }

    // ================= FACTORY METHODS =================

    public static StaffAttendanceModel createEmptyCell() {
        return new StaffAttendanceModel("", "EMPTY");
    }

    public static StaffAttendanceModel createTodayCell(String date) {
        return new StaffAttendanceModel(date, "TODAY");
    }

    public static StaffAttendanceModel createPresentCell(String date, String punchIn, String punchOut) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "PRESENT");
        model.setPunchIn(punchIn);
        model.setPunchOut(punchOut);
        return model;
    }

    public static StaffAttendanceModel createAbsentCell(String date) {
        return new StaffAttendanceModel(date, "ABSENT");
    }

    public static StaffAttendanceModel createHolidayCell(String date) {
        return new StaffAttendanceModel(date, "HOLIDAY");
    }

    public static StaffAttendanceModel createFutureCell(String date) {
        return new StaffAttendanceModel(date, "FUTURE");
    }

    public static StaffAttendanceModel createSundayCell(String date) {
        return new StaffAttendanceModel(date, "HOLIDAY");
    }

    public static StaffAttendanceModel createHalfDayCell(String date, String punchIn, String punchOut) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "HALF_DAY");
        model.setPunchIn(punchIn);
        model.setPunchOut(punchOut);
        return model;
    }

    public static StaffAttendanceModel createLateCell(String date, String punchIn, String punchOut) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "LATE");
        model.setPunchIn(punchIn);
        model.setPunchOut(punchOut);
        return model;
    }

    // Leave cell factory methods
    public static StaffAttendanceModel createLeaveApprovedCell(String date, String leaveReason, String leaveType) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "LEAVE");
        model.setLeaveReason(leaveReason);
        model.setLeaveStatus("APPROVED");
        model.setLeaveType(leaveType);
        return model;
    }

    public static StaffAttendanceModel createLeavePendingCell(String date, String leaveReason, String leaveType) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "LEAVE_PENDING");
        model.setLeaveReason(leaveReason);
        model.setLeaveStatus("PENDING");
        model.setLeaveType(leaveType);
        return model;
    }

    public static StaffAttendanceModel createLeaveRejectedCell(String date, String leaveReason, String leaveType) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "LEAVE_REJECTED");
        model.setLeaveReason(leaveReason);
        model.setLeaveStatus("REJECTED");
        model.setLeaveType(leaveType);
        return model;
    }

    public static StaffAttendanceModel createLeaveApprovedExplicitCell(String date, String leaveReason, String leaveType) {
        StaffAttendanceModel model = new StaffAttendanceModel(date, "LEAVE_APPROVED");
        model.setLeaveReason(leaveReason);
        model.setLeaveStatus("APPROVED");
        model.setLeaveType(leaveType);
        return model;
    }
}