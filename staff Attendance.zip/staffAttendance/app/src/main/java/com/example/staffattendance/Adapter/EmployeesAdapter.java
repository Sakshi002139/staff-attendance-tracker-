package com.example.staffattendance.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.EditEmployeeActivity;
import com.example.staffattendance.Model.EmployeesModel;
import com.example.staffattendance.R;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.List;

public class EmployeesAdapter extends RecyclerView.Adapter<EmployeesAdapter.ViewHolder> {

    private final List<EmployeesModel> list = new ArrayList<>();
    private final List<EmployeesModel> fullList = new ArrayList<>();
    private final Context context;

    public EmployeesAdapter(List<EmployeesModel> data, Context context) {
        this.context = context;
        updateList(data);
    }

    public void updateList(List<EmployeesModel> data) {
        list.clear();
        fullList.clear();
        if (data != null) {
            list.addAll(data);
            fullList.addAll(data);
        }
        notifyDataSetChanged();
    }

    public void filter(String query) {
        list.clear();
        if (query == null || query.trim().isEmpty()) {
            list.addAll(fullList);
        } else {
            String q = query.toLowerCase().trim();
            for (EmployeesModel emp : fullList) {
                boolean matches =
                        (emp.getName() != null && emp.getName().toLowerCase().contains(q)) ||
                                (emp.getEmpId() != null && emp.getEmpId().toLowerCase().contains(q)) ||
                                (emp.getDepartment() != null && emp.getDepartment().toLowerCase().contains(q)) ||
                                (emp.getRole() != null && emp.getRole().toLowerCase().contains(q)) ||
                                (emp.getPhone() != null && emp.getPhone().contains(q)) ||
                                (emp.getEmail() != null && emp.getEmail().toLowerCase().contains(q));
                if (matches) list.add(emp);
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_employee, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        EmployeesModel model = list.get(position);

        holder.txtName.setText(model.getName() != null ? model.getName() : "Unknown");
        holder.txtId.setText(model.getEmpId() != null ? model.getEmpId() : "N/A");
        holder.txtRole.setText(model.getRole() != null ? model.getRole() : "Not Specified");
        holder.txtDepartment.setText(model.getDepartment() != null ? model.getDepartment() : "General");
        holder.txtJoinDate.setText(model.getJoiningDate() != null ? model.getJoiningDate() : "Not Set");
        holder.txtPhone.setText(model.getPhone() != null ? model.getPhone() : "");

        // Status chip
        String status = model.getStatus() != null ? model.getStatus() : "active";
        holder.chipStatus.setText(status.toUpperCase());
        switch (status.toLowerCase()) {
            case "active":
                holder.chipStatus.setChipBackgroundColorResource(R.color.green);
                break;
            case "inactive":
                holder.chipStatus.setChipBackgroundColorResource(R.color.red);
                break;
            case "on_leave":
                holder.chipStatus.setChipBackgroundColorResource(R.color.orange);
                break;
            default:
                holder.chipStatus.setChipBackgroundColorResource(R.color.gray_xdark);
                break;
        }

        // Profile image
        if (model.getProfileImageBase64() != null && !model.getProfileImageBase64().isEmpty()) {
            try {
                byte[] decoded = Base64.decode(model.getProfileImageBase64(), Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                holder.imgProfile.setImageBitmap(bitmap);
                holder.imgProfile.setOnClickListener(v -> showImageDialog(bitmap));
            } catch (Exception e) {
                Log.e("EmployeesAdapter", "Image error", e);
                holder.imgProfile.setImageResource(R.drawable.ic_profile);
            }
        } else {
            holder.imgProfile.setImageResource(R.drawable.ic_profile);
        }

        // Menu (EDIT / DELETE)
        holder.imgMenu.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(context, v);
            popup.inflate(R.menu.employee_menu);
            popup.setOnMenuItemClickListener(item -> {
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return false;

                EmployeesModel selected = list.get(pos);

                if (item.getItemId() == R.id.action_edit) {
                    Intent intent = new Intent(context, EditEmployeeActivity.class);
                    intent.putExtra("companyKey", selected.getCompanyKey());
                    intent.putExtra("employeeKey", selected.getKey());
                    context.startActivity(intent);
                    return true;
                } else if (item.getItemId() == R.id.action_delete) {
                    showDeleteConfirmation(selected, pos);
                    return true;
                }
                return false;
            });
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private void showImageDialog(Bitmap bitmap) {
        ImageView img = new ImageView(context);
        img.setImageBitmap(bitmap);
        img.setAdjustViewBounds(true);
        new AlertDialog.Builder(context)
                .setView(img)
                .setPositiveButton("Close", null)
                .show();
    }

    private void showDeleteConfirmation(EmployeesModel employee, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Employee")
                .setMessage("Delete " + employee.getName() + "?")
                .setPositiveButton("Delete", (d, w) -> {
                    if (context instanceof OnEmployeeDeleteListener) {
                        ((OnEmployeeDeleteListener) context)
                                .onEmployeeDelete(employee, position);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    public interface OnEmployeeDeleteListener {
        void onEmployeeDelete(EmployeesModel employee, int position);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtName, txtId, txtRole, txtDepartment, txtPhone, txtJoinDate;
        Chip chipStatus;
        ShapeableImageView imgProfile, imgMenu;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtEmpName);
            txtId = itemView.findViewById(R.id.txtEmpId);
            txtRole = itemView.findViewById(R.id.txtEmpRole);
            txtDepartment = itemView.findViewById(R.id.txtEmpDepartment);
            txtPhone = itemView.findViewById(R.id.txtEmpPhone);
            txtJoinDate = itemView.findViewById(R.id.txtEmpJoinDate);
            chipStatus = itemView.findViewById(R.id.chipStatus);
            imgProfile = itemView.findViewById(R.id.imgProfile);
            imgMenu = itemView.findViewById(R.id.imgMenu);
        }
    }
}
