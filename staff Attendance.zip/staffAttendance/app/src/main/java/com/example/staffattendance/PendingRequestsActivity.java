package com.example.staffattendance;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.PendingRequestsAdapter;
import com.example.staffattendance.Model.LeaveItem;
import com.example.staffattendance.Model.Employee;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PendingRequestsActivity extends AppCompatActivity {

    private MaterialToolbar toolbar;
    private TabLayout tabLayout;
    private RecyclerView recyclerView;
    private EditText etSearch;
    private ImageView btnFilter;
    private LinearLayout layoutEmptyState;
    private ProgressBar progressBar;
    private FloatingActionButton fabRefresh;
    private ChipGroup chipGroupFilters;
    private TextView tvItemCount, tvEmptyTitle, tvEmptyMessage;

    // Stats TextViews
    private TextView tvTotalRequests, tvPendingCount, tvThisWeek;

    private PendingRequestsAdapter adapter;
    private List<LeaveItem> requestList = new ArrayList<>();
    private List<LeaveItem> filteredList = new ArrayList<>();

    private DatabaseReference leavesRef, employeesRef, attendanceRef;
    private SessionManager sessionManager;

    private String companyKey;
    private int currentTabPosition = 0; // 0=Pending, 1=Approved, 2=Rejected
    private Map<String, Employee> employeeCache = new HashMap<>();
    private String currentChipFilter = "All";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_requests);

        initViews();
        setupToolbar();
        setupTabLayout();
        setupChipFilters();
        setupRecyclerView();
        setupSearch();
        setupClickListeners();

        sessionManager = new SessionManager(this);
        companyKey = sessionManager.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        // Initialize Firebase references
        leavesRef = FirebaseDatabase.getInstance().getReference("Companies")
                .child(companyKey).child("Leaves");

        employeesRef = FirebaseDatabase.getInstance().getReference("Companies")
                .child(companyKey).child("Employees");

        attendanceRef = FirebaseDatabase.getInstance().getReference("Companies")
                .child(companyKey).child("Attendance");

        loadLeaveRequests();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        tabLayout = findViewById(R.id.tabLayout);
        recyclerView = findViewById(R.id.recyclerViewRequests);
        etSearch = findViewById(R.id.etSearch);
        btnFilter = findViewById(R.id.btnFilter);
        layoutEmptyState = findViewById(R.id.layoutEmptyState);
        progressBar = findViewById(R.id.progressBar);
        fabRefresh = findViewById(R.id.fabRefresh);
        chipGroupFilters = findViewById(R.id.chipGroupFilters);
        tvItemCount = findViewById(R.id.tvItemCount);
        tvEmptyTitle = findViewById(R.id.tvEmptyTitle);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);

        tvTotalRequests = findViewById(R.id.tvTotalRequests);
        tvPendingCount = findViewById(R.id.tvPendingCount);
        tvThisWeek = findViewById(R.id.tvThisWeek);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Leave Requests");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupTabLayout() {
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentTabPosition = tab.getPosition();
                updateSectionTitle();
                filterRequests();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void setupChipFilters() {
        chipGroupFilters.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (!checkedIds.isEmpty()) {
                Chip chip = findViewById(checkedIds.get(0));
                currentChipFilter = chip.getText().toString();
                filterRequests();
            }
        });
    }

    private void setupRecyclerView() {
        adapter = new PendingRequestsAdapter(filteredList, employeeCache, new PendingRequestsAdapter.OnRequestActionListener() {
            @Override
            public void onApprove(LeaveItem request) {
                showApproveDialog(request);
            }

            @Override
            public void onReject(LeaveItem request) {
                showRejectDialog(request);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterRequests();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void setupClickListeners() {
        fabRefresh.setOnClickListener(v -> {
            progressBar.setVisibility(View.VISIBLE);
            loadLeaveRequests();
        });

        btnFilter.setOnClickListener(v -> {
            // Toggle chip group visibility or show filter options
            if (chipGroupFilters.getVisibility() == View.VISIBLE) {
                chipGroupFilters.setVisibility(View.GONE);
            } else {
                chipGroupFilters.setVisibility(View.VISIBLE);
            }
        });
    }

    private void loadLeaveRequests() {
        progressBar.setVisibility(View.VISIBLE);
        requestList.clear();
        filteredList.clear();
        employeeCache.clear();

        leavesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int totalRequests = 0;
                int pendingCount = 0;
                int thisWeekCount = 0;

                Calendar calendar = Calendar.getInstance();
                long oneWeekAgo = calendar.getTimeInMillis() - (7L * 24 * 60 * 60 * 1000);

                for (DataSnapshot employeeSnapshot : snapshot.getChildren()) {
                    String empId = employeeSnapshot.getKey();

                    for (DataSnapshot leaveSnapshot : employeeSnapshot.getChildren()) {
                        LeaveItem request = leaveSnapshot.getValue(LeaveItem.class);
                        if (request != null) {
                            request.setLeaveId(leaveSnapshot.getKey());
                            request.setEmpId(empId);
                            request.setCompanyKey(companyKey);

                            requestList.add(request);
                            totalRequests++;

                            if ("PENDING".equalsIgnoreCase(request.getStatus())) {
                                pendingCount++;
                            }

                            if (request.getTimestamp() >= oneWeekAgo) {
                                thisWeekCount++;
                            }
                        }
                    }
                }

                // Sort by timestamp (newest first)
                Collections.sort(requestList, (a, b) ->
                        Long.compare(b.getTimestamp(), a.getTimestamp()));

                // Load all employee details
                loadAllEmployeeDetails();

                updateStats(totalRequests, pendingCount, thisWeekCount);
                filterRequests();
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                showEmptyState("Error Loading Data", "Failed to load requests: " + error.getMessage());
                Toast.makeText(PendingRequestsActivity.this,
                        "Error loading requests: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadAllEmployeeDetails() {
        employeesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot empSnapshot : snapshot.getChildren()) {
                    Employee employee = empSnapshot.getValue(Employee.class);
                    if (employee != null) {
                        employee.setEmpId(empSnapshot.getKey());
                        employeeCache.put(empSnapshot.getKey(), employee);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error silently
            }
        });
    }

    private void filterRequests() {
        filteredList.clear();

        String statusFilter;
        switch (currentTabPosition) {
            case 0:
                statusFilter = "PENDING";
                break;
            case 1:
                statusFilter = "APPROVED";
                break;
            case 2:
                statusFilter = "REJECTED";
                break;
            default:
                statusFilter = "PENDING";
        }

        String searchQuery = etSearch.getText().toString().toLowerCase().trim();
        Calendar calendar = Calendar.getInstance();

        for (LeaveItem request : requestList) {
            // Filter by status (tab)
            if (!statusFilter.equalsIgnoreCase(request.getStatus())) {
                continue;
            }

            // Filter by chip (time period)
            if (!filterByChip(request, calendar)) {
                continue;
            }

            // Filter by search query
            if (!searchQuery.isEmpty()) {
                Employee emp = employeeCache.get(request.getEmpId());
                if (emp == null || emp.getName() == null ||
                        !emp.getName().toLowerCase().contains(searchQuery)) {
                    continue;
                }
            }

            filteredList.add(request);
        }

        adapter.notifyDataSetChanged();
        updateEmptyState();
        updateItemCount();
    }

    private boolean filterByChip(LeaveItem request, Calendar calendar) {
        long now = System.currentTimeMillis();
        long requestTime = request.getTimestamp();

        switch (currentChipFilter) {
            case "Today":
                calendar.setTimeInMillis(now);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                long startOfDay = calendar.getTimeInMillis();
                return requestTime >= startOfDay;

            case "This Week":
                calendar.setTimeInMillis(now);
                calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                long startOfWeek = calendar.getTimeInMillis();
                return requestTime >= startOfWeek;

            case "This Month":
                calendar.setTimeInMillis(now);
                calendar.set(Calendar.DAY_OF_MONTH, 1);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                long startOfMonth = calendar.getTimeInMillis();
                return requestTime >= startOfMonth;

            case "All":
            default:
                return true;
        }
    }

    private void updateStats(int total, int pending, int thisWeek) {
        tvTotalRequests.setText(String.valueOf(total));
        tvPendingCount.setText(String.valueOf(pending));
        tvThisWeek.setText(String.valueOf(thisWeek));
    }

    private void updateEmptyState() {
        if (filteredList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            layoutEmptyState.setVisibility(View.VISIBLE);

            String statusText;
            switch (currentTabPosition) {
                case 0: statusText = "pending"; break;
                case 1: statusText = "approved"; break;
                case 2: statusText = "rejected"; break;
                default: statusText = "pending";
            }

            tvEmptyTitle.setText("No " + statusText.substring(0, 1).toUpperCase() +
                    statusText.substring(1) + " Requests");
            tvEmptyMessage.setText("There are no " + statusText +
                    " leave requests to display" +
                    (currentChipFilter.equals("All") ? "" : " for " + currentChipFilter));
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            layoutEmptyState.setVisibility(View.GONE);
        }
    }

    private void updateSectionTitle() {
        TextView sectionTitle = findViewById(R.id.sectionTitle);
        if (sectionTitle != null) {
            switch (currentTabPosition) {
                case 0:
                    sectionTitle.setText("Pending Requests");
                    break;
                case 1:
                    sectionTitle.setText("Approved Requests");
                    break;
                case 2:
                    sectionTitle.setText("Rejected Requests");
                    break;
            }
        }
    }

    private void updateItemCount() {
        if (tvItemCount != null) {
            tvItemCount.setText(filteredList.size() + " items");
            tvItemCount.setVisibility(View.VISIBLE);
        }
    }

    private void showEmptyState(String title, String message) {
        recyclerView.setVisibility(View.GONE);
        layoutEmptyState.setVisibility(View.VISIBLE);
        tvEmptyTitle.setText(title);
        tvEmptyMessage.setText(message);
    }

    private void showApproveDialog(LeaveItem request) {
        Employee emp = employeeCache.get(request.getEmpId());
        String empName = emp != null ? emp.getName() : "this employee";

        new AlertDialog.Builder(this)
                .setTitle("Approve Leave Request")
                .setMessage("Are you sure you want to approve the leave request for " + empName + "?")
                .setPositiveButton("Approve", (dialog, which) -> approveRequest(request))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showRejectDialog(LeaveItem request) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_reject_reason, null);
        builder.setView(dialogView);

        EditText etReason = dialogView.findViewById(R.id.etRejectReason);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);
        Button btnConfirm = dialogView.findViewById(R.id.btnConfirmReject);

        AlertDialog dialog = builder.create();
        dialog.show();

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnConfirm.setOnClickListener(v -> {
            String reason = etReason.getText().toString().trim();
            if (reason.isEmpty()) {
                etReason.setError("Please enter a reason");
                return;
            }
            rejectRequest(request, reason);
            dialog.dismiss();
        });
    }

    private void approveRequest(LeaveItem request) {
        if ("APPROVED".equalsIgnoreCase(request.getStatus())) {
            Toast.makeText(this, "Request already approved", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "APPROVED");
        updates.put("approvedAt", System.currentTimeMillis());
        updates.put("approvedBy", sessionManager.getEmpId());

        DatabaseReference requestRef = leavesRef.child(request.getEmpId())
                .child(request.getLeaveId());

        requestRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    updateAttendanceStatus(request, "APPROVED", null);
                    request.setStatus("APPROVED");
                    Toast.makeText(this, "Leave request approved successfully", Toast.LENGTH_SHORT).show();
                    loadLeaveRequests();
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Failed to approve: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void rejectRequest(LeaveItem request, String reason) {
        if ("REJECTED".equalsIgnoreCase(request.getStatus())) {
            Toast.makeText(this, "Request already rejected", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "REJECTED");
        updates.put("rejectedAt", System.currentTimeMillis());
        updates.put("rejectedBy", sessionManager.getEmpId());
        updates.put("rejectionReason", reason);

        DatabaseReference requestRef = leavesRef.child(request.getEmpId())
                .child(request.getLeaveId());

        requestRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    updateAttendanceStatus(request, "REJECTED", reason);
                    request.setStatus("REJECTED");
                    Toast.makeText(this, "Leave request rejected", Toast.LENGTH_SHORT).show();
                    loadLeaveRequests();
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Failed to reject: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void updateAttendanceStatus(LeaveItem request, String status, String rejectionReason) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

            String startDateStr = request.getStartDate();
            String endDateStr = request.getEndDate();

            if (startDateStr == null || endDateStr == null || startDateStr.isEmpty() || endDateStr.isEmpty()) {
                progressBar.setVisibility(View.GONE);
                return;
            }

            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);

            List<DatabaseReference> updateRefs = new ArrayList<>();

            while (!calendar.getTime().after(endDate)) {
                String currentDate = sdf.format(calendar.getTime());

                DatabaseReference dateRef = attendanceRef
                        .child(request.getEmpId())
                        .child(currentDate);

                updateRefs.add(dateRef);

                if ("APPROVED".equals(status)) {
                    dateRef.child("status").setValue("LEAVE");
                    dateRef.child("leaveStatus").setValue("APPROVED");
                    dateRef.child("leaveType").setValue(request.getLeaveType());
                    dateRef.child("leaveReason").setValue(request.getReason());
                } else {
                    dateRef.child("status").setValue(null);
                    dateRef.child("leaveStatus").setValue("REJECTED");
                    dateRef.child("leaveReason").setValue(rejectionReason);
                    dateRef.child("leaveType").setValue(null);
                }

                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }

            progressBar.setVisibility(View.GONE);

        } catch (Exception e) {
            e.printStackTrace();
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}