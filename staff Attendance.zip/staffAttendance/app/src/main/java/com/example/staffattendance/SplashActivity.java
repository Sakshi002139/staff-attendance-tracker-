package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.staffattendance.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    // Splash screen duration (milliseconds)
    private static final long SPLASH_DELAY = 1200; // 1.2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Use your layout
        setContentView(R.layout.activity_splash);

        SessionManager session = new SessionManager(this);

        // Delay using Handler to avoid freezing the UI
        new Handler(Looper.getMainLooper()).postDelayed(() -> {

            if (session.isLoggedIn()) {
                // Get role: "admin" or "employee"
                String userRole = session.getUserRole();

                if (userRole != null && userRole.toLowerCase().contains("admin")) {
                    // Redirect to Admin Dashboard
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                } else {
                    // Redirect to Employee Dashboard
                    startActivity(new Intent(SplashActivity.this, EmployeeDashboardActivity.class));
                }

            } else {
                // User not logged in → choose login screen
                startActivity(new Intent(SplashActivity.this,LoginActivity.class));
            }

            // Close SplashActivity
            finish();

        }, SPLASH_DELAY);
    }
}
