package com.example.staffattendance.Model;

public class AttendanceDayModel {

    // ---------- CALENDAR INFO ----------
    public int day;                // 1 – 31
    public String status;           // PRESENT / HALF_DAY / ABSENT

    public boolean isSunday;        // for gray color
    public boolean isFuture;        // for gray color

    // ---------- PUNCH IN ----------
    public String punchInTime;      // "09:23 AM"
    public String punchInAddress;   // Address text
    public String punchInImage;     // Image URI / URL

    // ---------- PUNCH OUT ----------
    public String punchOutTime;     // "06:48 PM"
    public String punchOutAddress;  // Address text
    public String punchOutImage;    // Image URI / URL

    // ---------- REQUIRED EMPTY CONSTRUCTOR ----------
    public AttendanceDayModel() {
        // Firebase needs this
    }

    // ---------- OPTIONAL CONSTRUCTOR ----------
    public AttendanceDayModel(
            int day,
            String status,
            boolean isSunday,
            boolean isFuture,
            String punchInTime,
            String punchInAddress,
            String punchInImage,
            String punchOutTime,
            String punchOutAddress,
            String punchOutImage
    ) {
        this.day = day;
        this.status = status;
        this.isSunday = isSunday;
        this.isFuture = isFuture;
        this.punchInTime = punchInTime;
        this.punchInAddress = punchInAddress;
        this.punchInImage = punchInImage;
        this.punchOutTime = punchOutTime;
        this.punchOutAddress = punchOutAddress;
        this.punchOutImage = punchOutImage;
    }
}
