package com.example.staffattendance;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Patterns;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class AddEmployeeActivity extends AppCompatActivity {

    private static final int IMAGE_REQUEST = 101;

    private ShapeableImageView imgProfile;
    private MaterialButton btnChooseImage, btnAddEmployee;
    private TextInputEditText etName, etEmail, etPhone, etRole, etJoiningDate, etAddress;

    private String imageBase64 = "";
    private DatabaseReference rootRef;
    private String companyKey;
    private String companyName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);

        rootRef = FirebaseDatabase.getInstance().getReference();

        companyKey = getIntent().getStringExtra("companyKey");

        if (companyKey == null || companyKey.isEmpty()) {
            Toast.makeText(this, "Company not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        initListeners();
        fetchCompanyBasicInfo();
    }

    private void initViews() {
        imgProfile = findViewById(R.id.imgProfile);
        btnChooseImage = findViewById(R.id.btnChooseImage);
        btnAddEmployee = findViewById(R.id.btnAddEmployee);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etRole = findViewById(R.id.etRole);
        etJoiningDate = findViewById(R.id.etJoiningDate);
        etAddress = findViewById(R.id.etAddress);
    }

    private void initListeners() {
        btnChooseImage.setOnClickListener(v -> chooseImage());
        btnAddEmployee.setOnClickListener(v -> saveEmployee());
        etJoiningDate.setOnClickListener(v -> showDatePicker());
    }

    /** Fetch company name & ensure lastEmployeeNo exists */
    private void fetchCompanyBasicInfo() {
        rootRef.child("Companies").child(companyKey)
                .get()
                .addOnSuccessListener(snapshot -> {
                    companyName = snapshot.child("companyName")
                            .getValue(String.class);

                    if (companyName == null) {
                        companyName = "Unknown Company";
                    }

                    if (!snapshot.hasChild("lastEmployeeNo")) {
                        rootRef.child("Companies")
                                .child(companyKey)
                                .child("lastEmployeeNo")
                                .setValue(0);
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this,
                                "Failed to load company data",
                                Toast.LENGTH_SHORT).show());
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            try {
                Uri uri = data.getData();
                Bitmap bitmap = MediaStore.Images.Media
                        .getBitmap(getContentResolver(), uri);

                imgProfile.setImageBitmap(bitmap);
                imageBase64 = bitmapToBase64(bitmap);

            } catch (Exception e) {
                Toast.makeText(this,
                        "Failed to load image",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String bitmapToBase64(Bitmap bitmap) {
        if (bitmap == null) return "";

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 30, baos);
        return Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this,
                (v, y, m, d) ->
                        etJoiningDate.setText(d + "/" + (m + 1) + "/" + y),
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH))
                .show();
    }

    private void saveEmployee() {

        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String role = etRole.getText().toString().trim();
        String joiningDate = etJoiningDate.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        // 🔒 Validation
        if (name.length() < 3) {
            etName.setError("Enter valid name");
            return;
        }

        if (!phone.matches("^[6-9]\\d{9}$")) {
            etPhone.setError("Enter valid phone");
            return;
        }

        if (!email.isEmpty() &&
                !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Invalid email");
            return;
        }

        btnAddEmployee.setEnabled(false);

        DatabaseReference companyRef =
                rootRef.child("Companies").child(companyKey);

        companyRef.child("lastEmployeeNo")
                .get()
                .addOnSuccessListener(snap -> {

                    int lastNo = snap.exists() && snap.getValue() != null
                            ? snap.getValue(Integer.class)
                            : 0;

                    int newNo = lastNo + 1;
                    String empId = "EMP_" + String.format("%03d", newNo);
                    String defaultPassword = "1234";

                    Map<String, Object> emp = new HashMap<>();
                    emp.put("empId", empId);
                    emp.put("name", name);
                    emp.put("email", email);
                    emp.put("phone", phone);
                    emp.put("role", role);
                    emp.put("joiningDate", joiningDate);
                    emp.put("address", address);
                    emp.put("companyName", companyName);
                    emp.put("profileImageBase64", imageBase64);
                    emp.put("password", defaultPassword);
                    emp.put("status", "active");
                    emp.put("firstLogin", true);

                    Map<String, Object> updates = new HashMap<>();
                    updates.put("Companies/" + companyKey + "/Employees/" + empId, emp);
                    updates.put("Companies/" + companyKey + "/lastEmployeeNo", newNo);

                    rootRef.updateChildren(updates)
                            .addOnSuccessListener(v ->
                                    showSuccessDialog(empId, defaultPassword))
                            .addOnFailureListener(e -> {
                                btnAddEmployee.setEnabled(true);
                                Toast.makeText(this,
                                        "Failed to add employee",
                                        Toast.LENGTH_LONG).show();
                            });
                })
                .addOnFailureListener(e -> {
                    btnAddEmployee.setEnabled(true);
                    Toast.makeText(this,
                            "Error generating employee ID",
                            Toast.LENGTH_LONG).show();
                });
    }

    private void showSuccessDialog(String empId, String password) {
        new AlertDialog.Builder(this)
                .setTitle("Employee Created")
                .setMessage(
                        "Employee ID: " + empId +
                                "\nPassword: " + password +
                                "\n\nEmployee must change password after first login")
                .setCancelable(false)
                .setPositiveButton("OK", (d, w) -> finish())
                .show();
    }
}
