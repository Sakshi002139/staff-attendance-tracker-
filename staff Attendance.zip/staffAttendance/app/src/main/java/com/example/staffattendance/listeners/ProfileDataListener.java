package com.example.staffattendance.listeners;

import com.example.staffattendance.models.Admin;
import com.example.staffattendance.models.Company;

public interface ProfileDataListener {
    void onAdminDataLoaded(Admin admin);
    void onCompanyDataLoaded(Company company);
    void onEmployeeCountLoaded(int count);
    void onError(String message);
}