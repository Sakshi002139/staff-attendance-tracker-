package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.staffattendance.utils.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    private TextInputEditText etAdminEmail, etAdminPassword;
    private MaterialButton btnAdminLogin;
    private ProgressBar progressBar;
    private TextView tvForgotPassword, tvSignUp, switchToEmployee;
    private DatabaseReference databaseRef;
    private FirebaseAuth firebaseAuth;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        databaseRef = FirebaseDatabase.getInstance().getReference();

        // Initialize SessionManager
        sessionManager = new SessionManager(this);

        // Check if already logged in as admin
        if (sessionManager.isLoggedIn() && sessionManager.isAdmin()) {
            openAdminDashboard();
            return;
        }

        // Check if user is already signed in via Firebase Auth
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        if (currentUser != null) {
            // User is signed in with Firebase Auth, check if admin in database
            checkIfAdminInDatabase(currentUser.getEmail());
            return;
        }

        // Initialize views
        etAdminEmail = findViewById(R.id.etAdminEmail);
        etAdminPassword = findViewById(R.id.etAdminPassword);
        btnAdminLogin = findViewById(R.id.btnAdminLogin);
        progressBar = findViewById(R.id.progressBar);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvSignUp = findViewById(R.id.tvSignUp);
        switchToEmployee = findViewById(R.id.switchToEmployee);

        // Auto-fill for testing
        etAdminEmail.setText("sakshirajput03003@gmail.com");

        // Set click listeners
        btnAdminLogin.setOnClickListener(v -> loginAdmin());

        tvForgotPassword.setOnClickListener(v -> {
            String email = etAdminEmail.getText().toString().trim();
            if (TextUtils.isEmpty(email)) {
                etAdminEmail.setError("Enter email to reset password");
                return;
            }
            resetPassword(email);
        });

        tvSignUp.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
        });

        switchToEmployee.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, EmployeeLoginActivity.class));
            finish();
        });
    }

    private void loginAdmin() {
        String email = etAdminEmail.getText().toString().trim();
        String password = etAdminPassword.getText().toString().trim();

        Log.d(TAG, "Login attempt - Email: " + email);

        // Validation
        if (TextUtils.isEmpty(email)) {
            etAdminEmail.setError("Email is required");
            etAdminEmail.requestFocus();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etAdminEmail.setError("Enter a valid email");
            etAdminEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etAdminPassword.setError("Password is required");
            etAdminPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            etAdminPassword.setError("Password must be at least 6 characters");
            etAdminPassword.requestFocus();
            return;
        }

        // Show progress and disable button
        progressBar.setVisibility(View.VISIBLE);
        btnAdminLogin.setEnabled(false);
        btnAdminLogin.setText("Logging in...");

        // Step 1: Authenticate with Firebase Auth
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Firebase Authentication successful
                        Log.d(TAG, "Firebase Auth successful");

                        // Step 2: Check if user is admin in database
                        checkIfAdminInDatabase(email);
                    } else {
                        // Firebase Authentication failed
                        progressBar.setVisibility(View.GONE);
                        btnAdminLogin.setEnabled(true);
                        btnAdminLogin.setText("LOGIN");

                        String errorMessage = "Authentication failed";
                        if (task.getException() != null) {
                            errorMessage = task.getException().getMessage();
                        }

                        Log.e(TAG, "Firebase Auth failed: " + errorMessage);

                        // Show specific error messages
                        if (errorMessage.contains("no user record")) {
                            Toast.makeText(LoginActivity.this,
                                    "Account not found. Please sign up first.",
                                    Toast.LENGTH_LONG).show();
                        } else if (errorMessage.contains("password is invalid")) {
                            etAdminPassword.setError("Invalid password");
                            etAdminPassword.requestFocus();
                            Toast.makeText(LoginActivity.this,
                                    "Invalid password. Please try again.",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(LoginActivity.this,
                                    "Login failed: " + errorMessage,
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void checkIfAdminInDatabase(String email) {
        Log.d(TAG, "Checking if " + email + " is admin in database");

        // Search in all companies for admin with this email
        databaseRef.child("Companies")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot companiesSnapshot) {
                        boolean adminFound = false;

                        for (DataSnapshot companySnapshot : companiesSnapshot.getChildren()) {
                            String companyKey = companySnapshot.getKey();
                            DataSnapshot adminsSnapshot = companySnapshot.child("Admins");

                            // Check all admins in this company
                            for (DataSnapshot adminSnapshot : adminsSnapshot.getChildren()) {
                                String adminEmail = adminSnapshot.child("email").getValue(String.class);

                                if (adminEmail != null && adminEmail.equalsIgnoreCase(email)) {
                                    adminFound = true;

                                    // Found the admin in database
                                    String adminName = adminSnapshot.child("name").getValue(String.class);
                                    String adminPhone = adminSnapshot.getKey(); // Phone is the key
                                    String companyName = companySnapshot.child("companyName").getValue(String.class);

                                    Log.d(TAG, "Admin found in database: " + adminName + ", Company: " + companyName);

                                    // Save session and open dashboard
                                    saveSessionAndOpenDashboard(companyKey, email, adminName, adminPhone, companyName);
                                    return;
                                }
                            }
                        }

                        // If admin not found in any company
                        if (!adminFound) {
                            runOnUiThread(() -> {
                                progressBar.setVisibility(View.GONE);
                                btnAdminLogin.setEnabled(true);
                                btnAdminLogin.setText("LOGIN");

                                // Sign out from Firebase Auth since not an admin
                                firebaseAuth.signOut();

                                Toast.makeText(LoginActivity.this,
                                        "You are not registered as an admin. Please sign up first.",
                                        Toast.LENGTH_LONG).show();
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            btnAdminLogin.setEnabled(true);
                            btnAdminLogin.setText("LOGIN");

                            Log.e(TAG, "Database error: " + error.getMessage());
                            Toast.makeText(LoginActivity.this,
                                    "Error checking admin status: " + error.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        });
                    }
                });
    }

    private void saveSessionAndOpenDashboard(String companyKey, String email, String name,
                                             String phone, String companyName) {
        runOnUiThread(() -> {
            // Save session using SessionManager
            sessionManager.createLoginSession(
                    email,           // user email
                    "admin",         // role
                    companyKey,      // company key
                    "",              // empId (empty for admin)
                    companyName,     // company name
                    name             // user name
            );

            Log.d(TAG, "Session saved - Email: " + email + ", Company: " + companyKey);

            // Open admin dashboard
            openAdminDashboard();
        });
    }

    private void resetPassword(String email) {
        progressBar.setVisibility(View.VISIBLE);

        firebaseAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    progressBar.setVisibility(View.GONE);

                    if (task.isSuccessful()) {
                        Toast.makeText(LoginActivity.this,
                                "Password reset email sent to " + email,
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(LoginActivity.this,
                                "Failed to send reset email: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void openAdminDashboard() {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            btnAdminLogin.setEnabled(true);
            btnAdminLogin.setText("LOGIN");

            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();

            Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reset button state
        if (btnAdminLogin != null) {
            btnAdminLogin.setEnabled(true);
            btnAdminLogin.setText("LOGIN");
        }
        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }
    }
}