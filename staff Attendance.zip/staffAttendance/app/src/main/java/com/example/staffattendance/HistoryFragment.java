package com.example.staffattendance;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.HistoryAdapter;
import com.example.staffattendance.Model.HistoryModel;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class HistoryFragment extends Fragment {

    private static final String TAG = "HistoryFragment";

    // UI Components
    private RecyclerView recyclerHistory;
    private LinearLayout emptyState;
    private EditText etSearch;
    private TabLayout tabLayout;

    // Data
    private HistoryAdapter adapter;
    private final ArrayList<HistoryModel> allRecords = new ArrayList<>();
    private final ArrayList<HistoryModel> filteredList = new ArrayList<>();

    // Firebase
    private DatabaseReference attendanceRef;
    private DatabaseReference leavesRef;
    private DatabaseReference employeesRef;
    private ValueEventListener attendanceListener;
    private ValueEventListener leavesListener;
    private ValueEventListener employeesListener;

    // Session
    private SessionManager sessionManager;
    private String companyKey;

    // Filters
    private String currentTab = "All";
    private String searchQuery = "";

    // Store employee details
    private final Map<String, Map<String, String>> employeeDetailsMap = new HashMap<>();

    // Constants
    private static final double REQUIRED_WORKING_HOURS = 8.5; // 8 hours 30 minutes
    private static final int HALF_DAY_THRESHOLD = 4; // Minimum hours for half day (changed from 6 to 4)
    private static final String OFFICE_START_TIME = "09:30";
    private static final int LATE_THRESHOLD_MINUTES = 15; // Late after 9:45 AM

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_history, container, false);

        // Initialize views
        initializeViews(view);

        // Initialize session manager
        sessionManager = new SessionManager(requireContext());
        companyKey = sessionManager.getCompanyKey();

        // Setup RecyclerView
        setupRecyclerView();

        // Setup listeners
        setupListeners();

        // Fetch data
        if (companyKey != null && !companyKey.isEmpty()) {
            loadEmployeeDetails();
        } else {
            Toast.makeText(getContext(), "Company information not found", Toast.LENGTH_SHORT).show();
            showEmptyState();
        }

        return view;
    }

    private void initializeViews(View view) {
        recyclerHistory = view.findViewById(R.id.recyclerHistory);
        emptyState = view.findViewById(R.id.emptyState);
        etSearch = view.findViewById(R.id.etSearch);
        tabLayout = view.findViewById(R.id.tabLayout);

        // Change search hint
        etSearch.setHint("Search employee...");
    }

    private void setupRecyclerView() {
        adapter = new HistoryAdapter(filteredList);
        recyclerHistory.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerHistory.setAdapter(adapter);
    }

    private void setupListeners() {
        // Search listener
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString().trim();
                filterData();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Tab listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentTab = tab.getText().toString();
                filterData();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void loadEmployeeDetails() {
        employeesRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Employees");

        if (employeesListener != null) {
            employeesRef.removeEventListener(employeesListener);
        }

        employeesListener = employeesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                employeeDetailsMap.clear();

                Log.d(TAG, "Loading employee details...");

                for (DataSnapshot employeeSnapshot : snapshot.getChildren()) {
                    String employeeId = employeeSnapshot.getKey();
                    Map<String, String> details = new HashMap<>();

                    // Get employee details
                    details.put("name", getStringValue(employeeSnapshot.child("name")));
                    details.put("email", getStringValue(employeeSnapshot.child("email")));
                    details.put("phone", getStringValue(employeeSnapshot.child("phone")));
                    details.put("empId", getStringValue(employeeSnapshot.child("empId")));
                    details.put("companyName", getStringValue(employeeSnapshot.child("companyName")));
                    details.put("address", getStringValue(employeeSnapshot.child("address")));
                    details.put("role", getStringValue(employeeSnapshot.child("role")));
                    details.put("department", getStringValue(employeeSnapshot.child("department")));
                    details.put("photoUrl", getStringValue(employeeSnapshot.child("photoUrl")));
                    details.put("joiningDate", getStringValue(employeeSnapshot.child("joiningDate")));

                    employeeDetailsMap.put(employeeId, details);

                    Log.d(TAG, "Loaded employee: " + employeeId + " - Name: " + details.get("name"));
                }

                Log.d(TAG, "Total employees loaded: " + employeeDetailsMap.size());

                // Now load attendance data
                loadAttendanceData();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading employee details: " + error.getMessage());
                Toast.makeText(getContext(), "Error loading employee details", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadAttendanceData() {
        attendanceRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Attendance");

        if (attendanceListener != null) {
            attendanceRef.removeEventListener(attendanceListener);
        }

        attendanceListener = attendanceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allRecords.clear();

                Log.d(TAG, "Loading attendance data...");

                if (!snapshot.exists()) {
                    Log.d(TAG, "No attendance data found");
                    loadLeavesData();
                    return;
                }

                // Process attendance data
                for (DataSnapshot employeeSnapshot : snapshot.getChildren()) {
                    String employeeId = employeeSnapshot.getKey();

                    // Process each day's attendance for this employee
                    for (DataSnapshot dateSnapshot : employeeSnapshot.getChildren()) {
                        String date = dateSnapshot.getKey();

                        try {
                            HistoryModel model = new HistoryModel();
                            model.setId(employeeId + "_" + date);
                            model.setEmployeeId(employeeId);
                            model.setDate(date);

                            // Get attendance data
                            String checkIn = getStringValue(dateSnapshot.child("punchIn"));
                            String checkOut = getStringValue(dateSnapshot.child("punchOut"));
                            String punchInTime = getStringValue(dateSnapshot.child("punchInTime"));
                            String punchOutTime = getStringValue(dateSnapshot.child("punchOutTime"));

                            // Use whichever field is available
                            String actualCheckIn = checkIn != null && !checkIn.isEmpty() ? checkIn : punchInTime;
                            String actualCheckOut = checkOut != null && !checkOut.isEmpty() ? checkOut : punchOutTime;

                            model.setCheckIn(actualCheckIn != null && !actualCheckIn.isEmpty() ? actualCheckIn : "--:--");
                            model.setCheckOut(actualCheckOut != null && !actualCheckOut.isEmpty() ? actualCheckOut : "--:--");

                            // Check for leave data in attendance
                            String leaveStatus = getStringValue(dateSnapshot.child("leaveStatus"));
                            String leaveType = getStringValue(dateSnapshot.child("leaveType"));
                            String leaveReason = getStringValue(dateSnapshot.child("leaveReason"));

                            if (leaveStatus != null && !leaveStatus.isEmpty() && !leaveStatus.equals("null")) {
                                model.setLeaveStatus(leaveStatus);
                                model.setLeaveType(leaveType);
                                model.setLeaveReason(leaveReason);
                            }

                            // Add employee details
                            addEmployeeDetails(model, employeeId);

                            // Determine status
                            String status = determineAttendanceStatus(model);
                            model.setStatus(status);

                            // Debug: Log late records
                            if ("LATE".equals(status)) {
                                Log.d(TAG, "✅ LATE RECORD: " + model.getEmployeeName() +
                                        " on " + model.getDate() +
                                        " punched in at " + model.getCheckIn());
                            }

                            allRecords.add(model);

                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing attendance for " + employeeId + " on " + date + ": " + e.getMessage());
                        }
                    }
                }

                Log.d(TAG, "Total attendance records loaded: " + allRecords.size());

                // Now load leaves data
                loadLeavesData();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading attendance: " + error.getMessage());
                Toast.makeText(getContext(), "Error loading attendance data", Toast.LENGTH_SHORT).show();
                loadLeavesData();
            }
        });
    }

    private void loadLeavesData() {
        leavesRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Leaves");

        if (leavesListener != null) {
            leavesRef.removeEventListener(leavesListener);
        }

        leavesListener = leavesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d(TAG, "Loading leaves data...");

                if (!snapshot.exists()) {
                    Log.d(TAG, "No leaves data found");
                    sortAllRecords();
                    filterData();
                    return;
                }

                // Process leaves for each employee
                for (DataSnapshot employeeSnapshot : snapshot.getChildren()) {
                    String employeeId = employeeSnapshot.getKey();

                    // Process each leave request for this employee
                    for (DataSnapshot leaveSnapshot : employeeSnapshot.getChildren()) {
                        try {
                            String leaveId = leaveSnapshot.getKey();

                            // Get leave data
                            String companyKeyFromLeave = getStringValue(leaveSnapshot.child("companyKey"));
                            String days = getStringValue(leaveSnapshot.child("days"));
                            String empId = getStringValue(leaveSnapshot.child("empId"));
                            String endDate = getStringValue(leaveSnapshot.child("endDate"));
                            String leaveType = getStringValue(leaveSnapshot.child("leaveType"));
                            String reason = getStringValue(leaveSnapshot.child("reason"));
                            String startDate = getStringValue(leaveSnapshot.child("startDate"));
                            String status = getStringValue(leaveSnapshot.child("status"));
                            Long timestamp = leaveSnapshot.child("timestamp").getValue(Long.class);

                            Log.d(TAG, "Found leave: " + empId + " - " + leaveType +
                                    " from " + startDate + " to " + endDate +
                                    " (" + days + " days) - " + status);

                            if (startDate.isEmpty() || endDate.isEmpty()) {
                                continue;
                            }

                            // Create a date range for the leave
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                            Date start = sdf.parse(startDate);
                            Date end = sdf.parse(endDate);

                            if (start != null && end != null) {
                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(start);

                                // Create a record for each day of leave
                                while (!calendar.getTime().after(end)) {
                                    String currentDate = sdf.format(calendar.getTime());
                                    String recordId = employeeId + "_" + currentDate + "_" + leaveId;

                                    // Check if we already have an attendance record for this date
                                    boolean recordExists = false;
                                    for (HistoryModel existing : allRecords) {
                                        if (existing.getId().equals(employeeId + "_" + currentDate)) {
                                            // Update existing record with leave info
                                            existing.setLeaveStatus(status);
                                            existing.setLeaveType(leaveType);
                                            existing.setLeaveReason(reason);
                                            existing.setStatus(determineAttendanceStatus(existing));
                                            recordExists = true;
                                            break;
                                        }
                                    }

                                    if (!recordExists) {
                                        // Create a new leave record
                                        HistoryModel model = new HistoryModel();
                                        model.setId(recordId);
                                        model.setEmployeeId(employeeId);
                                        model.setDate(currentDate);
                                        model.setLeaveStatus(status);
                                        model.setLeaveType(leaveType);
                                        model.setLeaveReason(reason);
                                        model.setCheckIn("--:--");
                                        model.setCheckOut("--:--");

                                        // Add employee details
                                        addEmployeeDetails(model, employeeId);

                                        // Set status as ABSENT for leave
                                        model.setStatus("ABSENT");

                                        allRecords.add(model);
                                    }

                                    calendar.add(Calendar.DAY_OF_MONTH, 1);
                                }
                            }

                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing leave data: " + e.getMessage());
                        }
                    }
                }

                Log.d(TAG, "Total records after adding leaves: " + allRecords.size());
                sortAllRecords();
                filterData();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading leaves: " + error.getMessage());
                sortAllRecords();
                filterData();
            }
        });
    }

    private String determineAttendanceStatus(HistoryModel model) {
        // First check if it's a leave
        String leaveStatus = model.getLeaveStatus();

        if (leaveStatus != null && !leaveStatus.isEmpty()) {
            if (leaveStatus.equalsIgnoreCase("APPROVED")) {
                return "LEAVE";
            } else if (leaveStatus.equalsIgnoreCase("PENDING")) {
                return "LEAVE_PENDING";
            } else if (leaveStatus.equalsIgnoreCase("REJECTED")) {
                // If leave is rejected, check normal attendance
                return checkNormalAttendance(model);
            }
        }

        // Check normal attendance
        return checkNormalAttendance(model);
    }

    private String checkNormalAttendance(HistoryModel model) {
        String checkIn = model.getCheckIn();
        String checkOut = model.getCheckOut();

        // If no check-in at all = ABSENT
        if (checkIn == null || checkIn.isEmpty() || checkIn.equals("--:--")) {
            return "ABSENT";
        }

        // Check if late
        boolean late = isLate(checkIn);

        // If checked in but no check-out yet
        if (checkOut == null || checkOut.isEmpty() || checkOut.equals("--:--")) {
            return late ? "LATE" : "PRESENT";
        }

        // Both check-in and check-out exist
        try {
            // Calculate hours worked
            double hours = calculateHoursWorked(checkIn, checkOut);

            // Determine status based on hours
            if (hours >= REQUIRED_WORKING_HOURS) {
                return late ? "LATE" : "PRESENT";
            } else if (hours >= HALF_DAY_THRESHOLD) {
                return "HALF_DAY";
            } else {
                return "SHORT_HOURS";
            }

        } catch (Exception e) {
            Log.e(TAG, "Error calculating hours: " + e.getMessage());
            return late ? "LATE" : "PRESENT";
        }
    }

    private double calculateHoursWorked(String checkIn, String checkOut) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date inTime = sdf.parse(checkIn);
            Date outTime = sdf.parse(checkOut);

            long diff = outTime.getTime() - inTime.getTime();
            long totalMinutes = diff / (1000 * 60);

            return totalMinutes / 60.0;
        } catch (Exception e) {
            Log.e(TAG, "Error calculating hours worked: " + e.getMessage());
            return 0.0;
        }
    }

    private boolean isLate(String checkInTime) {
        try {
            if (checkInTime == null || checkInTime.isEmpty() || checkInTime.equals("--:--")) {
                return false;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date punchIn = sdf.parse(checkInTime);
            Date officeStart = sdf.parse(OFFICE_START_TIME);

            long diff = punchIn.getTime() - officeStart.getTime();
            long minutesLate = diff / (1000 * 60);

            return minutesLate > LATE_THRESHOLD_MINUTES;
        } catch (ParseException e) {
            Log.e(TAG, "Error parsing time: " + e.getMessage());
        }
        return false;
    }

    private void addEmployeeDetails(HistoryModel model, String employeeId) {
        if (employeeDetailsMap.containsKey(employeeId)) {
            Map<String, String> details = employeeDetailsMap.get(employeeId);

            if (details != null) {
                // Set employee details
                model.setEmployeeName(details.get("name"));
                model.setEmail(details.get("email"));
                model.setPhone(details.get("phone"));
                model.setEmployeeId(details.get("empId"));
                model.setPhotoUrl(details.get("photoUrl"));

                // Set department/role
                String role = details.get("role");
                String department = details.get("department");
                String companyName = details.get("companyName");

                if (role != null && !role.isEmpty()) {
                    model.setDepartment(role);
                } else if (department != null && !department.isEmpty()) {
                    model.setDepartment(department);
                } else if (companyName != null && !companyName.isEmpty()) {
                    model.setDepartment(companyName);
                } else {
                    model.setDepartment("Employee");
                }
            }
        } else {
            // Employee not found in details map
            model.setEmployeeName("Unknown Employee");
            model.setDepartment("--");
            Log.w(TAG, "Employee details not found for ID: " + employeeId);
        }
    }

    private void sortAllRecords() {
        Collections.sort(allRecords, (o1, o2) -> {
            try {
                // Sort by date (newest first)
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date date1 = sdf.parse(o1.getDate());
                Date date2 = sdf.parse(o2.getDate());

                if (date1 != null && date2 != null) {
                    int dateComparison = date2.compareTo(date1); // Descending
                    if (dateComparison != 0) {
                        return dateComparison;
                    }
                }

                // Then sort by employee name
                String name1 = o1.getEmployeeName() != null ? o1.getEmployeeName() : "";
                String name2 = o2.getEmployeeName() != null ? o2.getEmployeeName() : "";
                return name1.compareToIgnoreCase(name2);

            } catch (ParseException e) {
                return 0;
            }
        });
    }

    private void filterData() {
        filteredList.clear();

        if (allRecords.isEmpty()) {
            updateUI();
            return;
        }

        // Debug counts
        int lateCount = 0;
        int presentCount = 0;
        int absentCount = 0;
        int leaveCount = 0;

        for (HistoryModel record : allRecords) {
            boolean matches = true;

            // Apply tab filter
            if (!currentTab.equals("All")) {
                String status = record.getStatus();
                if (status == null) {
                    matches = false;
                } else {
                    switch (currentTab) {
                        case "Present":
                            // Show PRESENT records only (not late)
                            matches = status.equalsIgnoreCase("PRESENT");
                            if (matches) presentCount++;
                            break;
                        case "Absent":
                            // Show ABSENT and SHORT_HOURS (less than 4 hours)
                            matches = status.equalsIgnoreCase("ABSENT") ||
                                    status.equalsIgnoreCase("SHORT_HOURS");
                            if (matches) absentCount++;
                            break;
                        case "Late":
                            // Show LATE records only
                            matches = status.equalsIgnoreCase("LATE");
                            if (matches) lateCount++;
                            break;
                        case "Leave":
                            // Show LEAVE and LEAVE_PENDING records
                            matches = status.equalsIgnoreCase("LEAVE") ||
                                    status.equalsIgnoreCase("LEAVE_PENDING");
                            if (matches) leaveCount++;
                            break;
                    }
                }
            }

            // Apply search filter
            if (matches && !searchQuery.isEmpty()) {
                String searchLower = searchQuery.toLowerCase();

                boolean nameMatch = record.getEmployeeName() != null &&
                        record.getEmployeeName().toLowerCase().contains(searchLower);
                boolean dateMatch = record.getDate() != null &&
                        record.getDate().toLowerCase().contains(searchLower);
                boolean deptMatch = record.getDepartment() != null &&
                        record.getDepartment().toLowerCase().contains(searchLower);
                boolean statusMatch = record.getStatus() != null &&
                        record.getStatus().toLowerCase().contains(searchLower);

                matches = nameMatch || dateMatch || deptMatch || statusMatch;
            }

            if (matches) {
                filteredList.add(record);
            }
        }

        // Debug log
        Log.d(TAG, "🔍 Filter Results - Tab: " + currentTab +
                ", Late: " + lateCount +
                ", Present: " + presentCount +
                ", Absent: " + absentCount +
                ", Leave: " + leaveCount);

        updateUI();
    }

    private void updateUI() {
        if (adapter != null) {
            adapter.updateList(filteredList);
        }

        // Log for debugging
        Log.d(TAG, "📱 Filtered list size: " + filteredList.size() + " for tab: " + currentTab);

        if (filteredList.isEmpty()) {
            showEmptyState();
        } else {
            hideEmptyState();
        }
    }

    private void showEmptyState() {
        if (emptyState != null && recyclerHistory != null) {
            emptyState.setVisibility(View.VISIBLE);
            recyclerHistory.setVisibility(View.GONE);

            // Update empty state text
            TextView titleText = emptyState.findViewById(R.id.text_empty_message);
            TextView subtitleText = emptyState.findViewById(R.id.subtitle_empty_message);

            if (titleText != null) {
                if (currentTab.equals("All")) {
                    titleText.setText("No records found");
                    if (subtitleText != null) {
                        subtitleText.setText("There are no attendance records");
                    }
                } else {
                    titleText.setText("No " + currentTab.toLowerCase() + " records");
                    if (subtitleText != null) {
                        subtitleText.setText("No " + currentTab.toLowerCase() + " records found for the selected filter");
                    }
                }
            }
        }
    }

    private void hideEmptyState() {
        if (emptyState != null && recyclerHistory != null) {
            emptyState.setVisibility(View.GONE);
            recyclerHistory.setVisibility(View.VISIBLE);
        }
    }

    // Helper method to safely get string values
    private String getStringValue(DataSnapshot snapshot) {
        if (snapshot.exists()) {
            String value = snapshot.getValue(String.class);
            return value != null ? value : "";
        }
        return "";
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Remove Firebase listeners
        removeListeners();
    }

    private void removeListeners() {
        if (attendanceRef != null && attendanceListener != null) {
            attendanceRef.removeEventListener(attendanceListener);
        }
        if (employeesRef != null && employeesListener != null) {
            employeesRef.removeEventListener(employeesListener);
        }
        if (leavesRef != null && leavesListener != null) {
            leavesRef.removeEventListener(leavesListener);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh data when fragment resumes
        if (companyKey != null && !companyKey.isEmpty()) {
            loadEmployeeDetails();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // Remove listeners to save resources
        removeListeners();
    }
}