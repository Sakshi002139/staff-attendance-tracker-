package com.example.staffattendance.Model;

// DailyRecord.java
public class DailyRecord {
    private String date;
    private String punchIn;
    private String punchOut;
    private String status; // "present", "absent", "half_day", "leave"
    private double workingHours;
    private String notes;

    // Empty constructor required for Firebase
    public DailyRecord() {}

    public DailyRecord(String punchIn, String punchOut, String status) {
        this.punchIn = punchIn;
        this.punchOut = punchOut;
        this.status = status;
    }

    // Getters and setters (Firebase needs these)
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getPunchIn() { return punchIn; }
    public void setPunchIn(String punchIn) { this.punchIn = punchIn; }

    public String getPunchOut() { return punchOut; }
    public void setPunchOut(String punchOut) { this.punchOut = punchOut; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getWorkingHours() { return workingHours; }
    public void setWorkingHours(double workingHours) { this.workingHours = workingHours; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}