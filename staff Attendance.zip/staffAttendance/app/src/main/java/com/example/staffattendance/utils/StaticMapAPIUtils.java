package com.example.staffattendance.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class StaticMapAPIUtils {

    // =====================================================
    // STATIC MAP IMAGE API (for ImageView only)
    // =====================================================
    private static final String STATIC_MAP_API_URL =
            "https://staticmapapi.com/map";

    // =====================================================
    // OFFICE LOCATION (FIXED & VERIFIED)
    // Kore Arcade, Sangli
    // =====================================================
    public static final double OFFICE_LATITUDE  = 16.8480701;
    public static final double OFFICE_LONGITUDE = 74.5952647;

    // =====================================================
    // 1️⃣ GENERATE STATIC MAP IMAGE URL
    // =====================================================
    public static String getPunchLocationMapUrl(
            double latitude,
            double longitude,
            String punchType
    ) {

        String markerColor = "red";

        if (punchType != null) {
            String type = punchType.toUpperCase();
            if (type.contains("IN")) {
                markerColor = "green";
            } else if (type.contains("OUT")) {
                markerColor = "red";
            } else if (type.contains("OFFICE")) {
                markerColor = "blue";
            }
        }

        return STATIC_MAP_API_URL +
                "?lat=" + latitude +
                "&lon=" + longitude +
                "&zoom=16" +
                "&width=600" +
                "&height=400" +
                "&marker=color:" + markerColor + "|" +
                latitude + "," + longitude +
                "&format=png";
    }

    // =====================================================
    // 2️⃣ LOAD STATIC MAP INTO IMAGEVIEW
    // =====================================================
    public static void loadPunchLocationMap(
            Context context,
            ImageView imageView,
            double latitude,
            double longitude,
            String punchType
    ) {

        if (latitude == 0.0 || longitude == 0.0) return;

        String imageUrl =
                getPunchLocationMapUrl(latitude, longitude, punchType);

        Picasso.get()
                .load(imageUrl)
                .placeholder(android.R.drawable.ic_menu_mapmode)
                .error(android.R.drawable.ic_dialog_alert)
                .fit()
                .centerCrop()
                .into(imageView);
    }

    // =====================================================
    // 3️⃣ SMALL MAP THUMBNAIL (RecyclerView / History)
    // =====================================================
    public static String getLocationThumbnailUrl(
            double latitude,
            double longitude
    ) {

        return STATIC_MAP_API_URL +
                "?lat=" + latitude +
                "&lon=" + longitude +
                "&zoom=15" +
                "&width=200" +
                "&height=150" +
                "&marker=size:small|color:red|" +
                latitude + "," + longitude +
                "&format=png";
    }

    // =====================================================
    // 4️⃣ OPEN GOOGLE MAPS → OFFICE
    // =====================================================
    public static void openOfficeInGoogleMaps(Context context) {

        String googleMapsUrl =
                "https://www.google.com/maps/dir/?api=1" +
                        "&destination=" +
                        OFFICE_LATITUDE + "," + OFFICE_LONGITUDE +
                        "&travelmode=driving";

        Intent intent =
                new Intent(Intent.ACTION_VIEW, Uri.parse(googleMapsUrl));
        intent.setPackage("com.google.android.apps.maps");

        context.startActivity(intent);
    }

    // =====================================================
    // 5️⃣ OPEN GOOGLE MAPS (CURRENT → OFFICE)
    // =====================================================
    public static void openDirectionsFromCurrentLocation(
            Context context,
            double currentLatitude,
            double currentLongitude
    ) {

        String googleMapsUrl =
                "https://www.google.com/maps/dir/?api=1" +
                        "&origin=" +
                        currentLatitude + "," + currentLongitude +
                        "&destination=" +
                        OFFICE_LATITUDE + "," + OFFICE_LONGITUDE +
                        "&travelmode=driving";

        Intent intent =
                new Intent(Intent.ACTION_VIEW, Uri.parse(googleMapsUrl));
        intent.setPackage("com.google.android.apps.maps");

        context.startActivity(intent);
    }
}
