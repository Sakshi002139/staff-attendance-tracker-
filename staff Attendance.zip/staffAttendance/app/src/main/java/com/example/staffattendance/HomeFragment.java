package com.example.staffattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.StaffAdapter;
import com.example.staffattendance.Model.StaffModel;
import com.example.staffattendance.utils.FirebaseManager;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.database.*;

import java.text.SimpleDateFormat;
import java.util.*;

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";

    private Spinner spinnerFilter;
    private TextView tvInValue, tvOutValue, tvNoPunchInValue, tvTotalStaff, tvAdminName;
    private EditText edtSearch;
    private RecyclerView recyclerViewStaff;
    private ExtendedFloatingActionButton fabAddStaff;
    private LinearLayout actionPending;

    private StaffAdapter adapter;

    private final List<StaffModel> staffList = new ArrayList<>();
    private final List<StaffModel> filteredList = new ArrayList<>();

    private SessionManager session;
    private String companyKey;

    private int inCount = 0;
    private int outCount = 0;
    private int noPunchCount = 0;

    private DatabaseReference employeesRef;
    private DatabaseReference attendanceRef;

    private ValueEventListener employeesListener;
    private ValueEventListener attendanceListener;

    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        init(view);

        session = new SessionManager(requireContext());
        companyKey = session.getCompanyKey();

        if (companyKey == null || companyKey.isEmpty()) {
            Log.e(TAG, "Company key missing");
            Toast.makeText(requireContext(), "Company key missing. Please login again.", Toast.LENGTH_SHORT).show();
            return;
        }

        employeesRef = FirebaseManager.getInstance().getCompanyEmployeesRef(companyKey);
        attendanceRef = FirebaseManager.getInstance().getCompanyAttendanceRef(companyKey);

        setupRecycler();
        setupSearch();
        setupSpinnerFilter();

        // Load admin name first
        loadAdminName();
        loadEmployees();
    }

    private void init(View view) {

        spinnerFilter = view.findViewById(R.id.spinnerFilter);
        tvInValue = view.findViewById(R.id.tvInValue);
        tvOutValue = view.findViewById(R.id.tvOutValue);
        tvNoPunchInValue = view.findViewById(R.id.tvNoPunchInValue);
        tvTotalStaff = view.findViewById(R.id.tvTotalStaff);
        tvAdminName = view.findViewById(R.id.tvAdminName);

        edtSearch = view.findViewById(R.id.edtSearch);
        recyclerViewStaff = view.findViewById(R.id.recyclerViewStaff);
        fabAddStaff = view.findViewById(R.id.fabAddStaff);
        actionPending = view.findViewById(R.id.actionPending);

        fabAddStaff.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddStaffActivity.class);
            intent.putExtra("companyKey", companyKey);
            startActivity(intent);
        });

        actionPending.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), PendingRequestsActivity.class));
        });
    }

    /**
     * LOAD ADMIN NAME with correct Firebase path
     */
    private void loadAdminName() {

        String phone = session.getUserPhone();
        String nameFromSession = session.getUserName();

        // First, set from session if available
        if (nameFromSession != null && !nameFromSession.isEmpty()) {
            tvAdminName.setText(nameFromSession);
        } else {
            tvAdminName.setText("Admin");
        }

        if (phone == null || phone.isEmpty() || companyKey == null || companyKey.isEmpty()) {
            Log.e(TAG, "Phone or company key missing");
            return;
        }

        // Correct Firebase path - Companies -> companyKey -> admins -> phone -> name
        DatabaseReference adminRef = FirebaseDatabase.getInstance()
                .getReference()
                .child("Companies")
                .child(companyKey)
                .child("admins")
                .child(phone);

        Log.d(TAG, "Loading admin from path: Companies/" + companyKey + "/admins/" + phone);

        adminRef.addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (!isAdded()) return;

                if (snapshot.exists()) {

                    // Try different possible field names
                    String name = null;

                    // Check for 'name' field
                    if (snapshot.child("name").exists()) {
                        name = snapshot.child("name").getValue(String.class);
                    }
                    // Check for 'adminName' field
                    else if (snapshot.child("adminName").exists()) {
                        name = snapshot.child("adminName").getValue(String.class);
                    }
                    // Check if the snapshot itself is a string
                    else if (snapshot.getValue() instanceof String) {
                        name = snapshot.getValue(String.class);
                    }
                    // Try to get any string value
                    else {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            if (child.getValue() instanceof String) {
                                name = child.getValue(String.class);
                                break;
                            }
                        }
                    }

                    if (name != null && !name.isEmpty()) {
                        tvAdminName.setText(name);
                        // Save to session
                        session.saveUserData(name, session.getUserEmail());
                        Log.d(TAG, "Admin name loaded: " + name);
                    } else {
                        // If no name found, try to get email or phone as fallback
                        String email = snapshot.child("email").getValue(String.class);
                        if (email != null && !email.isEmpty()) {
                            tvAdminName.setText(email);
                        } else {
                            tvAdminName.setText("Admin");
                        }
                    }
                } else {
                    Log.d(TAG, "Admin data not found at path");
                    // Try alternative path with uppercase 'Admins'
                    tryAlternativeAdminPath(phone);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Admin load failed: " + error.getMessage());
                // Set default name on error
                tvAdminName.setText("Admin");
            }
        });
    }

    /**
     * Alternative method to try different admin path variations
     */
    private void tryAlternativeAdminPath(String phone) {
        // Try with uppercase 'Admins'
        DatabaseReference altAdminRef = FirebaseDatabase.getInstance()
                .getReference()
                .child("Companies")
                .child(companyKey)
                .child("Admins")
                .child(phone);

        altAdminRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;

                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    if (name != null && !name.isEmpty()) {
                        tvAdminName.setText(name);
                        session.saveUserData(name, session.getUserEmail());
                    }
                } else {
                    // If still not found, set default
                    tvAdminName.setText("Admin Dashboard");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                tvAdminName.setText("Admin Dashboard");
            }
        });
    }

    private void setupRecycler() {
        adapter = new StaffAdapter(filteredList, requireContext());
        recyclerViewStaff.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerViewStaff.setAdapter(adapter);
    }

    private void setupSearch() {

        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilters();
            }
        });
    }

    private void setupSpinnerFilter() {

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.attendance_filter,
                android.R.layout.simple_spinner_item
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(adapter);

        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilters();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadEmployees() {

        employeesListener = new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                staffList.clear();

                for (DataSnapshot employeeSnapshot : snapshot.getChildren()) {

                    String empId = employeeSnapshot.getKey();

                    String name = employeeSnapshot.child("name").getValue(String.class);
                    String phone = employeeSnapshot.child("phone").getValue(String.class);
                    String accountStatus = employeeSnapshot.child("accountStatus").getValue(String.class);

                    StaffModel model = new StaffModel(empId, name, phone);

                    // Set account status
                    if (accountStatus != null) {
                        model.setAccountStatus(accountStatus);
                    }

                    // Set initial status
                    model.setStatus("NO_PUNCH");

                    // Clear any existing times
                    model.setPunchIn(null);
                    model.setPunchOut(null);
                    model.setCheckIn(null);
                    model.setCheckOut(null);

                    staffList.add(model);

                    Log.d(TAG, "Added employee: " + name + " with ID: " + empId);
                }

                tvTotalStaff.setText("Total Staff: " + staffList.size());

                loadTodayAttendance();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading employees: " + error.getMessage());
            }
        };

        employeesRef.addValueEventListener(employeesListener);
    }

    private void loadTodayAttendance() {

        if (attendanceListener != null) {
            attendanceRef.removeEventListener(attendanceListener);
        }

        String todayDate = dateFormat.format(new Date());
        Log.d(TAG, "Loading attendance for date: " + todayDate);

        attendanceListener = new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                inCount = 0;
                outCount = 0;
                noPunchCount = 0;

                Log.d(TAG, "Attendance snapshot children count: " + snapshot.getChildrenCount());

                for (StaffModel staff : staffList) {

                    String empId = staff.getEmpId();

                    // Reset staff times and status first
                    staff.setPunchIn(null);
                    staff.setPunchOut(null);
                    staff.setCheckIn(null);
                    staff.setCheckOut(null);

                    // Check if there's attendance data for this employee
                    DataSnapshot employeeAttendance = snapshot.child(empId);

                    if (employeeAttendance.exists()) {
                        Log.d(TAG, "Found attendance for employee: " + staff.getName() + " (ID: " + empId + ")");

                        // Try to get today's attendance
                        DataSnapshot todayNode = employeeAttendance.child(todayDate);

                        if (todayNode.exists()) {

                            Log.d(TAG, "Today's attendance exists for: " + staff.getName());

                            // Get the actual time values with correct field names
                            String punchIn = null;
                            String punchOut = null;

                            // Try different possible field names for check-in
                            if (todayNode.child("punchInTime").exists()) {
                                punchIn = todayNode.child("punchInTime").getValue(String.class);
                                Log.d(TAG, "Found punchInTime: " + punchIn);
                            } else if (todayNode.child("checkIn").exists()) {
                                punchIn = todayNode.child("checkIn").getValue(String.class);
                                Log.d(TAG, "Found checkIn: " + punchIn);
                            } else if (todayNode.child("punchIn").exists()) {
                                punchIn = todayNode.child("punchIn").getValue(String.class);
                                Log.d(TAG, "Found punchIn: " + punchIn);
                            }

                            // Try different possible field names for check-out
                            if (todayNode.child("punchOutTime").exists()) {
                                punchOut = todayNode.child("punchOutTime").getValue(String.class);
                                Log.d(TAG, "Found punchOutTime: " + punchOut);
                            } else if (todayNode.child("checkOut").exists()) {
                                punchOut = todayNode.child("checkOut").getValue(String.class);
                                Log.d(TAG, "Found checkOut: " + punchOut);
                            } else if (todayNode.child("punchOut").exists()) {
                                punchOut = todayNode.child("punchOut").getValue(String.class);
                                Log.d(TAG, "Found punchOut: " + punchOut);
                            }

                            // Set the times in the model
                            if (punchIn != null && !punchIn.isEmpty()) {
                                staff.setPunchIn(punchIn);
                                staff.setCheckIn(punchIn);
                            }

                            if (punchOut != null && !punchOut.isEmpty()) {
                                staff.setPunchOut(punchOut);
                                staff.setCheckOut(punchOut);
                            }

                            // Determine status based on punch times
                            if (punchIn != null && punchOut != null) {
                                staff.setStatus("PRESENT");
                                outCount++;
                                Log.d(TAG, "Status: PRESENT for " + staff.getName());

                            } else if (punchIn != null) {
                                staff.setStatus("IN");
                                inCount++;
                                Log.d(TAG, "Status: IN for " + staff.getName());

                            } else {
                                staff.setStatus("NO_PUNCH");
                                noPunchCount++;
                                Log.d(TAG, "Status: NO_PUNCH for " + staff.getName());
                            }

                        } else {
                            // No attendance for today, but might have other dates
                            staff.setStatus("NO_PUNCH");
                            noPunchCount++;
                            Log.d(TAG, "No today's attendance for: " + staff.getName());
                        }

                    } else {
                        // No attendance record at all for this employee
                        staff.setStatus("NO_PUNCH");
                        noPunchCount++;
                        Log.d(TAG, "No attendance record for: " + staff.getName());
                    }
                }

                // Log final counts
                Log.d(TAG, "Final counts - IN: " + inCount + ", OUT: " + outCount + ", NO PUNCH: " + noPunchCount);

                updateUI();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Attendance load failed: " + error.getMessage());
            }
        };

        attendanceRef.addValueEventListener(attendanceListener);
    }

    private void updateUI() {

        if (!isAdded()) return;

        tvInValue.setText(String.valueOf(inCount));
        tvOutValue.setText(String.valueOf(outCount));
        tvNoPunchInValue.setText(String.valueOf(noPunchCount));

        applyFilters();
    }

    /**
     * FIXED: applyFilters() now uses string-based filtering to handle all 6 spinner options
     */
    private void applyFilters() {

        if (adapter == null) return;

        String searchQuery = edtSearch.getText().toString().toLowerCase().trim();
        String selectedFilter = spinnerFilter.getSelectedItem().toString();

        filteredList.clear();

        for (StaffModel staff : staffList) {

            String name = staff.getName() == null ? "" : staff.getName().toLowerCase();

            if (!name.contains(searchQuery)) continue;

            switch (selectedFilter) {

                case "All":
                    filteredList.add(staff);
                    break;

                case "Present":
                    if ("PRESENT".equals(staff.getStatus()))
                        filteredList.add(staff);
                    break;

                case "Late":
                    if ("LATE".equals(staff.getStatus()))
                        filteredList.add(staff);
                    break;

                case "In":
                    if ("IN".equals(staff.getStatus()))
                        filteredList.add(staff);
                    break;

                case "No Punch":
                    if ("NO_PUNCH".equals(staff.getStatus()))
                        filteredList.add(staff);
                    break;

                case "Leave":
                    if ("LEAVE".equals(staff.getStatus()))
                        filteredList.add(staff);
                    break;

                default:
                    // If filter doesn't match any case, show all (fallback)
                    filteredList.add(staff);
                    break;
            }
        }

        adapter.notifyDataSetChanged();

        Log.d(TAG, "Filter applied - showing " + filteredList.size() + " of " + staffList.size() + " staff");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (employeesListener != null)
            employeesRef.removeEventListener(employeesListener);

        if (attendanceListener != null)
            attendanceRef.removeEventListener(attendanceListener);
    }
}