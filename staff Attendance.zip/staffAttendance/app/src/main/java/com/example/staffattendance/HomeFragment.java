package com.example.staffattendance;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.staffattendance.Adapter.HistoryAdapter;
import com.example.staffattendance.Model.HistoryModel;
import com.example.staffattendance.utils.AttendanceUtils;
import com.example.staffattendance.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";

    // UI Components
    private TextView txtTodayDate, txtTotalEmp, txtPresent, txtAbsent, txtLate, tvUserName, tvTime;
    private RecyclerView recyclerAttendance;
    private EditText edtSearch;
    private LinearLayout llEmptyState;
    private ImageView btnRefreshAttendance;
    private MaterialButton btnEmptyRefresh;

    // Data lists
    private final ArrayList<HistoryModel> historyList = new ArrayList<>();
    private final ArrayList<HistoryModel> filteredList = new ArrayList<>();
    private HistoryAdapter historyAdapter;

    // Session and company data
    private SessionManager sessionManager;
    private String companyKey;
    private String currentDate;

    // Firebase references and listeners
    private ValueEventListener employeeListener;
    private ValueEventListener attendanceListener;
    private DatabaseReference employeesRef;
    private DatabaseReference attendanceRef;

    // Handler for live clock
    private android.os.Handler timeHandler;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize UI components
        initializeUI(view);

        // Initialize SessionManager
        sessionManager = new SessionManager(requireContext());

        // Set default values
        setDefaultValues();

        // Set user name
        String userName = sessionManager.getUserName();
        tvUserName.setText(userName.isEmpty() ? "Welcome Admin" : "Welcome, " + userName);

        // Set today's date
        currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String formattedDate = new SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault()).format(new Date());
        txtTodayDate.setText(formattedDate);

        // Setup RecyclerView
        setupRecyclerView();

        // Start live clock
        startLiveClock();

        // Setup search functionality
        setupSearch();

        // Setup click listeners
        setupClickListeners();

        // Get company key from session and start data loading
        initializeCompanyData();

        return view;
    }

    private void initializeUI(View view) {
        txtTodayDate = view.findViewById(R.id.txtTodayDate);
        txtTotalEmp = view.findViewById(R.id.txtTotalEmp);
        txtPresent = view.findViewById(R.id.txtPresent);
        txtAbsent = view.findViewById(R.id.txtAbsent);
        txtLate = view.findViewById(R.id.txtLate);
        tvUserName = view.findViewById(R.id.tvUserName);
        tvTime = view.findViewById(R.id.tvTime);
        recyclerAttendance = view.findViewById(R.id.recyclerAttendance);
        edtSearch = view.findViewById(R.id.edtSearch);
        llEmptyState = view.findViewById(R.id.llEmptyState);
        btnEmptyRefresh = view.findViewById(R.id.btnEmptyRefresh);
    }

    private void setDefaultValues() {
        txtTotalEmp.setText("0");
        txtPresent.setText("0");
        txtAbsent.setText("0");
        txtLate.setText("0");
        tvTime.setText("--:--");
    }

    private void setupRecyclerView() {
        recyclerAttendance.setLayoutManager(new LinearLayoutManager(getContext()));
        historyAdapter = new HistoryAdapter(filteredList);
        recyclerAttendance.setAdapter(historyAdapter);

        // Set empty state visibility
        updateEmptyState();
    }

    private void setupClickListeners() {
        if (btnRefreshAttendance != null) {
            btnRefreshAttendance.setOnClickListener(v -> refreshData());
        }
        if (btnEmptyRefresh != null) {
            btnEmptyRefresh.setOnClickListener(v -> refreshData());
        }
    }

    private void refreshData() {
        Toast.makeText(getContext(), "Refreshing data...", Toast.LENGTH_SHORT).show();
        if (companyKey != null && !companyKey.isEmpty()) {
            removeListeners();
            startLiveDataListener();
        }
    }

    private void startLiveClock() {
        timeHandler = new android.os.Handler();
        Runnable timeUpdater = new Runnable() {
            @Override
            public void run() {
                if (isAdded() && getActivity() != null) {
                    SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
                    String currentTime = timeFormat.format(new Date());
                    tvTime.setText(currentTime);
                    timeHandler.postDelayed(this, 1000);
                }
            }
        };
        timeHandler.post(timeUpdater);
    }

    private void setupSearch() {
        if (edtSearch != null) {
            edtSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void afterTextChanged(Editable s) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterAttendance(s.toString());
                }
            });
        }
    }

    private void initializeCompanyData() {
        companyKey = sessionManager.getCompanyKey();

        if (companyKey != null && !companyKey.isEmpty()) {
            startLiveDataListener();
        } else {
            Toast.makeText(getContext(), "Company information not found", Toast.LENGTH_SHORT).show();
            showEmptyState();
        }
    }

    private void startLiveDataListener() {
        Log.d(TAG, "Starting live data listener for company: " + companyKey);
        removeListeners();

        employeesRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Employees");

        attendanceRef = FirebaseDatabase.getInstance()
                .getReference("Companies")
                .child(companyKey)
                .child("Attendance")
                .child(currentDate);

        // Listen for employee count
        employeeListener = employeesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int totalEmployees = (int) snapshot.getChildrenCount();
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        txtTotalEmp.setText(String.valueOf(totalEmployees));
                    });
                }
                Log.d(TAG, "Total employees: " + totalEmployees);
                loadAttendanceData(totalEmployees);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading employees: " + error.getMessage());
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Error loading employees", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    private void loadAttendanceData(int totalEmployees) {
        if (attendanceRef == null) return;

        attendanceListener = attendanceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d(TAG, "Attendance data received, count: " + snapshot.getChildrenCount());

                final AttendanceCounts counts = new AttendanceCounts();
                final Map<String, HistoryModel> attendanceMap = new HashMap<>();

                // Clear lists first
                historyList.clear();
                filteredList.clear();

                // If there's attendance data
                if (snapshot.exists() && snapshot.getChildrenCount() > 0) {
                    // Process each attendance record
                    for (DataSnapshot employeeSnapshot : snapshot.getChildren()) {
                        String employeeId = employeeSnapshot.getKey();
                        Log.d(TAG, "Processing attendance for employee: " + employeeId);

                        // Try to get as HistoryModel first, then fallback to individual fields
                        HistoryModel model = employeeSnapshot.getValue(HistoryModel.class);
                        if (model == null) {
                            model = new HistoryModel();

                            // Get individual fields
                            String checkIn = employeeSnapshot.child("checkIn").getValue(String.class);
                            String checkOut = employeeSnapshot.child("checkOut").getValue(String.class);
                            String status = employeeSnapshot.child("status").getValue(String.class);
                            Long timestamp = employeeSnapshot.child("timestamp").getValue(Long.class);
                            String finalStatus = employeeSnapshot.child("finalStatus").getValue(String.class);

                            model.setCheckIn(checkIn != null ? checkIn : "--:--");
                            model.setCheckOut(checkOut != null ? checkOut : "--:--");
                            model.setStatus(status != null ? status : "");
                            model.setFinalStatus(finalStatus != null ? finalStatus : "");
                            model.setPunchInTimestamp(timestamp != null ? timestamp : 0);
                        }

                        model.setId(employeeId);
                        model.setEmployeeId(employeeId);

                        // Check if late using the utility class
                        boolean isLate = AttendanceUtils.isLate(model.getCheckIn());
                        model.setLate(isLate);

                        // Set date
                        model.setDate(currentDate);

                        // Add to map
                        attendanceMap.put(employeeId, model);

                        // Load employee details
                        getEmployeeDetails(employeeId, model, attendanceMap, counts);
                    }
                }

                // Now check for all employees (including those without attendance)
                employeesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot employeeSnapshot) {
                        Log.d(TAG, "Checking all employees, count: " + employeeSnapshot.getChildrenCount());

                        for (DataSnapshot empSnap : employeeSnapshot.getChildren()) {
                            String employeeId = empSnap.getKey();

                            if (!attendanceMap.containsKey(employeeId)) {
                                // Employee hasn't punched in - mark as absent
                                createAbsentEmployee(employeeId, empSnap, attendanceMap, counts);
                            }
                        }

                        // Update UI with final data
                        updateUIAfterDataLoad(attendanceMap, counts, totalEmployees);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e(TAG, "Error checking absent employees: " + error.getMessage());
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading attendance: " + error.getMessage());
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Error loading attendance", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    private void getEmployeeDetails(String employeeId, HistoryModel model,
                                    Map<String, HistoryModel> attendanceMap,
                                    AttendanceCounts counts) {
        employeesRef.child(employeeId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Log.d(TAG, "Loading details for employee: " + employeeId);

                    // Get employee details with proper null checks
                    String name = snapshot.child("name").getValue(String.class);
                    // FIRST, try to get role field (this is what you want to display)
                    String role = snapshot.child("role").getValue(String.class);
                    // If role not found, fallback to department
                    String department = snapshot.child("department").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class);
                    String empId = snapshot.child("empId").getValue(String.class);
                    String companyName = snapshot.child("companyName").getValue(String.class);

                    Log.d(TAG, "Employee " + employeeId + " - Name: " + name + ", Role: " + role + ", Dept: " + department);

                    if (name != null && !name.isEmpty()) {
                        model.setEmployeeName(name);
                    } else {
                        model.setEmployeeName("Unknown");
                    }

                    // PRIORITY: role -> department -> companyName -> "Employee"
                    if (role != null && !role.isEmpty()) {
                        model.setDepartment(role); // This will display "Android developer"
                    } else if (department != null && !department.isEmpty()) {
                        model.setDepartment(department);
                    } else if (companyName != null && !companyName.isEmpty()) {
                        model.setDepartment(companyName);
                    } else {
                        model.setDepartment("Employee");
                    }

                    if (email != null) model.setEmail(email);
                    if (phone != null) model.setPhone(phone);

                    // Determine final status if not already set
                    if (model.getStatus() == null || model.getStatus().isEmpty()) {
                        String status = determineStatus(model);
                        model.setStatus(status);

                        // Update counts - FIXED: Late is counted separately
                        if ("PRESENT".equalsIgnoreCase(status)) {
                            counts.present++;
                        } else if ("LATE".equalsIgnoreCase(status)) {
                            counts.present++; // Late counts as present for attendance
                            counts.late++;    // But also counted separately as late
                        } else if ("ABSENT".equalsIgnoreCase(status)) {
                            counts.absent++;
                        }
                    } else {
                        // If status is already set, still update counts
                        String status = model.getStatus().toUpperCase();
                        if ("PRESENT".equals(status)) {
                            counts.present++;
                        } else if ("LATE".equals(status)) {
                            counts.present++;
                            counts.late++;
                        } else if ("ABSENT".equals(status)) {
                            counts.absent++;
                        }
                    }
                } else {
                    Log.e(TAG, "Employee not found: " + employeeId);
                    model.setEmployeeName("Unknown Employee");
                    model.setDepartment("--");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading employee details: " + error.getMessage());
            }
        });
    }

    private void updateUIAfterDataLoad(Map<String, HistoryModel> attendanceMap,
                                       AttendanceCounts counts, int totalEmployees) {
        Log.d(TAG, "Updating UI with " + attendanceMap.size() + " employees");

        // Update lists
        historyList.clear();
        historyList.addAll(attendanceMap.values());

        // Sort by status (Present -> Late -> Absent) then by name
        Collections.sort(historyList, (o1, o2) -> {
            // First sort by status priority
            int status1 = getStatusPriority(o1.getStatus());
            int status2 = getStatusPriority(o2.getStatus());

            if (status1 != status2) {
                return Integer.compare(status1, status2);
            }

            // Then sort by name
            String name1 = o1.getEmployeeName() != null ? o1.getEmployeeName() : "";
            String name2 = o2.getEmployeeName() != null ? o2.getEmployeeName() : "";
            return name1.compareToIgnoreCase(name2);
        });

        filteredList.clear();
        filteredList.addAll(historyList);

        // Update UI on main thread
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                historyAdapter.updateList(filteredList);

                // Update statistics - FIXED: Show correct counts
                txtPresent.setText(String.valueOf(counts.present));
                txtAbsent.setText(String.valueOf(counts.absent));
                txtLate.setText(String.valueOf(counts.late));

                // Log for debugging
                Log.d(TAG, "=== FINAL COUNTS ===");
                Log.d(TAG, "Total Employees: " + totalEmployees);
                Log.d(TAG, "Present: " + counts.present);
                Log.d(TAG, "Absent: " + counts.absent);
                Log.d(TAG, "Late: " + counts.late);

                for (HistoryModel model : historyList) {
                    Log.d(TAG, "Employee: " + model.getEmployeeName() +
                            " | Role: " + model.getDepartment() +
                            " | Status: " + model.getStatus() +
                            " | CheckIn: " + model.getCheckIn() +
                            " | IsLate: " + model.isLate());
                }

                // Update empty state
                updateEmptyState();
            });
        }
    }

    // Wrapper class to hold counts
    private static class AttendanceCounts {
        int present;
        int absent;
        int late;

        AttendanceCounts() {
            this.present = 0;
            this.absent = 0;
            this.late = 0;
        }
    }

    private int getStatusPriority(String status) {
        if (status == null) return 3;
        switch (status.toUpperCase()) {
            case "PRESENT":
                return 1;
            case "LATE":
                return 2;
            case "ABSENT":
                return 3;
            default:
                return 4;
        }
    }

    private void createAbsentEmployee(String employeeId, DataSnapshot empSnap,
                                      Map<String, HistoryModel> attendanceMap,
                                      AttendanceCounts counts) {
        Log.d(TAG, "Creating absent employee: " + employeeId);

        // Create history model for this absent employee
        HistoryModel model = new HistoryModel();
        model.setId(employeeId);
        model.setEmployeeId(employeeId);
        model.setStatus("ABSENT");
        model.setDate(currentDate);
        model.setCheckIn("--:--");
        model.setCheckOut("--:--");
        model.setPunchInTimestamp(0);
        model.setLate(false);

        // Get employee details
        String name = empSnap.child("name").getValue(String.class);
        // FIRST, try to get role field
        String role = empSnap.child("role").getValue(String.class);
        // If role not found, fallback to department
        String department = empSnap.child("department").getValue(String.class);
        String email = empSnap.child("email").getValue(String.class);
        String phone = empSnap.child("phone").getValue(String.class);
        String companyName = empSnap.child("companyName").getValue(String.class);

        if (name != null && !name.isEmpty()) {
            model.setEmployeeName(name);
        } else {
            model.setEmployeeName("Unknown Employee");
        }

        // PRIORITY: role -> department -> companyName -> "Employee"
        if (role != null && !role.isEmpty()) {
            model.setDepartment(role); // This will display "Android developer"
        } else if (department != null && !department.isEmpty()) {
            model.setDepartment(department);
        } else if (companyName != null && !companyName.isEmpty()) {
            model.setDepartment(companyName);
        } else {
            model.setDepartment("Employee");
        }

        if (email != null) model.setEmail(email);
        if (phone != null) model.setPhone(phone);

        attendanceMap.put(employeeId, model);
        counts.absent++;

        Log.d(TAG, "Absent employee created: " + name + " | Role: " + model.getDepartment());
    }

    private String determineStatus(HistoryModel model) {
        String checkInTime = model.getCheckIn();
        String checkOutTime = model.getCheckOut();
        String finalStatus = model.getFinalStatus();
        String status = model.getStatus();

        // If status is already set, use it
        if (status != null && !status.isEmpty() &&
                !status.equals("PENDING") && !status.equals("N/A")) {
            return status.toUpperCase();
        }

        // If final status is set, use it
        if (finalStatus != null && !finalStatus.isEmpty()) {
            if (finalStatus.equalsIgnoreCase("PRESENT")) {
                // Check if late
                if (checkInTime != null && !checkInTime.isEmpty() &&
                        !checkInTime.equals("--:--") && AttendanceUtils.isLate(checkInTime)) {
                    return "LATE";
                }
                return "PRESENT";
            } else if (finalStatus.equalsIgnoreCase("ABSENT")) {
                return "ABSENT";
            }
        }

        // Determine based on check-in/check-out
        if (checkInTime != null && !checkInTime.isEmpty() &&
                !checkInTime.equals("--:--")) {
            if (AttendanceUtils.isLate(checkInTime)) {
                return "LATE";
            }
            return "PRESENT";
        }

        return "ABSENT";
    }

    private void filterAttendance(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(historyList);
        } else {
            String searchQuery = query.toLowerCase().trim();
            for (HistoryModel model : historyList) {
                String name = model.getEmployeeName() != null ? model.getEmployeeName().toLowerCase() : "";
                String dept = model.getDepartment() != null ? model.getDepartment().toLowerCase() : "";
                String empId = model.getEmployeeId() != null ? model.getEmployeeId().toLowerCase() : "";
                String status = model.getStatus() != null ? model.getStatus().toLowerCase() : "";

                if (name.contains(searchQuery) || dept.contains(searchQuery) ||
                        empId.contains(searchQuery) || status.contains(searchQuery)) {
                    filteredList.add(model);
                }
            }
        }

        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                historyAdapter.updateList(filteredList);
                updateEmptyState();
            });
        }
    }

    private void updateEmptyState() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                if (filteredList.isEmpty()) {
                    llEmptyState.setVisibility(View.VISIBLE);
                    recyclerAttendance.setVisibility(View.GONE);
                } else {
                    llEmptyState.setVisibility(View.GONE);
                    recyclerAttendance.setVisibility(View.VISIBLE);
                }
            });
        }
    }

    private void showEmptyState() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                llEmptyState.setVisibility(View.VISIBLE);
                recyclerAttendance.setVisibility(View.GONE);
            });
        }
    }

    private void removeListeners() {
        if (employeeListener != null && employeesRef != null) {
            employeesRef.removeEventListener(employeeListener);
        }
        if (attendanceListener != null && attendanceRef != null) {
            attendanceRef.removeEventListener(attendanceListener);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        removeListeners();
        if (timeHandler != null) {
            timeHandler.removeCallbacksAndMessages(null);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        removeListeners();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (companyKey != null && !companyKey.isEmpty()) {
            startLiveDataListener();
        }
    }
}