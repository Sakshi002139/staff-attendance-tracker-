package com.example.staffattendance.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.database.FirebaseDatabase;

public class SessionManager {

    private static final int PRIVATE_MODE = Context.MODE_PRIVATE;
    private static final String PREF_NAME = "staff_attendance_session";

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context context;

    // SESSION KEYS
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_LAST_LOGIN = "lastLogin";

    // ACTIVITY KEYS
    private static final String KEY_LAST_ACTIVE = "lastActive";
    private static final String KEY_APP_STATUS = "appStatus";

    private static final String KEY_USER_PHONE = "userPhone";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_ROLE = "userRole";
    private static final String KEY_EMP_ID = "empId";
    private static final String KEY_USER_ID = "userId"; // ADDED: User ID key

    private static final String KEY_COMPANY_KEY = "companyKey";
    private static final String KEY_COMPANY_NAME = "companyName";
    private static final String KEY_COMPANY_ID = "companyId";
    private static final String KEY_COMPANY_CODE = "companyCode";

    private static final String KEY_PROFILE_IMAGE = "profileImage";
    private static final String KEY_DARK_MODE = "darkMode";
    private static final String KEY_LANGUAGE = "language";

    // OFFICE LOCATION KEYS
    private static final String KEY_OFFICE_LAT = "officeLat";
    private static final String KEY_OFFICE_LNG = "officeLng";
    private static final String KEY_OFFICE_RADIUS = "officeRadius";

    // Session timeout in milliseconds (7 days instead of 24 hours)
    private static final long SESSION_TIMEOUT = 7 * 24 * 60 * 60 * 1000; // 7 days

    public SessionManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    // ================= LOGIN SESSION =================

    public void createLoginSession(String email, String role, String companyKey) {
        createLoginSession(email, role, companyKey, null, "", "");
    }

    public void createLoginSession(String email, String role, String companyKey,
                                   String empId, String companyName, String userName) {

        long currentTime = System.currentTimeMillis();

        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_ROLE, role);
        editor.putString(KEY_COMPANY_KEY, companyKey);
        editor.putString(KEY_EMP_ID, empId != null ? empId : "");
        editor.putString(KEY_COMPANY_NAME, companyName != null ? companyName : "");
        editor.putString(KEY_USER_NAME, userName != null ? userName : "");

        // ADDED: Store user ID (for admin, this is the same as email or phone)
        editor.putString(KEY_USER_ID, email); // Using email as user ID by default

        editor.putLong(KEY_LAST_LOGIN, currentTime);
        editor.putLong(KEY_LAST_ACTIVE, currentTime);
        editor.putString(KEY_APP_STATUS, "ONLINE");

        editor.apply();

        // FIREBASE SYNC - Only for employees
        if (empId != null && !empId.isEmpty()) {
            syncEmployeeStatus(companyKey, empId, "ACTIVE", "active");
        }
    }

    public void createLoginSession(String email, String role,
                                   String companyKey, String empId) {
        createLoginSession(email, role, companyKey, empId, "", "");
    }

    // ADDED: Overloaded method with user ID
    public void createLoginSession(String email, String role, String companyKey,
                                   String empId, String companyName, String userName, String userId) {
        long currentTime = System.currentTimeMillis();

        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_ROLE, role);
        editor.putString(KEY_COMPANY_KEY, companyKey);
        editor.putString(KEY_EMP_ID, empId != null ? empId : "");
        editor.putString(KEY_COMPANY_NAME, companyName != null ? companyName : "");
        editor.putString(KEY_USER_NAME, userName != null ? userName : "");
        editor.putString(KEY_USER_ID, userId != null ? userId : email);

        editor.putLong(KEY_LAST_LOGIN, currentTime);
        editor.putLong(KEY_LAST_ACTIVE, currentTime);
        editor.putString(KEY_APP_STATUS, "ONLINE");

        editor.apply();

        // FIREBASE SYNC - Only for employees
        if (empId != null && !empId.isEmpty()) {
            syncEmployeeStatus(companyKey, empId, "ACTIVE", "active");
        }
    }

    // ================= FIREBASE SYNC =================

    private void syncEmployeeStatus(String companyKey, String empId,
                                    String status, String accountStatus) {
        try {
            FirebaseDatabase.getInstance()
                    .getReference("Companies")
                    .child(companyKey)
                    .child("Employees")
                    .child(empId)
                    .child("status")
                    .setValue(status);

            FirebaseDatabase.getInstance()
                    .getReference("Companies")
                    .child(companyKey)
                    .child("Employees")
                    .child(empId)
                    .child("accountStatus")
                    .setValue(accountStatus);

            FirebaseDatabase.getInstance()
                    .getReference("Companies")
                    .child(companyKey)
                    .child("Employees")
                    .child(empId)
                    .child("lastActive")
                    .setValue(System.currentTimeMillis());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= OFFICE LOCATION =================

    public void saveOfficeLocation(double lat, double lng, float radius) {
        editor.putLong(KEY_OFFICE_LAT, Double.doubleToRawLongBits(lat));
        editor.putLong(KEY_OFFICE_LNG, Double.doubleToRawLongBits(lng));
        editor.putFloat(KEY_OFFICE_RADIUS, radius);
        editor.apply();
    }

    public double getOfficeLat() {
        return Double.longBitsToDouble(pref.getLong(KEY_OFFICE_LAT, 0));
    }

    public double getOfficeLng() {
        return Double.longBitsToDouble(pref.getLong(KEY_OFFICE_LNG, 0));
    }

    public float getOfficeRadius() {
        return pref.getFloat(KEY_OFFICE_RADIUS, 100f);
    }

    // ================= COMPANY =================

    public void setCompanyCode(String companyCode) {
        editor.putString(KEY_COMPANY_CODE, companyCode);
        editor.apply();
    }

    public String getCompanyCode() {
        return pref.getString(KEY_COMPANY_CODE, "");
    }

    public void setCompanyId(String companyId) {
        editor.putString(KEY_COMPANY_ID, companyId);
        editor.apply();
    }

    public String getCompanyId() {
        return pref.getString(KEY_COMPANY_ID, "");
    }

    public String getCompanyKey() {
        return pref.getString(KEY_COMPANY_KEY, "");
    }

    public void setCompanyName(String companyName) {
        editor.putString(KEY_COMPANY_NAME, companyName);
        editor.apply();
    }

    public String getCompanyName() {
        return pref.getString(KEY_COMPANY_NAME, "");
    }

    // ================= USER =================

    public void saveUserData(String name, String email, String phone, String role) {
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_PHONE, phone);
        editor.putString(KEY_USER_ROLE, role);
        editor.apply();
    }

    public void saveUserData(String name, String email) {
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.apply();
    }

    public String getUserName() {
        return pref.getString(KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return pref.getString(KEY_USER_EMAIL, "");
    }

    public void setUserPhone(String phone) {
        editor.putString(KEY_USER_PHONE, phone);
        editor.apply();
    }

    public String getUserPhone() {
        return pref.getString(KEY_USER_PHONE, "");
    }

    public String getUserRole() {
        return pref.getString(KEY_USER_ROLE, "");
    }

    public boolean isAdmin() {
        return "admin".equalsIgnoreCase(getUserRole());
    }

    public boolean isEmployee() {
        return "employee".equalsIgnoreCase(getUserRole());
    }

    public void setEmpId(String empId) {
        editor.putString(KEY_EMP_ID, empId);
        editor.apply();
    }

    public String getEmpId() {
        return pref.getString(KEY_EMP_ID, "");
    }

    // ADDED: Get User ID method
    public String getUserId() {
        String userId = pref.getString(KEY_USER_ID, "");
        // If userId is empty, fallback to email or empId
        if (userId.isEmpty()) {
            userId = getUserEmail();
            if (userId.isEmpty()) {
                userId = getEmpId();
            }
        }
        return userId;
    }

    // ADDED: Set User ID method
    public void setUserId(String userId) {
        editor.putString(KEY_USER_ID, userId);
        editor.apply();
    }

    // ================= PROFILE =================

    public void setProfileImage(String imageUrl) {
        editor.putString(KEY_PROFILE_IMAGE, imageUrl);
        editor.apply();
    }

    public String getProfileImage() {
        return pref.getString(KEY_PROFILE_IMAGE, "");
    }

    // ================= SETTINGS =================

    public void setDarkMode(boolean enabled) {
        editor.putBoolean(KEY_DARK_MODE, enabled);
        editor.apply();
    }

    public boolean isDarkMode() {
        return pref.getBoolean(KEY_DARK_MODE, false);
    }

    public void setLanguage(String languageCode) {
        editor.putString(KEY_LANGUAGE, languageCode);
        editor.apply();
    }

    public String getLanguage() {
        return pref.getString(KEY_LANGUAGE, "en");
    }

    // ================= SESSION =================

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public long getLastLoginTime() {
        return pref.getLong(KEY_LAST_LOGIN, 0);
    }

    // FIXED: Session expiration check
    public boolean isSessionExpired() {
        long lastLogin = getLastLoginTime();
        if (lastLogin == 0) return true;

        long currentTime = System.currentTimeMillis();
        long timeDifference = currentTime - lastLogin;

        // Log for debugging
        android.util.Log.d("SessionManager", "Time since last login: " + (timeDifference / 1000 / 60) + " minutes");
        android.util.Log.d("SessionManager", "Session timeout: " + (SESSION_TIMEOUT / 1000 / 60 / 60) + " hours");

        return timeDifference > SESSION_TIMEOUT;
    }

    public void updateLastLogin() {
        editor.putLong(KEY_LAST_LOGIN, System.currentTimeMillis());
        editor.apply();
    }

    public void updateLastActive() {
        editor.putLong(KEY_LAST_ACTIVE, System.currentTimeMillis());
        editor.apply();
    }

    public long getLastActive() {
        return pref.getLong(KEY_LAST_ACTIVE, 0);
    }

    public void setAppStatus(String status) {
        editor.putString(KEY_APP_STATUS, status);
        editor.apply();
    }

    public String getAppStatus() {
        return pref.getString(KEY_APP_STATUS, "OFFLINE");
    }

    // FIXED: Session validation
    public boolean hasValidSession() {
        if (!isLoggedIn()) {
            android.util.Log.d("SessionManager", "Not logged in");
            return false;
        }

        if (isSessionExpired()) {
            android.util.Log.d("SessionManager", "Session expired");
            return false;
        }

        if (getCompanyKey().isEmpty()) {
            android.util.Log.d("SessionManager", "No company key");
            return false;
        }

        // For employees, check empId
        if (isEmployee() && getEmpId().isEmpty()) {
            android.util.Log.d("SessionManager", "Employee but no empId");
            return false;
        }

        android.util.Log.d("SessionManager", "Session valid");
        return true;
    }

    // ================= LOGOUT =================

    public boolean logout() {
        editor.putString(KEY_APP_STATUS, "OFFLINE");
        editor.apply();

        String companyKey = getCompanyKey();
        String empId = getEmpId();

        // Update Firebase for employees only
        if (!companyKey.isEmpty() && !empId.isEmpty()) {
            try {
                FirebaseDatabase.getInstance()
                        .getReference("Companies")
                        .child(companyKey)
                        .child("Employees")
                        .child(empId)
                        .child("accountStatus")
                        .setValue("inactive");

                FirebaseDatabase.getInstance()
                        .getReference("Companies")
                        .child(companyKey)
                        .child("Employees")
                        .child(empId)
                        .child("status")
                        .setValue("OFFLINE");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Clear all session data
        editor.clear();
        editor.apply();

        return true;
    }

    // ================= CONVENIENCE METHODS =================

    public void logoutUser() {
        logout();
    }

    // Clear specific data
    public void clearUserData() {
        editor.remove(KEY_USER_NAME);
        editor.remove(KEY_USER_EMAIL);
        editor.remove(KEY_USER_PHONE);
        editor.remove(KEY_USER_ROLE);
        editor.remove(KEY_EMP_ID);
        editor.remove(KEY_USER_ID);
        editor.remove(KEY_PROFILE_IMAGE);
        editor.apply();
    }

    public void clearCompanyData() {
        editor.remove(KEY_COMPANY_KEY);
        editor.remove(KEY_COMPANY_NAME);
        editor.remove(KEY_COMPANY_ID);
        editor.remove(KEY_COMPANY_CODE);
        editor.remove(KEY_OFFICE_LAT);
        editor.remove(KEY_OFFICE_LNG);
        editor.remove(KEY_OFFICE_RADIUS);
        editor.apply();
    }

    // ================= DEBUG =================

    public String getSessionInfo() {
        return "Session Info:\n" +
                "Logged In: " + isLoggedIn() + "\n" +
                "Session Expired: " + isSessionExpired() + "\n" +
                "Time Since Login: " + ((System.currentTimeMillis() - getLastLoginTime()) / 1000 / 60) + " minutes\n" +
                "User Name: " + getUserName() + "\n" +
                "User Email: " + getUserEmail() + "\n" +
                "User Phone: " + getUserPhone() + "\n" +
                "User Role: " + getUserRole() + "\n" +
                "User ID: " + getUserId() + "\n" +
                "Employee ID: " + getEmpId() + "\n" +
                "Company Code: " + getCompanyCode() + "\n" +
                "Company Key: " + getCompanyKey() + "\n" +
                "Company Name: " + getCompanyName() + "\n" +
                "Last Active: " + getLastActive() + "\n" +
                "App Status: " + getAppStatus() + "\n" +
                "Office Lat: " + getOfficeLat() + "\n" +
                "Office Lng: " + getOfficeLng() + "\n" +
                "Office Radius: " + getOfficeRadius() + "\n" +
                "Dark Mode: " + isDarkMode() + "\n" +
                "Language: " + getLanguage();
    }
}