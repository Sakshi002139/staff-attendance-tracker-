package com.example.staffattendance.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final int PRIVATE_MODE = Context.MODE_PRIVATE;
    private static final String PREF_NAME = "staff_attendance_session";

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    // Keys
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_LAST_LOGIN = "lastLogin";
    private static final String KEY_USER_PHONE = "userPhone";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_ROLE = "userRole";
    private static final String KEY_EMP_ID = "empId";
    private static final String KEY_COMPANY_KEY = "companyKey";
    private static final String KEY_COMPANY_NAME = "companyName";
    private static final String KEY_COMPANY_ID = "companyId"; // Added
    private static final String KEY_PROFILE_IMAGE = "profileImage"; // Added for profile image
    private static final String KEY_DARK_MODE = "darkMode";
    private static final String KEY_LANGUAGE = "language";

    public SessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    // ✅ FIXED: Changed parameter name from 'phone' to 'email' to match usage
    public void createLoginSession(String email, String role, String companyKey) {
        createLoginSession(email, role, companyKey, null, "", "");
    }

    // ✅ ADDED: New method with all parameters including companyName and userName
    public void createLoginSession(String email, String role, String companyKey, String empId, String companyName, String userName) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_USER_EMAIL, email);  // Store email instead of phone
        editor.putString(KEY_USER_ROLE, role);
        editor.putString(KEY_COMPANY_KEY, companyKey);
        editor.putString(KEY_EMP_ID, empId);
        editor.putString(KEY_COMPANY_NAME, companyName);
        editor.putString(KEY_USER_NAME, userName);
        editor.putLong(KEY_LAST_LOGIN, System.currentTimeMillis());
        editor.apply();
    }

    // ✅ ADDED: Method with email, role, companyKey, and empId
    public void createLoginSession(String email, String role, String companyKey, String empId) {
        createLoginSession(email, role, companyKey, empId, "", "");
    }

    // ========== ADDED: Profile Image Methods ==========
    public void saveProfileImage(String imageUrl) {
        editor.putString(KEY_PROFILE_IMAGE, imageUrl);
        editor.apply();
    }

    public String getProfileImage() {
        return pref.getString(KEY_PROFILE_IMAGE, "");
    }

    // ========== ADDED: Complete User Data Method ==========
    public void saveUserData(String name, String email, String phone, String role) {
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_PHONE, phone);
        editor.putString(KEY_USER_ROLE, role);
        editor.apply();
    }

    // ========== ADDED: Complete Employee Data Method with Status ==========
    public void saveEmployeeData(String name, String email, String phone, String role, String status) {
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_PHONE, phone);
        editor.putString(KEY_USER_ROLE, role);
        editor.apply();
    }

    // ========== ADDED: Company ID Methods ==========
    public void setCompanyId(String companyId) {
        editor.putString(KEY_COMPANY_ID, companyId);
        editor.apply();
    }

    public String getCompanyId() {
        return pref.getString(KEY_COMPANY_ID, "");
    }

    // ========== EXISTING METHODS ==========
    public void setEmpId(String empId) {
        editor.putString(KEY_EMP_ID, empId);
        editor.apply();
    }

    public String getEmpId() {
        return pref.getString(KEY_EMP_ID, null);
    }

    public void setUserPhone(String phone) {
        editor.putString(KEY_USER_PHONE, phone);
        editor.apply();
    }

    public String getUserPhone() {
        return pref.getString(KEY_USER_PHONE, null);
    }

    // Overloaded method for backward compatibility
    public void saveUserData(String name, String email) {
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.apply();
    }

    public String getUserName() {
        return pref.getString(KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return pref.getString(KEY_USER_EMAIL, "");
    }

    public String getCompanyKey() {
        return pref.getString(KEY_COMPANY_KEY, null);
    }

    public void setCompanyName(String companyName) {
        editor.putString(KEY_COMPANY_NAME, companyName);
        editor.apply();
    }

    public String getCompanyName() {
        return pref.getString(KEY_COMPANY_NAME, "");
    }

    public String getUserRole() {
        return pref.getString(KEY_USER_ROLE, "");
    }

    public boolean isAdmin() {
        return "admin".equalsIgnoreCase(getUserRole());
    }

    public boolean isEmployee() {
        return "employee".equalsIgnoreCase(getUserRole());
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public long getLastLoginTime() {
        return pref.getLong(KEY_LAST_LOGIN, 0);
    }

    public boolean isSessionExpired() {
        long last = getLastLoginTime();
        if (last == 0) return true;
        return (System.currentTimeMillis() - last) > (24 * 60 * 60 * 1000);
    }

    public void setDarkMode(boolean enabled) {
        editor.putBoolean(KEY_DARK_MODE, enabled);
        editor.apply();
    }

    public boolean isDarkMode() {
        return pref.getBoolean(KEY_DARK_MODE, false);
    }

    public void setLanguage(String lang) {
        editor.putString(KEY_LANGUAGE, lang);
        editor.apply();
    }

    public String getLanguage() {
        return pref.getString(KEY_LANGUAGE, "en");
    }

    // ✅ IMPROVED: Added boolean return to check if logout was successful
    public boolean logout() {
        try {
            editor.clear();
            return editor.commit(); // Use commit() instead of apply() for immediate result
        } catch (Exception e) {
            return false;
        }
    }

    // ✅ ADDED: Method to check if session has required data
    public boolean hasValidSession() {
        return isLoggedIn() &&
                !isSessionExpired() &&
                getCompanyKey() != null &&
                getEmpId() != null;
    }

    // ✅ ADDED: Method to update last login time
    public void updateLastLogin() {
        editor.putLong(KEY_LAST_LOGIN, System.currentTimeMillis());
        editor.apply();
    }
}