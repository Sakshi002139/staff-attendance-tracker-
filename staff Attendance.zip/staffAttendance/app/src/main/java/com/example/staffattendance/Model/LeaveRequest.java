package com.example.staffattendance.Model;

public class LeaveRequest {
    private String leaveId;
    private String empId;
    private String companyKey;
    private String leaveType;
    private long startDate;
    private long endDate;
    private int days;
    private String reason;
    private String status; // pending, approved, rejected
    private long timestamp;
    private long approvedAt;
    private long rejectedAt;
    private String approvedBy;
    private String rejectedBy;
    private String rejectionReason;

    // For displaying employee details
    private Employee employee;

    // Default constructor required for Firebase
    public LeaveRequest() {}

    // Getters and Setters
    public String getLeaveId() { return leaveId; }
    public void setLeaveId(String leaveId) { this.leaveId = leaveId; }

    public String getEmpId() { return empId; }
    public void setEmpId(String empId) { this.empId = empId; }

    public String getCompanyKey() { return companyKey; }
    public void setCompanyKey(String companyKey) { this.companyKey = companyKey; }

    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    public long getStartDate() { return startDate; }
    public void setStartDate(long startDate) { this.startDate = startDate; }

    public long getEndDate() { return endDate; }
    public void setEndDate(long endDate) { this.endDate = endDate; }

    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public long getApprovedAt() { return approvedAt; }
    public void setApprovedAt(long approvedAt) { this.approvedAt = approvedAt; }

    public long getRejectedAt() { return rejectedAt; }
    public void setRejectedAt(long rejectedAt) { this.rejectedAt = rejectedAt; }

    public String getApprovedBy() { return approvedBy; }
    public void setApprovedBy(String approvedBy) { this.approvedBy = approvedBy; }

    public String getRejectedBy() { return rejectedBy; }
    public void setRejectedBy(String rejectedBy) { this.rejectedBy = rejectedBy; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }
}